package com.example.friendtree;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import android.util.Log;

public class handler extends DefaultHandler {

	//
	TomorrowWeatherV0 tomorrowWeatherV0;

	//
	int findCount = 0;

	//
	public handler() {
		super();
	}

	//
	public handler(TomorrowWeatherV0 tomorrowWeatherV0) {
		this.tomorrowWeatherV0 = tomorrowWeatherV0;
	}

	/*
	 * 
	 */
	@Override
	public void endDocument() throws SAXException {
		Log.i("yao", "ooo");
		super.endDocument();
	}

	/*
	 * 
	 */
	@Override
	public void startDocument() throws SAXException {
		Log.i("yao", "ooo");
		super.startDocument();
	}
	
	int count = 0;
	/*
	 * 
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

		Log.i("yao", qName);
		if (qName.equals("weather")) {
			tomorrowWeatherV0.setLocation(attributes.getValue("weatherlocationname"));
		}
		if (qName.equals("current")) {
			tomorrowWeatherV0.setCurrenttemperature(attributes.getValue("temperature"));
			tomorrowWeatherV0.setCurrentcondition(attributes.getValue("skycode"));
		}
		if (qName.equals("forecast")) {
			count++;
			if(count==1)
			{
				tomorrowWeatherV0.setHigh(attributes.getValue("high"));
				tomorrowWeatherV0.setLow(attributes.getValue("low"));
				tomorrowWeatherV0.setCondition(attributes.getValue("skytextday"));
				tomorrowWeatherV0.setDate(attributes.getValue("date"));
				tomorrowWeatherV0.setDay(attributes.getValue("day"));
			}
			if(count==2)
			{
				tomorrowWeatherV0.setHigh2(attributes.getValue("high"));
				tomorrowWeatherV0.setLow2(attributes.getValue("low"));
				tomorrowWeatherV0.setCondition2(attributes.getValue("skytextday"));
				tomorrowWeatherV0.setDate2(attributes.getValue("date"));
				tomorrowWeatherV0.setDay2(attributes.getValue("day"));
			}
		}
		super.startElement(uri, localName, qName, attributes);
	}

	/*
	 *
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		Log.i("yao", "ooo");
		super.endElement(uri, localName, qName);
	}

	/*
	 * 
	 */
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		super.characters(ch, start, length);
	}

}