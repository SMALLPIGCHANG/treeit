package com.example.friendtree;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;

import com.facebook.*;
import com.facebook.model.*;
import android.support.v4.app.FragmentActivity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.widget.TextView;

public class FriendTree extends FragmentActivity {

	private MainFragment mainFragment;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);       															//�h�����ε{�����D
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);	//�h����������Abar
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);											//�ù����V
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);											//�ù���V
		setContentView(R.layout.activity_friend_tree);
		
		
		//�����{���^�ӮɭY�O�n�J�Y�]if
		if (savedInstanceState == null) {
			// Add the fragment on initial activity setup
			mainFragment = new MainFragment();
			getSupportFragmentManager()
			.beginTransaction()
			.add(android.R.id.content, mainFragment)
			.commit();
		            
			Log.i("TAG", "if");
		} else {
			// Or set the fragment from restored state info
			mainFragment = (MainFragment) getSupportFragmentManager()
					.findFragmentById(android.R.id.content);
			Log.i("TAG", "else");
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.friend_tree, menu);
		return true;
	}

}
