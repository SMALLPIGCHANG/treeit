package com.example.friendtree;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import android.util.Log;

public class GetWeather {
    public String getWeather(String cityName) {
	InputStream inputstream=null;
	 String s, str="";
        try {
            /*URL url = new URL("http://www.google.com/ig/api?hl=zh_tw&weather="
                    + cityName);*/
        	/*URL url = new URL("http://weather.msn.com/data.aspx?wealocations=wc:TWXX0021&weadegreetype=C");*/
        	URL url = new URL("http://weather.msn.com/data.aspx?wealocations=wc:" + cityName + "&weadegreetype=C");
            inputstream = url.openStream();
            URLConnection conn = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(
        	    conn.getInputStream()));
            StringBuffer stringbuffer = new StringBuffer();
            while ((s = in.readLine()) != null) {
                //stringbuffer.append(s);
        	str = str+ s;
            }
            in.close();
            
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(str)));
            NodeList nodelist1 = (NodeList) doc
                    .getElementsByTagName("forecast_conditions");
            NodeList nodelist2 = nodelist1.item(0).getChildNodes();
            str = nodelist2.item(1).getAttributes().item(0).getNodeValue()
                    + "-"
                    + nodelist2.item(2).getAttributes().item(0).getNodeValue()
                    ;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }

}
