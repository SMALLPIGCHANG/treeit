package com.example.friendtree;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xml.sax.SAXException;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsoluteLayout;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;

@SuppressLint("NewApi")
@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class MainFragment extends Fragment {
	
	private static final String TAG = "MainFragment";
	private Display display;
	private int screenWidth,screenHeight;
	private UiLifecycleHelper uiHelper;
	LoginButton authButton;
	private ImageButton logbutton;
	
	//�ɶ��ܼƫŧi
	protected static final int GUINOTIFIER = 0x1234;
	public Calendar mCalendar;
	public int mYear;
	public int mMonth;
	public int mDay;
	public int mWeek;
	public int mHour;
	public int mMinutes;
	public int msecond;
	public int realmMonth;
	public String realmWeek;
	public Handler mHandler;
	private Thread mClockThread;
	
	//�w���ܼ�
	private LocationManager locationManager;
	private Location myLocation;
	private Criteria criteria;
	String city;
	String lolo;
	
	public String uid;
	private TextView txt;
	private Button sendBtn;
	private TextView webtext,date;
	private String decideurl = "http://cell5.widelab.org/~b9929061/android/neworolduser.php";
	private String friendurl = "http://cell5.widelab.org/~b9929061/android/conDBtestall.php";
	private String commenturl = "http://cell5.widelab.org/~b9929061/android/conDBtestallcomment.php";
	private String hoturl = "http://cell5.widelab.org/~b9929061/android/conDBtestallhot.php";
	private String groupurl = "http://cell5.widelab.org/~b9929061/android/group.php";
	private String albumlisturl = "http://cell5.widelab.org/~b9929061/android/albumlist.php";
	private String personalhoturl = "http://cell5.widelab.org/~b9929061/android/personalhot.php";
	private String recommendurl = "http://cell5.widelab.org/~b9929061/android/recommend.php";
	private String noticeurl = "http://cell5.widelab.org/~b9929061/android/notice.php";
	private String clearurl = "http://cell5.widelab.org/~b9929061/android/clear.php";
	private String likerecordurl = "http://cell5.widelab.org/~b9929061/android/likerecord.php";
	private String commentrecordurl = "http://cell5.widelab.org/~b9929061/android/comrecord.php";
	private String sharerecordurl = "http://cell5.widelab.org/~b9929061/android/likerecord.php";
	private String tagrecordurl = "http://cell5.widelab.org/~b9929061/android/tagrecord.php";
	private String messagerecordurl = "http://cell5.widelab.org/~b9929061/android/comrecord.php";
	private String result = null;
	private String groupresult = null;
	private JSONArray ja;
	private boolean threadDisable;
	private int newuser=0,all15=0;
	
	private ImageButton rereadguide;
	
	private ImageView myself;
	private Button myselfclick;
	private ImageView[] tip;
	private ImageButton[] tipclick;
	//�B���ܼ�
	private String[] fname,fid,content,clicktime;
	private int[] sp,like_num,comment_num,mood;
	ProgressBar pd = null;
	AbsoluteLayout absolute;
	
	private ImageButton[] recommendibtn;
	private String[] recommendid;
	private ImageView recommendprofile;
	private ImageView recommendbackground;
	private ImageButton recommendadd;
	private ImageView recommendsendmessagepic;
	private Button recommendsendmessage;
	
	private int count=0;
	private int newusercount=0;
	private int jumptoshow=0;
	private int loging=0;
	private TextView loading;
	private ImageView loadingbackground;
	private TextView[] loadingdot;
	private int dotblack = 0;
	private int dynamicdot = 0;
	
	private String curl1[],curl2[],curl;
	public WebView myWebView;
	public WebView updatedata,updatedata10,updatedata60;
	private int updatecondition=0;
	
	private Animation animation,animation2,animation3,animation4;
	private Animation leafrotateanimation,rainanimation,rainanimation2;
	private Animation leaffallanimation,leaffallanimation2;
	private Animation birdfly1,birdfly2;
	private Animation newspaperrotation,newspapertranslation,newspaperscale;
	private Animation friendtranslation,friendscale;
	private Animation noticetranslation,noticetranslation2,noticerotationset1,noticetranslationset1,noticerotationset2,noticetranslationset2;
	private Animation noticewindowtranslation,noticewindowscale;
	private AnimationSet newspaperanimation,friendanimation,noticeanimation,noticeanimation2,noticewindowanimation;
	
	private int[] fallcondition;
	
	private ImageView[] rain;
	private int raincondition = 0;
	private int addrain = 0;
	
	
	//������ܼ�
	int birdarrx[] = {-200,810};
	int birdarry[] = {50,410};
	private ImageView[] bird;
	int birdflycondition = 0;
	private ImageButton newspaper;
	private ImageView hotbackground;


	int rand;
	int now = 0;
	int iqqq = 0;
	int nnn = 0;
	int inout = 0;
	
	private int[] afa;
	private ImageView trunk,imagetemp,imagetemp2;
	private ImageView friendbackground;
	private int friendnow=0;
	private Button btntemp;
	private ImageButton imgbtntemp;
	
	private ImageButton imgbtntemp2;
	
	private ImageButton clearbutton;
	
	private ImageButton[] leafibtn;
	private int CurrentButtonNumber = 0;
	//�Ĥ@���q�𸭪�x�y��
	int leaf1x[]={607,616,584,540,574,634,688,701,669,715,555,550,655,738,742};
	//�Ĥ@���q�𸭪�y�y��
	int leaf1y[]={578,539,513,524,552,503,488,564,527,522,485,583,475,492,548};
	//�Ĥ@���q���˦n��x�y��
	int recommendfriend1x[]={614,637,653,674,689,677};
	//�Ĥ@���q���˦n��y�y��
	int recommendfriend1y[]={700,673,615,596,700,663};
	
	//�ĤG���q�𸭪�x�y��
	int leaf2x[]={530,490,515,558,543,515,586,558,605,582,645,654,694,703,666,
				  642,629,606,599,576,715,739,699,786,744,770,800,763,734,713,
				  748,525,490,537,790,719};
	//�ĤG���q�𸭪�y�y��
	int leaf2y[]={379,386,420,413,452,482,449,490,483,525,502,462,457,410,393,
				  425,368,402,341,376,327,364,369,394,401,433,462,474,447,498,
				  512,525,454,335,355,527};
	//�ĤG���q���˦n��x�y��
	int recommendfriend2x[]={688,682,678,639,611,590};
	//�ĤG���q���˦n��y�y��
	int recommendfriend2y[]={695,663,561,587,655,692};
	
	//�ĤT���q�𸭪�x�y��
	//x����5
	int leaf3x[]={482,522,518,557,599,553,473,494,452,475,452,498,540,441,480,
				  524,569,535,550,574,590,614,614,654,644,672,691,648,664,692,
				  718,708,751,765,802,842,808,732,691,879,897,835,796,784,859,
				  825,792,833,866,754,694,720,470,513,604,752,762};
	//�ĤT���q�𸭪�y�y��
	//y����40
	int leaf3y[]={463,484,443,461,458,419,237,274,274,309,344,342,339,397,378,
				  373,370,248,298,263,226,260,301,294,333,364,400,417,240,273,
				  308,347,334,376,391,404,431,436,477,384,346,365,350,312,332,
				  302,273,262,292,221,221,246,420,304,350,273,477};
	//�ĤT���q���˦n��x�y��
	int recommendfriend3x[]={694,700,692,640,602,590};
	//�ĤT���q���˦n��y�y��
	int recommendfriend3y[]={665,622,522,536,625,666};
	
	//�ĥ|���q�𸭪�x�y��
	int leaf4x[]={680,637,705,786,752,789,831,754,830,873,854,811,821,778,748,
				  791,718,761,687,683,713,648,641,615,588,565,591,564,582,518,
				  479,521,498,534,498,527,438,415,459,443,564,522,480,464,503,
				  466,409,433,415,389,345,369,713,722,754,809,873,850,882,905,
				  797,900,892,923,882,858,832,806,812,837,850,669,687,708,733,
				  753,607,609,656,664,656,622,632,560,475,479,425,458,500,480,
				  369,374,402,410,373,336,368,451,544,596,431,490,850,920,686,
				  381,576};
	//�ĥ|���q�𸭪�y�y��
	int leaf4y[]={439,391,365,411,385,370,376,333,334,337,295,295,224,215,248,
				  258,279,290,327,252,222,312,271,232,196,234,267,303,341,358,
				  310,308,273,259,229,198,215,257,253,291,410,417,421,460,456,
				  383,394,358,324,357,354,320,469,421,428,450,380,414,411,387,
				  339,311,280,287,225,246,266,165,196,174,205,362,297,192,171,
				  197,316,381,243,210,179,169,200,176,353,155,166,183,181,207,
				  209,244,225,298,290,320,391,420,456,445,458,496,460,241,147,
				  169,482};
	//�ĥ|���q���˦n��x�y��
	int recommendfriend4x[]={713,701,684,613,594,575};
	//�ĥ|���q���˦n��y�y��
	int recommendfriend4y[]={661,618,518,554,615,637};
	
	//�Ĥ����q�𸭪�x�y��
	int leaf5x[]={669,782,823,808,749,761,789,822,832,861,762,802,793,688,697,
				  683,720,683,720,610,644,642,652,688,565,584,595,604,621,540,
				  530,518,489,496,509,446,434,442,442,443,477,538,397,397,402,
				  363,360,360,359,360,318,294,321,688,711,743,724,735,767,805,
				  835,849,735,780,889,901,871,841,871,890,852,820,794,828,859,
				  681,655,605,635,593,591,762,798,777,756,743,726,645,645,677,
				  676,724,708,616,569,570,594,551,538,527,501,521,464,477,406,
				  489,469,450,419,440,464,426,402,377,352,342,370,312,338,333,
				  292,270,286,239,242,240,267,299,302,328,363,332,392,448,541,
				  571,565,415,784,890,728,864,903,834,517,472,301,264,264,339};
	//�Ĥ����q�𸭪�y�y��
	int leaf5y[]={413,363,369,330,291,250,281,253,294,264,209,220,181,323,279,
				  239,218,196,177,289,249,208,168,150,289,326,225,186,139,215,
				  175,134,165,201,243,181,222,267,321,384,411,379,250,289,340,
				  184,227,271,311,352,216,253,291,453,429,425,400,370,400,399,
				  409,346,328,321,329,301,306,226,235,208,135,132,150,162,173,
				  366,292,371,370,267,160,181,99,123,151,121,148,86,118,92,
				  124,94,123,104,135,104,84,78,107,332,290,417,359,236,206,
				  94,70,99,87,130,152,159,137,114,92,121,154,132,152,182,
				  160,184,225,192,223,268,315,323,373,354,394,385,382,426,441,
				  451,420,407,427,162,452,374,238,194,78,121,192,250,346,417};
	//�Ĥ����q���˦n��x�y��
	int recommendfriend5x[]={591,620,631,692,701,710};
	//�Ĥ����q���˦n��y�y��
	int recommendfriend5y[]={610,558,469,490,607,647};
		
	
	private ImageButton[] flowerbtn;
	int flowerx[]={1006,875,812,817,505,529,479,257,556,603};
	int flowery[]={211,115,425,548,531,346,291,260,88,76};
	private int[] flick = {0,0,0,0,0,0,0,0,0,0};
	private String[] hotname,hotid,hotcontent,hottime;
	private int[] hot_like_num,hot_comment_num;
	private TextView[] hotcontentborder;
	private TextView[] hotinformation;
	private TextView[] hotcontenttxt;
	private ImageView[] hotpic;
	
	private String[] albumliststringtemp,albumlist,albumcommon,albumlistname,albumlisttime,albumlistpicurl,albumlistid,albumpicture;
	
	private ImageView mempic,talkpic,replacepic;
	private ImageView[] memgroupcircle;
	private ImageView[] memgrouppic;
	private ImageView memcircle;
	private TextView wallnewsframe,wallnews,underline,memname,meminfo;
	private ImageView liketemp,commenttemp;
	private Button liketempnumandlink,commenttempunmandlink;
	private Button talk;
	private ImageView talkbackground;
	private TextView talkframe;
	private String[] talkcontent;
	private int talkopencondition=0;
	private ImageButton left,right;
	private Button gotochat;
	private TextView[] memgroupname;
	private int bbb=0;
	private int groupcount=0;
	private int groupshow=0;
	private int downloaddatacondition=0;
	
	//��U�U���q���άۤ��Ϧr�ܼ�
	private ImageView likepic,commentpic,sharepic,tagpic,messagepic,albumpic;
	private TextView like,comment,share,tag,message,album;
	private ImageView[] noticetype;
	private int noticex[]={1000,1000,260,90,90};//like=90,comment=355,share=600,tag=860,message=1110
	private int noticey[]={250,650,650,725,1000};
	private ImageView[][][] notice;
	private int usecount=0,oldusecount1=0,oldusecount2=0,oldusecount3=0,oldusecount4=0;
	//like=90,comment=355,share=600,tag=860,message=1110
	private int likex[]={1000,260,90,90};
	private int likey[]={650,650,725,1000};
	private int commentx[]={1000,260,355,355};
	private int commenty[]={650,650,725,1000};
	private int sharex[]={1000,260,600,600};
	private int sharey[]={650,650,725,1000};
	private int tagx[]={1000,260,860,860};
	private int tagy[]={650,650,725,1000};
	private int messagex[]={1000,260,1110,1110};
	private int messagey[]={650,650,725,1000};
	private TextView likeframe,commentframe,shareframe,tagframe,messageframe;
	private int likenum,commentnum,sharenum,tagnum,messagenum;
	private ImageButton likeibtn,commentibtn,shareibtn,tagibtn,messageibtn;
	private Button likebtn,commentbtn,sharebtn,tagbtn,messagebtn;
	private ListView list;
	ArrayList<HashMap<String,String>> arraylist = new ArrayList<HashMap<String,String>>();
	private SimpleAdapter adapter;
	
	private ImageView[][] noticelikeelement,noticecommentelement,noticeshareelement,noticetagelement,noticemessageelement;
	
	private String[] noticefid,noticeevent,noticetypes,noticetypeid,noticecontent;
	private String[][] personalnoticeevent,personalnoticetype,personalnoticetypeid,personalnoticecontent;
	private int[] noticenum;
	//���v�q���ܼ�
	private String[] likerecordfid,likerecordevent,likerecordtypes,likerecordtypeid,likerecordcontent;
	private String[] commentrecordfid,commentrecordevent,commentrecordtypes,commentrecordtypeid,commentrecordcontent;
	private String[] tagrecordfid,tagrecordevent,tagrecordtypes,tagrecordtypeid,tagrecordcontent;

	private int[] havenotice;
	private String[] havenoticeid;
	
	private int leafmovecondition = 0;
	
	//����
	private MediaPlayer mPlayer;
	
	private Bitmap[] hotdownloadImageBitmap,hotdoInBackgroundBitmap;
	private Bitmap linkline;
	private Bitmap[] groupdownloadImageBitmap,groupdoInBackgroundBitmap,groupoutputBitmap;
	private Bitmap downloadImageBitmap,doInBackgroundBitmap,outputBitmap;
	
	private HorizontalScrollView horizonsv;
	private FrameLayout fl;
	private GridView mPhotoWall;

	private ImageLoader imgLoader;
	private ImageView[] dmiv;
	private String[] strURL2 ={"http://photos-c.ak.fbcdn.net/hphotos-ak-ash3/s75x225/8135_100170220002455_2832884_s.jpg",
			"http://photos-f.ak.fbcdn.net/hphotos-ak-prn2/s75x225/10534_100228403330174_7269150_s.jpg",
			"http://photos-h.ak.fbcdn.net/hphotos-ak-ash3/s75x225/19756_100739813292804_515645_s.jpg"};
	private ImageService imageService;
	
	String personhotcontent;
	private String[] newstemp;
	private int newsindex=0;
	
	//�s�D�ܼ�
	/** �u�n��s�����v���T���N�X */
    protected static final int REFRESH_DATA = 0x00000001;
    /** Rss��ƪ����} */
    private String trgUrl = "http://tw.news.yahoo.com/rss/realtime";
    /** �s�D��ƪ�����}�C */
    RssNews[] Arr_RssNews;

	
	//�i�J�̥�����
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    uiHelper = new UiLifecycleHelper(getActivity(), callback);
	    uiHelper.onCreate(savedInstanceState);
	    
	    Log.i(TAG, "oncreate");
	    StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
        .detectDiskReads()
        .detectDiskWrites()
        .detectNetwork()   // or .detectAll() for all detectable problems
        .penaltyLog()
        .build());

        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
        .detectLeakedSqlLiteObjects()
        .penaltyLog()
        .penaltyDeath()
        .build());
	}
	//�i�J����
    @SuppressLint("NewApi")
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@Override
	public View onCreateView(LayoutInflater inflater, 
			ViewGroup container, 
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_friend_tree, container, false);

		authButton = (LoginButton) view.findViewById(R.id.authButton);
		authButton.setFragment(this);
		
		
		//authButton.setVisibility(View.GONE);
		//authButton.performClick();
		//authButton.setReadPermissions(Arrays.asList("user_likes", "user_status"));
		
		display = getActivity().getWindowManager().getDefaultDisplay();
		screenWidth = display.getWidth();
		screenHeight = display.getHeight();
		
		// �^��trgUrl_txt��r�ظ̪����e
        // �}�@�Ӱ����(Thread)
        new Thread()
        {
             @Override
             public void run()
             {
                   Arr_RssNews = getRssNews();
                   if (Arr_RssNews != null)
                         // �bHandler�W�o�X�u�n��s�����v���T��
                         mHandlernews.sendEmptyMessage(REFRESH_DATA);
             }
         }.start();
		
		absolute = (AbsoluteLayout) view.findViewById(R.id.AbsoluteLayout1);
		txt = (TextView) view.findViewById(R.id.textView1);
		webtext = (TextView) view.findViewById(R.id.textView2);
		date = (TextView) view.findViewById(R.id.textView3);
		sendBtn = (Button) view.findViewById(R.id.button1);
		hotdownloadImageBitmap = new Bitmap[8];
		hotdoInBackgroundBitmap = new Bitmap[8];
		groupdownloadImageBitmap = new Bitmap[20];
		groupdoInBackgroundBitmap = new Bitmap[20];
		groupoutputBitmap = new Bitmap[20];
		
		
		pd = (ProgressBar) view.findViewById(R.id.progressBar1);
        
        rereadguide = new ImageButton(getActivity());
        myWebView = new WebView(getActivity());
        updatedata = new WebView(getActivity());
        updatedata10 = new WebView(getActivity());
        updatedata60 = new WebView(getActivity());
        myself = new ImageView(getActivity());
        myselfclick = new Button(getActivity());
        trunk = new ImageView(getActivity());
        likepic = new ImageView(getActivity());
        commentpic = new ImageView(getActivity());
        sharepic = new ImageView(getActivity());
        tagpic = new ImageView(getActivity());
        messagepic = new ImageView(getActivity());
        albumpic = new ImageView(getActivity());
        like = new TextView(getActivity());
        comment = new TextView(getActivity());
        share = new TextView(getActivity());
        tag = new TextView(getActivity());
        message = new TextView(getActivity());
        album = new TextView(getActivity());
        likeframe = new TextView(getActivity());
        commentframe = new TextView(getActivity());
        shareframe = new TextView(getActivity());
        tagframe = new TextView(getActivity());
        messageframe = new TextView(getActivity());
        
        horizonsv = new HorizontalScrollView(getActivity());
        fl = new FrameLayout(getActivity());
        mPhotoWall = new GridView(getActivity());
        leafibtn = new ImageButton[200];
        recommendibtn = new ImageButton[6];
        flowerbtn = new ImageButton[10];
		
		

		logbutton = new ImageButton(getActivity());
		//logbutton.getBackground().setAlpha(0);
		//logbutton.setText("�n�X");
		//logbutton.setTextSize(24);
		logbutton.setBackgroundResource(R.drawable.logout);
		logbutton.setOnClickListener(new Button.OnClickListener(){
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				authButton.performClick();
			}
		});
		absolute.addView(logbutton,new AbsoluteLayout.LayoutParams(48,48,15,5));
		logbutton.setVisibility(view.GONE);
		
		
		imgLoader = new ImageLoader(getActivity());
		imageService = new ImageService();
    	dmiv = new ImageView[10];
    	/*for(int i=0;i<3;i++)
    	{
    		dmiv[i] = new ImageView(getActivity());
    		//imgLoader.DisplayImage(strURL2[i],dmiv[i]);
    		imageService.setBitmapByURL(strURL2[i], dmiv[i],BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher), true);
    		absolute.addView(dmiv[i],new AbsoluteLayout.LayoutParams(100,100,i*200,i*200));
    	}*/
		for(int i=0;i<15;i++)
		{
			leaf1x[i]=leaf1x[i]+4;
			leaf1y[i]=leaf1y[i]-35;
		}
		for(int i=0;i<36;i++)
		{
			leaf2x[i]=leaf2x[i]-4;
			leaf2y[i]=leaf2y[i]-60;
		}
		/*for(int i=0;i<57;i++)
		{
			leaf3x[i]=leaf3x[i]-5;
			leaf3y[i]=leaf3y[i]-40;
		}*/
		//�s
		for(int i=0;i<57;i++)
		{
			leaf3x[i]=leaf3x[i]+5;
			leaf3y[i]=leaf3y[i]-10;
		}
		for(int i=0;i<107;i++)
		{
			leaf4x[i]=leaf4x[i]-10;
			leaf4y[i]=leaf4y[i];
		}
		for(int i=0;i<150;i++)
		{
			leaf5x[i]=leaf5x[i]+5;
			leaf5y[i]=leaf5y[i]-5;
		}
        
		tip = new ImageView[2];
		tipclick = new ImageButton[2];
		for(int i=0;i<2;i++)
        {
			tip[i] = new ImageView(getActivity());
			tipclick[i] = new ImageButton(getActivity());
        }
        
        rain = new ImageView[2];
        for(int i=0;i<2;i++)
        {
        	rain[i] = new ImageView(getActivity());
        }
        
        afa = new int[150];
        for(int i=0;i<150;i++)
        {
        	afa[i] = 255;
        }
        
        fallcondition = new int[150];
        for(int i=0;i<150;i++)
        {
        	fallcondition[i] = 0;
        }
        
        initMediaPlayer();
        
        clearbutton = new ImageButton(getActivity());
        noticetype = new ImageView[5];
        for(int i=0;i<5;i++)
        {
        	noticetype[i] = new ImageView(getActivity());
        }
        /*notice = new ImageView[5][4][100];
        for(int i=0;i<5;i++)
        {
        	for(int j=0;j<4;j++)
        	{
        		for(int k=0;k<100;k++)
        		{
        			notice[i][j][k] = new ImageView(getActivity());
        			switch(i)
        			{
        				case 0:
        					notice[i][j][k].setBackgroundResource(R.drawable.like);
        					break;
        				case 1:
        					notice[i][j][k].setBackgroundResource(R.drawable.comment);
        					break;
        				case 2:
        					notice[i][j][k].setBackgroundResource(R.drawable.share);
        					break;
        				case 3:
        					notice[i][j][k].setBackgroundResource(R.drawable.tag);
        					break;
        				case 4:
        					notice[i][j][k].setBackgroundResource(R.drawable.message);
        					break;
        			}
        		}
        	}
        }*/
        
        /*noticelikeelement = new ImageView[4][100];
        noticecommentelement = new ImageView[4][100];
        noticeshareelement = new ImageView[4][100];
        noticetagelement = new ImageView[4][100];
        noticemessageelement = new ImageView[4][100];
        for(int i=0;i<4;i++)
        {
        	for(int j=0;j<100;j++)
        	{
        		noticelikeelement[i][j] = new ImageView(getActivity());
        		noticecommentelement[i][j] = new ImageView(getActivity());
        		noticeshareelement[i][j] = new ImageView(getActivity());
        		noticetagelement[i][j] = new ImageView(getActivity());
        		noticemessageelement[i][j] = new ImageView(getActivity());
        		noticelikeelement[i][j].setBackgroundResource(R.drawable.like);
        		noticecommentelement[i][j].setBackgroundResource(R.drawable.comment);
        		noticeshareelement[i][j].setBackgroundResource(R.drawable.share);
        		noticetagelement[i][j].setBackgroundResource(R.drawable.tag);
        		noticemessageelement[i][j].setBackgroundResource(R.drawable.message);
        		if(i==2)
        		{
        			absolute.addView(noticelikeelement[i][j],new AbsoluteLayout.LayoutParams(70,70, likex[1], likey[1]));
        			absolute.addView(noticecommentelement[i][j],new AbsoluteLayout.LayoutParams(70,70, commentx[1], commenty[1]));
        			absolute.addView(noticeshareelement[i][j],new AbsoluteLayout.LayoutParams(70,70, sharex[1], sharey[1]));
        			absolute.addView(noticetagelement[i][j],new AbsoluteLayout.LayoutParams(70,70, tagx[1], tagy[1]));
        			absolute.addView(noticemessageelement[i][j],new AbsoluteLayout.LayoutParams(70,70, messagex[1], messagey[1]));
        			noticelikeelement[i][j].setVisibility(View.GONE);
        			noticecommentelement[i][j].setVisibility(View.GONE);
        			noticeshareelement[i][j].setVisibility(View.GONE);
        			noticetagelement[i][j].setVisibility(View.GONE);
        			noticemessageelement[i][j].setVisibility(View.GONE);
        		}
        		if(i==3)
        		{
        			absolute.addView(noticelikeelement[i][j],new AbsoluteLayout.LayoutParams(70,70, likex[2], likey[2]));
        			absolute.addView(noticecommentelement[i][j],new AbsoluteLayout.LayoutParams(70,70, commentx[2], commenty[2]));
        			absolute.addView(noticeshareelement[i][j],new AbsoluteLayout.LayoutParams(70,70, sharex[2], sharey[2]));
        			absolute.addView(noticetagelement[i][j],new AbsoluteLayout.LayoutParams(70,70, tagx[2], tagy[2]));
        			absolute.addView(noticemessageelement[i][j],new AbsoluteLayout.LayoutParams(70,70, messagex[2], messagey[2]));
        			noticelikeelement[i][j].setVisibility(View.GONE);
        			noticecommentelement[i][j].setVisibility(View.GONE);
        			noticeshareelement[i][j].setVisibility(View.GONE);
        			noticetagelement[i][j].setVisibility(View.GONE);
        			noticemessageelement[i][j].setVisibility(View.GONE);
        		}
        	}
        }*/

		Log.i(TAG, "oncreateview");
		

		//�ɶ��ܤơA���ܭI����
        final NumberFormat formatter = new DecimalFormat("00");
        mHandler = new Handler(){
        	public void handleMessage(Message msg){
        		
        		if(dynamicdot==1){
        			loadingdot[dotblack].setTextColor(0xFFFFFFFF);
        			dotblack++;
        			dotblack = dotblack%10;
        			loadingdot[dotblack].setTextColor(0xFF111111);
        		}
        		
        		if((jumptoshow+10)%60==msecond && newusercount==5)
        		{
        			Log.e("newusercountnewusercount", String.valueOf(newusercount));
        			newusercount++;
        			Log.e("newusercountnewusercount", String.valueOf(newusercount));
        			
        			Log.v("onpcccccccccccccc", "OOOOOOOOOOOOOO");
    				count=3;
    				//absolute.removeView(myWebView);
    				myWebView.setVisibility(View.GONE);
    				
    				if(newuser==0)
    				{
    					absolute.removeView(loadingbackground);
	    				absolute.removeView(loading);
	    				dynamicdot=2;
	    				for(int i=0;i<10;i++)
	    				{
	    					absolute.removeView(loadingdot[i]);
	    				}
    				}
    				
    				updatedata.setLayoutParams(new LayoutParams(0,0));
    				updatedata.setX(0);
    				updatedata.setY(0);
    				absolute.addView(updatedata);
    				updatedata10.setLayoutParams(new LayoutParams(0,0));
    				updatedata10.setX(100);
    				updatedata10.setY(0);
    				absolute.addView(updatedata10);
    				updatedata60.setLayoutParams(new LayoutParams(0,0));
    				updatedata60.setX(200);
    				updatedata60.setY(0);
    				absolute.addView(updatedata60);
    				
    				rereadguide.setBackgroundResource(R.drawable.rereadguide);
    				absolute.addView(rereadguide,new AbsoluteLayout.LayoutParams(59,67, 75, -5));
    				rereadguide.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							Intent intent = new Intent();
							intent.setClass(getActivity(), Guide.class);
							startActivity(intent);
						}
    				});
    				
    				trunk.setImageResource(R.drawable.trunk1);
    				trunk.setX(0);
    				//trunk.setY(60);
    				//trunk3
    				//trunk.setY(15);
    				//absolute.addView(trunk, new LayoutParams(1280,1725));
    				//trunk1~5(���F3)
    				trunk.setY(-115);
    				absolute.addView(trunk, new LayoutParams(1280,1725));
    				
    				//likepic.getBackground().setAlpha(0);
    				likepic.setBackgroundResource(R.drawable.like);
    				//commentpic.getBackground().setAlpha(0);
    				commentpic.setBackgroundResource(R.drawable.comment);
    				//sharepic.getBackground().setAlpha(0);
    				sharepic.setBackgroundResource(R.drawable.share);
    				//tagpic.getBackground().setAlpha(0);
    				tagpic.setBackgroundResource(R.drawable.tag);
    				//messagepic.getBackground().setAlpha(0);
    				messagepic.setBackgroundResource(R.drawable.message);
    				//albumpic.getBackground().setAlpha(0);
    				albumpic.setBackgroundResource(R.drawable.album);
    				like.setText("�g");
    				like.setTextSize(24);
    				like.setTextColor(0xFFFFFFFF);
    				comment.setText("�d��");
    				comment.setTextSize(24);
    				comment.setTextColor(0xFFFFFFFF);
    				share.setText("����");
    				share.setTextSize(24);
    				share.setTextColor(0xFFFFFFFF);
    				tag.setText("����");
    				tag.setTextSize(24);
    				tag.setTextColor(0xFFFFFFFF);
    				message.setText("�T��");
    				message.setTextSize(24);
    				message.setTextColor(0xFFFFFFFF);
    				album.setText("��ï");
    				album.setTextSize(24);
    				album.setTextColor(0xFFFFFFFF);
    				likeframe.setText("0");
    				likeframe.setTextSize(45);
    				likeframe.setTextColor(0xFFFFFFFF);
    				likeframe.setGravity(Gravity.RIGHT);
    		        commentframe.setText("0");
    		        commentframe.setTextSize(45);
    		        commentframe.setTextColor(0xFFFFFFFF);
    		        commentframe.setGravity(Gravity.RIGHT);
    		        shareframe.setText("0");
    		        shareframe.setTextSize(45);
    		        shareframe.setTextColor(0xFFFFFFFF);
    		        shareframe.setGravity(Gravity.RIGHT);
    		        tagframe.setText("0");
    		        tagframe.setTextSize(45);
    		        tagframe.setTextColor(0xFFFFFFFF);
    		        tagframe.setGravity(Gravity.RIGHT);
    		        messageframe.setText("0");
    		        messageframe.setTextSize(45);
    		        messageframe.setTextColor(0xFFFFFFFF);
    		        messageframe.setGravity(Gravity.RIGHT);
    		        
    		        

					absolute.addView(likepic,new AbsoluteLayout.LayoutParams(60,60, 65, 795));
					absolute.addView(like,new AbsoluteLayout.LayoutParams(200,100, 128, 806));
					absolute.addView(commentpic,new AbsoluteLayout.LayoutParams(60,60, 300, 795));
					absolute.addView(comment,new AbsoluteLayout.LayoutParams(200,100, 363, 806));
					absolute.addView(sharepic,new AbsoluteLayout.LayoutParams(60,60, 540, 795));
					absolute.addView(share,new AbsoluteLayout.LayoutParams(200,100, 603, 806));
					absolute.addView(tagpic,new AbsoluteLayout.LayoutParams(60,60, 785, 795));
					absolute.addView(tag,new AbsoluteLayout.LayoutParams(200,100, 848, 806));
					absolute.addView(messagepic,new AbsoluteLayout.LayoutParams(60,60, 1025, 795));
					absolute.addView(message,new AbsoluteLayout.LayoutParams(200,100, 1088, 806));
					absolute.addView(albumpic,new AbsoluteLayout.LayoutParams(75,75, 66, 1120));
					absolute.addView(album,new AbsoluteLayout.LayoutParams(200,100, 139, 1139));
					absolute.addView(likeframe,new AbsoluteLayout.LayoutParams(50,50, 210, 860));
					absolute.addView(commentframe,new AbsoluteLayout.LayoutParams(50,50, 445, 860));
					absolute.addView(shareframe,new AbsoluteLayout.LayoutParams(50,50, 685, 860));
					absolute.addView(tagframe,new AbsoluteLayout.LayoutParams(50,50, 930, 860));
					absolute.addView(messageframe,new AbsoluteLayout.LayoutParams(50,50, 1170, 860));
					
					
					likebtn = new Button(getActivity());
					likebtn.getBackground().setAlpha(0);
    		        absolute.addView(likebtn,new AbsoluteLayout.LayoutParams(199,126, 70, 960));
    		        likebtn.setOnClickListener(new Button.OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							imgbtntemp = new ImageButton(getActivity());
							imgbtntemp.setBackgroundColor(0x00ffffff);
							absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
							imgbtntemp.setOnClickListener(new Button.OnClickListener(){
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									absolute.removeView(imgbtntemp);
									absolute.removeView(list);
								}
							});
							list = new ListView(getActivity());
				            ArrayList<String[]> alldata = new ArrayList<String[]>();
				            list.setAdapter(new MydataAdapter(getActivity(),alldata));
				            list.setTextFilterEnabled(true);
				            list.setOnItemClickListener(new OnItemClickListener() {
				    			@Override
				    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
				    				// TODO Auto-generated method stub
				    				
				    			}
				            });
				            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
						}
    		        });
					
    				
    				newspaperanimation = new AnimationSet(true);
        			newspaperanimation.setFillAfter(true);
        			newspaperrotation = null;
        			newspaperrotation = new RotateAnimation(0,1080,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        			newspaperrotation.setDuration(1000);
        			newspaperrotation.setFillAfter(true);
        			newspaperanimation.addAnimation(newspaperrotation);
				
        			newspapertranslation = null;
        			newspapertranslation = new TranslateAnimation(0,820-885,0,482-525);
        			newspapertranslation.setDuration(1000);
        			newspapertranslation.setFillAfter(true);
        			newspaperanimation.addAnimation(newspapertranslation);
        			
        			newspaperscale = null;
        			newspaperscale = new ScaleAnimation(0, 12, 0, 12);
        			newspaperscale.setDuration(1000);
        			newspaperscale.setFillAfter(true);
        			newspaperanimation.addAnimation(newspaperscale);
        			
    				newspaper = new ImageButton(getActivity());
					newspaper.setBackgroundResource(R.drawable.nonewspaper);
					absolute.addView(newspaper,new AbsoluteLayout.LayoutParams(120, 320, 835, 455));
					newspaper.setOnClickListener(new Button.OnClickListener(){

						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							imgbtntemp = new ImageButton(getActivity());
							imgbtntemp.setBackgroundColor(0x7f000000);
							//imgbtntemp.getBackground().setAlpha(255);
							absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
							newspaper.setBackgroundResource(R.drawable.nonewspaper);
							hotbackground = new ImageView(getActivity());
							hotbackground.setBackgroundResource(R.drawable.hotbackground);
							absolute.addView(hotbackground,new AbsoluteLayout.LayoutParams(90, 60, 885, 525));
							hotbackground.startAnimation(newspaperanimation);
							newspaperanimation.setAnimationListener(new Animation.AnimationListener() {
								@Override public void onAnimationStart(Animation animation) {
								}
								@Override public void onAnimationRepeat(Animation animation) {
								}
								@Override public void onAnimationEnd(Animation animation) {
									
									hotcontentborder = new TextView[10];
									hotinformation = new TextView[10];
									hotcontenttxt = new TextView[10];
									hotpic = new ImageView[10];
									
									for(int i=0;i<10;i++)
									{
										hotcontentborder[i] = new TextView(getActivity());
										hotinformation[i] = new TextView(getActivity());
										hotcontenttxt[i] = new TextView(getActivity());
										hotpic[i] = new ImageView(getActivity());
									}
									
									for(int i=0;i<=3;i++)
									{
										hotcontentborder[i].setText("");
										hotcontentborder[i].setTextSize(24);
										hotcontentborder[i].setBackgroundResource(R.drawable.textview_border);
										absolute.addView(hotcontentborder[i],new AbsoluteLayout.LayoutParams(240,240, 150+250*i, 120));
										if(hotid[i].equals("null"))
										{
											hotpic[i].setBackgroundResource(R.drawable.ic_launcher);
										}
										else
										{
										if(i==0)
										{
											GetXMLTask1 task1 = new GetXMLTask1();
											task1.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==1)
										{
											GetXMLTask2 task2 = new GetXMLTask2();
											task2.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==2)
										{
											GetXMLTask3 task3 = new GetXMLTask3();
											task3.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==3)
										{
											GetXMLTask4 task4 = new GetXMLTask4();
											task4.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										}
										//hotpic[i].setBackgroundResource(R.drawable.afternoon);
										absolute.addView(hotpic[i],new AbsoluteLayout.LayoutParams(230,230, 155+250*i, 125));
										hotpic[i].setAlpha(187);
										hotinformation[i].setTextSize(18);
										hotinformation[i].setTextColor(0xFFFFFFFF);
										hotinformation[i].setText(hotname[i] + "\n" + hottime[i]);
										absolute.addView(hotinformation[i],new AbsoluteLayout.LayoutParams(180,50, 180+250*i, 260));
										hotcontenttxt[i].setTextSize(18);
										hotcontenttxt[i].setTextColor(0xFFFFFFFF);
										hotcontenttxt[i].setText(hotcontent[i]);
										absolute.addView(hotcontenttxt[i],new AbsoluteLayout.LayoutParams(230,45, 160+250*i, 305));
									}
									for(int i=4;i<=7;i++)
									{
										hotcontentborder[i].setText("");
										hotcontentborder[i].setTextSize(24);
										hotcontentborder[i].setBackgroundResource(R.drawable.textview_border);
										absolute.addView(hotcontentborder[i],new AbsoluteLayout.LayoutParams(240,240, 150+250*(i-4), 400));
										if(hotid[i].equals("null"))
										{
											hotpic[i].setBackgroundResource(R.drawable.ic_launcher);
										}
										else
										{
										if(i==4)
										{
											GetXMLTask5 task5 = new GetXMLTask5();
											task5.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==5)
										{
											GetXMLTask6 task6 = new GetXMLTask6();
											task6.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==6)
										{
											GetXMLTask7 task7 = new GetXMLTask7();
											task7.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										else if(i==7)
										{
											GetXMLTask8 task8 = new GetXMLTask8();
											task8.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
										}
										}
										//hotpic[i].setBackgroundResource(R.drawable.afternoon);
										absolute.addView(hotpic[i],new AbsoluteLayout.LayoutParams(230,230, 155+250*(i-4), 405));
										hotpic[i].setAlpha(187);
										hotinformation[i].setTextSize(18);
										hotinformation[i].setTextColor(0xFFFFFFFF);
										hotinformation[i].setText(hotname[i] + "\n" + hottime[i]);
										absolute.addView(hotinformation[i],new AbsoluteLayout.LayoutParams(180,50, 180+250*(i-4), 540));
										hotcontenttxt[i].setTextSize(18);
										hotcontenttxt[i].setTextColor(0xFFFFFFFF);
										hotcontenttxt[i].setText(hotcontent[i]);
										absolute.addView(hotcontenttxt[i],new AbsoluteLayout.LayoutParams(230,45, 160+250*(i-4), 585));
									}
									
									
									btntemp = new Button(getActivity());
									btntemp.getBackground().setAlpha(0);
									btntemp.setBackgroundResource(R.drawable.x);
									absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(80,80, 1120, 5));
									btntemp.setOnClickListener(new Button.OnClickListener() {
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											for(int i=0;i<8;i++)
											{
												absolute.removeView(hotcontentborder[i]);
												absolute.removeView(hotinformation[i]);
												absolute.removeView(hotcontenttxt[i]);
												absolute.removeView(hotpic[i]);
												if(hotdoInBackgroundBitmap[i]!=null)
												{
													hotdoInBackgroundBitmap[i].recycle();
												}
												if(hotdownloadImageBitmap[i]!=null)
												{
													hotdownloadImageBitmap[i].recycle();
												}
											}
											absolute.removeView(imgbtntemp);
											absolute.removeView(btntemp);
											hotbackground.clearAnimation();
											absolute.removeView(hotbackground);
										}
									});
								}
							});
						}									
					});
    				
    				result = sendPostDataToInternet(uid,friendurl,0);
    				Log.i("result", result);
    				//webtext.setText(result);
    				try {
    					ja = JSONDecode();
    				} catch (JSONException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    				
    				fname = new String[10000];
                    fid = new String[10000];
                    sp = new int[10000];
                    content = new String[10000];
                    clicktime = new String[10000];
                    like_num = new int[10000];
                    comment_num = new int[10000];
                    mood = new int[10000];
                    havenotice = new int[10000];
                    havenoticeid = new String[10000];
    				
                    for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
    						fname[i] = jsonObject.getString("name");
    						fid[i] = jsonObject.getString("id");
    						sp[i] = jsonObject.getInt("social_point");
    						content[i] = jsonObject.getString("content");
    						clicktime[i] = mYear + "/" + formatter.format(realmMonth) + "/" + formatter.format(mDay) + " " +
    									formatter.format(mHour) + ":" + formatter.format(mMinutes) + ":" + formatter.format(msecond);
    			            like_num[i] = jsonObject.getInt("like_num");
    			            comment_num[i] = jsonObject.getInt("comment_num");
    			            mood[i] = jsonObject.getInt("mood");
    			            havenotice[i] = 0;
    					} catch (JSONException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}

                    }
    				
    				
                    
                    for(int i=0;i<15;i++) {
    		        	leafibtn[i] = new ImageButton(getActivity());
    		        	leafibtn[i].setId(CurrentButtonNumber);
    		        	CurrentButtonNumber++;
    		        	leafibtn[i].getBackground().setAlpha(0);
    		        	
    		        	
    		        	if(mood[i]==0)
    		        	{
    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
    		        	}
    		        	else if(mood[i]==-1)
    		        	{
    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
    		        	}
    		        	else if(mood[i]==-2)
    		        	{
    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
    		        	}
    		        	else if(mood[i]==1)
    		        	{
    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
    		        	}
    		        	else if(mood[i]==2)
    		        	{
    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
    		        	}
    		        	
    		        	leafibtn[i].setOnClickListener(testnewuser);
    		        	//leafibtn[i].setOnLongClickListener(test2);
    		        	//addView(����,�e�װ���)
    		        	if(i<52)
    		        	{
    		        		absolute.addView(leafibtn[i],new AbsoluteLayout.LayoutParams(60,60, leaf1x[i], leaf1y[i]));
    		        	}
    		        	else
    		        	{
    		        		absolute.addView(leafibtn[i],new AbsoluteLayout.LayoutParams(48,48, leaf1x[i], leaf1y[i]));
    		        	}
    		        }
                    
                    result = sendPostDataToInternet(uid,noticeurl,0);
        			try {
        				ja = JSONDecode2();
        			} catch (JSONException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        			noticefid = new String[ja.length()];
        			noticeevent = new String[ja.length()];
        			noticetypes = new String[ja.length()];
        			noticetypeid = new String[ja.length()];
        			noticecontent = new String[ja.length()];
        			personalnoticeevent = new String[150][ja.length()];
        			personalnoticetype = new String[150][ja.length()];
        			personalnoticetypeid = new String[150][ja.length()];
        			personalnoticecontent = new String[150][ja.length()];
        			noticenum = new int[150];
        			for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	noticefid[i] = jsonObject.getString("fid");
                        	noticeevent[i] = jsonObject.getString("event");
                        	noticetypes[i] = jsonObject.getString("type");
                        	noticetypeid[i] = jsonObject.getString("typeid");
                        	noticecontent[i] = jsonObject.getString("content");
        				} catch (JSONException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
                    }

        			for(int i=0;i<noticefid.length;i++)
        			{
        				
        				for(int j=0;j<15;j++)
        				{
        					if(noticefid[i].equals(fid[j]))
        					{
        						if(noticeevent[i].equals("like"))
    	        				{
    	        					likenum++;
    	        				}
    	        				else if(noticeevent[i].equals("com"))
    	        				{
    	        					commentnum++;
    	        				}
    	        				else if(noticeevent[i].equals("share"))
    	        				{
    	        					sharenum++;
    	        				}
    	        				else if(noticeevent[i].equals("tag"))
    	        				{
    	        					tagnum++;
    	        				}
    	        				else if(noticeevent[i].equals("msg"))
    	        				{
    	        					messagenum++;
    	        				}
        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
        						noticenum[j]++;
    							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
    							havenotice[j]=1;
    							//havenoticeid[j]=poid[i];
    						}
    					}
    				}
        			result = sendPostDataToInternet(uid,likerecordurl,0);
        			try {
        				ja = JSONDecode2();
        			} catch (JSONException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        			likerecordfid = new String[ja.length()];
        			likerecordevent = new String[ja.length()];
        			likerecordtypes = new String[ja.length()];
        			likerecordtypeid = new String[ja.length()];
        			likerecordcontent = new String[ja.length()];
        			for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	likerecordfid[i] = jsonObject.getString("fid");
                        	likerecordevent[i] = jsonObject.getString("event");
                        	likerecordtypes[i] = jsonObject.getString("type");
                        	likerecordtypeid[i] = jsonObject.getString("typeid");
                        	likerecordcontent[i] = jsonObject.getString("content");
        				} catch (JSONException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
                    }
        			result = sendPostDataToInternet(uid,commentrecordurl,0);
        			try {
        				ja = JSONDecode2();
        			} catch (JSONException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        			commentrecordfid = new String[ja.length()];
        			commentrecordevent = new String[ja.length()];
        			commentrecordtypes = new String[ja.length()];
        			commentrecordtypeid = new String[ja.length()];
        			commentrecordcontent = new String[ja.length()];
        			for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	commentrecordfid[i] = jsonObject.getString("fid");
                        	commentrecordevent[i] = jsonObject.getString("event");
                        	commentrecordtypes[i] = jsonObject.getString("type");
                        	commentrecordtypeid[i] = jsonObject.getString("typeid");
                        	commentrecordcontent[i] = jsonObject.getString("content");
        				} catch (JSONException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
                    }
        			result = sendPostDataToInternet(uid,tagrecordurl,0);
        			try {
        				ja = JSONDecode2();
        			} catch (JSONException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        			tagrecordfid = new String[ja.length()];
        			tagrecordevent = new String[ja.length()];
        			tagrecordtypes = new String[ja.length()];
        			tagrecordtypeid = new String[ja.length()];
        			tagrecordcontent = new String[ja.length()];
        			for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	tagrecordfid[i] = jsonObject.getString("fid");
                        	tagrecordevent[i] = jsonObject.getString("event");
                        	tagrecordtypes[i] = jsonObject.getString("type");
                        	tagrecordtypeid[i] = jsonObject.getString("typeid");
                        	tagrecordcontent[i] = jsonObject.getString("content");
        				} catch (JSONException e) {
        					// TODO Auto-generated catch block
        					e.printStackTrace();
        				}
                    }
        			if(likenum>0)
        			{
        				likeibtn = new ImageButton(getActivity());
    					likeibtn.getBackground().setAlpha(0);
	    		        likeibtn.setBackgroundResource(R.drawable.likes);
	    		        absolute.addView(likeibtn,new AbsoluteLayout.LayoutParams(199,126, 70, 960));
	    		        likeibtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(likeibtn);
										absolute.removeView(list);
									}
								});
								likenum=0;
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            likeframe.setText(String.valueOf(likenum));
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
        			}
        			if(commentnum>0)
        			{
        				commentibtn = new ImageButton(getActivity());
    					commentibtn.getBackground().setAlpha(0);
	    		        commentibtn.setBackgroundResource(R.drawable.comments);
	    		        absolute.addView(commentibtn,new AbsoluteLayout.LayoutParams(199,126, 305, 960));
	    		        commentibtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(commentibtn);
										absolute.removeView(list);
									}
								});
								commentnum=0;
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            commentframe.setText(String.valueOf(commentnum));
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
        			}
        			if(sharenum>0)
        			{
        				shareibtn = new ImageButton(getActivity());
    					shareibtn.getBackground().setAlpha(0);
	    		        shareibtn.setBackgroundResource(R.drawable.shares);
	    		        absolute.addView(shareibtn,new AbsoluteLayout.LayoutParams(199,126, 545, 960));
	    		        shareibtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(shareibtn);
										absolute.removeView(list);
									}
								});
								sharenum=0;
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            shareframe.setText(String.valueOf(sharenum));
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
        			}
        			if(tagnum>0)
        			{
        				tagibtn = new ImageButton(getActivity());
    					tagibtn.getBackground().setAlpha(0);
	    		        tagibtn.setBackgroundResource(R.drawable.tags);
	    		        absolute.addView(tagibtn,new AbsoluteLayout.LayoutParams(199,126, 790, 960));
	    		        tagibtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(tagibtn);
										absolute.removeView(list);
									}
								});
								tagnum=0;
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            tagframe.setText(String.valueOf(tagnum));
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
        			}
        			if(messagenum>0)
        			{
        				messageibtn = new ImageButton(getActivity());
    					messageibtn.getBackground().setAlpha(0);
	    		        messageibtn.setBackgroundResource(R.drawable.messages);
	    		        absolute.addView(messageibtn,new AbsoluteLayout.LayoutParams(199,126, 1030, 960));
	    		        messageibtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(messageibtn);
										absolute.removeView(list);
									}
								});
								messagenum=0;
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            messageframe.setText(String.valueOf(messagenum));
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
        			}
        			likeframe.setText(String.valueOf(likenum));
        			commentframe.setText(String.valueOf(commentnum));
        			shareframe.setText(String.valueOf(sharenum));
        			tagframe.setText(String.valueOf(tagnum));
        			messageframe.setText(String.valueOf(messagenum));
        			
                    
                    CurrentButtonNumber=0;
                    result = sendPostDataToInternet(uid,recommendurl,0);
                    try {
    					ja = JSONDecode2();
    				} catch (JSONException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
                    
                    recommendid = new String[ja.length()];
                    
                    for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	recommendid[i] = jsonObject.getString("recommendid");
    					} catch (JSONException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}
                    }
                    
                    for(int i=0;i<recommendid.length;i++)
                    {
                    	if(recommendid.length<6)
                    	{
	                    	recommendibtn[i] = new ImageButton(getActivity());
	                    	recommendibtn[i].setId(CurrentButtonNumber);
	    		        	CurrentButtonNumber++;
	    		        	recommendibtn[i].getBackground().setAlpha(0);
	    		        	recommendibtn[i].setBackgroundResource(R.drawable.newfriend);
	    		        	recommendibtn[i].setOnClickListener(recommendwindow);
	    		        	absolute.addView(recommendibtn[i],new AbsoluteLayout.LayoutParams(40,40, recommendfriend1x[i], recommendfriend1y[i]));
                    	}
                    }
                    
                    
                    result = sendPostDataToInternet(uid,hoturl,0);
    				Log.i("result", result);
    				//webtext.setText(result);
    				try {
    					ja = JSONDecode2();
    				} catch (JSONException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}

                    hotname = new String[10];
                    hotid = new String[10];
                    hottime = new String[10];
                    hotcontent = new String[10];
                    hot_like_num = new int[10];
                    hot_comment_num = new int[10];

                    for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
    						
    						hotname[i] = jsonObject.getString("name");
    						hotid[i] = jsonObject.getString("id");
    						hottime[i] = jsonObject.getString("time");
    						hotcontent[i] = jsonObject.getString("content");
    						hot_like_num[i] = jsonObject.getInt("like_num");
    						hot_comment_num[i] = jsonObject.getInt("comment_num");
    					} catch (JSONException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}

                    }
                    
                    
                    result = sendPostDataToInternet(uid,albumlisturl,0);
                    //name,time,picurl,id;
                    try {
    					ja = JSONDecodeAlbumlist();
    				} catch (JSONException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
                    albumlistname = new String[ja.length()];
                    albumlisttime = new String[ja.length()];
                    albumlistpicurl = new String[ja.length()];
                    albumlistid = new String[ja.length()];
                    for (int i = 0; i < ja.length(); i++) {
                        try {
                        	JSONObject jsonObject = ja.getJSONObject(i);
                        	albumlistname[i] = jsonObject.getString("name");
                        	albumlisttime[i] = jsonObject.getString("time");
                        	albumlistpicurl[i] = jsonObject.getString("picurl");
                        	albumlistid[i] = jsonObject.getString("id");
    					} catch (JSONException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}
                    }
                    
                    if(albumlistname[0].equals("null"))
                    {
	                    
                    }
                    else
                    {
                    	List<ImageAndText> gridviewlist = new ArrayList<ImageAndText>();
	                    
	    		        for(int i=0;i<albumlistname.length;i++)
	    		        {
	    		        	//String[] splitid = albumlistid[i].split(".");
	    		        	if(albumlistid[i].contains("."))
	    		        	{
	    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], "�@�P��ï�G" + albumlistname[i] + "\n" + albumlisttime[i]));
	    		        	}
	    		        	else
	    		        	{
	    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], albumlistname[i] + "\n" + albumlisttime[i]));
	    		        	}
	    		        }
	    		        absolute.addView(horizonsv,new AbsoluteLayout.LayoutParams(1140,250, 65, 1225));
	    		        horizonsv.addView(fl,new HorizontalScrollView.LayoutParams(1140,250));
	    				mPhotoWall.setColumnWidth(270);
	    				mPhotoWall.setStretchMode(2);//STRETCH_COLUMN_WIDTH
	    				mPhotoWall.setNumColumns(albumlistname.length);
	    				mPhotoWall.setVerticalSpacing(20);
	    				mPhotoWall.setGravity(Gravity.CENTER);
	    				fl.addView(mPhotoWall,new FrameLayout.LayoutParams(285*albumlistname.length,250));
	    				//absolute.addView(mPhotoWall,new AbsoluteLayout.LayoutParams(1160,200, 60, 1225));
	    				mPhotoWall.setAdapter(new ImageAndTextListAdapter(getActivity(), gridviewlist, mPhotoWall, 1));
	    				mPhotoWall.setOnItemClickListener(new OnItemClickListener(){
							@Override
							public void onItemClick(AdapterView<?> arg0, View arg1, int position, long locategridview) {
								// TODO Auto-generated method stub
								Intent intent = new Intent();
								intent.setClass(getActivity(), Albumpic.class);
								// �إ� Bundle ����
					            Bundle bundle = new Bundle();
					            bundle.putString("albumid", albumlistid[position]);
					            // �N Bundle ���w�� Intent
					            intent.putExtras(bundle);
								startActivity(intent);
							}
	    				});
                    }
                    
                    
                    
                    inout = 1;

            		
            		
            		clearbutton.setBackgroundResource(R.drawable.clearnotice);
            		//absolute.addView(clearbutton,new AbsoluteLayout.LayoutParams(74,84, 50, 600));
            		clearbutton.setOnClickListener(new Button.OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							for(int i=0;i<5;i++)
							{
								noticetype[i].setBackgroundResource(R.drawable.like);
							}
							absolute.addView(noticetype[0],new AbsoluteLayout.LayoutParams(70,70, noticex[0], noticey[0]));
							
							noticetranslation = null;
		        			noticetranslation = new TranslateAnimation(0,noticex[1]-noticex[0],0,noticey[1]-noticey[0]);
		        			noticetranslation.setDuration(800);
		        			noticetranslation.setFillAfter(true);
		        			
							noticeanimation = new AnimationSet(true);
							noticeanimation.setFillAfter(true);
							noticerotationset1 = null;
							noticerotationset1 = new RotateAnimation(0,720,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
							noticerotationset1.setDuration(1500);
							noticerotationset1.setFillAfter(true);
							noticeanimation.addAnimation(noticerotationset1);
							noticetranslationset1 = null;
		        			noticetranslationset1 = new TranslateAnimation(0,noticex[2]-noticex[1],0,noticey[2]-noticey[1]);
		        			noticetranslationset1.setDuration(1500);
		        			noticetranslationset1.setFillAfter(true);
		        			noticeanimation.addAnimation(noticetranslationset1);
		        			
		        			noticeanimation2 = new AnimationSet(true);
							noticeanimation2.setFillAfter(true);
							noticerotationset2 = null;
							noticerotationset2 = new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
							noticerotationset2.setDuration(1000);
							noticerotationset2.setFillAfter(true);
							noticeanimation2.addAnimation(noticerotationset2);
							noticetranslationset2 = null;
		        			noticetranslationset2 = new TranslateAnimation(0,noticex[3]-noticex[2],0,noticey[3]-noticey[2]);
		        			noticetranslationset2.setDuration(1000);
		        			noticetranslationset2.setFillAfter(true);
		        			noticeanimation2.addAnimation(noticetranslationset2);
		        			
		        			noticetranslation2 = null;
		        			noticetranslation2 = new TranslateAnimation(0,noticex[4]-noticex[3],0,noticey[4]-noticey[3]);
		        			noticetranslation2.setDuration(1000);
		        			noticetranslation2.setFillAfter(true);

		        			noticetype[0].startAnimation(noticetranslation);
		        			noticetranslation.setAnimationListener(new Animation.AnimationListener() {
								@Override public void onAnimationStart(Animation animation) {
								}
								@Override public void onAnimationRepeat(Animation animation) {
								}
								@Override public void onAnimationEnd(Animation animation) {
									absolute.removeView(noticetype[0]);
									absolute.addView(noticetype[1],new AbsoluteLayout.LayoutParams(70,70, noticex[1], noticey[1]));
									noticetype[1].startAnimation(noticeanimation);
									noticeanimation.setAnimationListener(new Animation.AnimationListener() {
										@Override public void onAnimationStart(Animation animation2) {
										}
										@Override public void onAnimationRepeat(Animation animation2) {
										}
										@Override public void onAnimationEnd(Animation animation2) {
											absolute.removeView(noticetype[1]);
											absolute.addView(noticetype[2],new AbsoluteLayout.LayoutParams(70,70, noticex[2], noticey[2]));
											noticetype[2].startAnimation(noticeanimation2);
											noticeanimation2.setAnimationListener(new Animation.AnimationListener() {
												@Override public void onAnimationStart(Animation animation3) {
												}
												@Override public void onAnimationRepeat(Animation animation3) {
												}
												@Override public void onAnimationEnd(Animation animation3) {
													absolute.removeView(noticetype[2]);
													absolute.addView(noticetype[3],new AbsoluteLayout.LayoutParams(70,70, noticex[3], noticey[3]));
													noticetype[3].startAnimation(noticetranslation2);
													noticetranslation2.setAnimationListener(new Animation.AnimationListener() {
														@Override public void onAnimationStart(Animation animation4) {
														}
														@Override public void onAnimationRepeat(Animation animation4) {
														}
														@Override public void onAnimationEnd(Animation animation4) {
															absolute.removeView(noticetype[3]);
															//absolute.addView(noticetype[4],new AbsoluteLayout.LayoutParams(70,70, noticex[4], noticey[4]));
														}
								        			});
												}
						        			});
										}
				        			});
								}
		        			});
							
							
						}
            			
            		});
    				
            		//GetXMLTaskMyself taskmyself = new GetXMLTaskMyself();
    				//taskmyself.execute(new String[] { "http://graph.facebook.com/" + uid + "/picture" });
    				if(newuser==0)
    				{
    					absolute.addView(myself,new AbsoluteLayout.LayoutParams(70,70, 675, 550));
    				}
    				else
    				{
    					absolute.addView(myself,new AbsoluteLayout.LayoutParams(70,70, 675, 590));
    				}
    				myselfclick.setBackgroundColor(0x00ffffff);
    				if(newuser==0)
    				{
    					absolute.addView(myselfclick,new AbsoluteLayout.LayoutParams(70,70, 675, 550));
    				}
    				else
    				{
    					absolute.addView(myselfclick,new AbsoluteLayout.LayoutParams(70,70, 675, 590));
    				}
    				
    				myselfclick.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							/*imgbtntemp = new ImageButton(getActivity());
							imgbtntemp.setBackgroundColor(0x00ffffff);
							absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
							imgbtntemp.setOnClickListener(new Button.OnClickListener(){
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									absolute.removeView(imgbtntemp);
								}
							});*/
							
							PopupMenu menu = new PopupMenu(getActivity(), v);
							for(int i=0;i<15;i++)
							{
								menu.getMenu().add(0, i, 0, fname[i]);
							}
					        menu.show();
					        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
								@Override
								public boolean onMenuItemClick(MenuItem arg0) {
									// TODO Auto-generated method stub
									friendnow = arg0.getItemId();

							    		mempic = new ImageView(getActivity());
							    		replacepic = new ImageView(getActivity());
							    		wallnewsframe = new TextView(getActivity());
							    		wallnews = new TextView(getActivity());
							    		liketemp = new ImageView(getActivity());
							    		liketempnumandlink = new Button(getActivity());
							    		commenttemp = new ImageView(getActivity());
							    		commenttempunmandlink = new Button(getActivity());
										underline = new TextView(getActivity());
										memname = new TextView(getActivity());
										meminfo = new TextView(getActivity());
										talkpic = new ImageView(getActivity());
										talk = new Button(getActivity());
										left = new ImageButton(getActivity());
										right = new ImageButton(getActivity());
										gotochat = new Button(getActivity());
							    	
										imgbtntemp = new ImageButton(getActivity());
										imgbtntemp.setBackgroundColor(0x7f000000);
										//imgbtntemp.getBackground().setAlpha(255);
										absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
										
										
										
										friendanimation = new AnimationSet(true);
										friendanimation.setFillAfter(true);
										friendtranslation = null;
										friendtranslation = new TranslateAnimation(0,875-leaf1x[arg0.getItemId()],0,300-leaf1y[arg0.getItemId()]);
										friendtranslation.setDuration(500);
										friendtranslation.setFillAfter(true);
										friendanimation.addAnimation(friendtranslation);
										
										friendscale = null;
										friendscale = new ScaleAnimation(0, 1, 0, 1);
										friendscale.setDuration(500);
										friendscale.setFillAfter(true);
										friendanimation.addAnimation(friendscale);

										
										friendbackground = new ImageView(getActivity());
										friendbackground.setBackgroundResource(R.drawable.friendbackground);
							    		absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, leaf1x[arg0.getItemId()], leaf1y[arg0.getItemId()]));
							    		friendbackground.startAnimation(friendanimation);
							    		friendanimation.setAnimationListener(new Animation.AnimationListener() {
											@Override public void onAnimationStart(Animation animation) {
											}
											@Override public void onAnimationRepeat(Animation animation) {
											}
											@Override public void onAnimationEnd(Animation animation) {
												//mempic.setBackgroundResource(R.drawable.dusk);
												if(mood[friendnow]==0)
									        	{
													replacepic.setBackgroundResource(R.drawable.normalb);
									        	}
									        	else if(mood[friendnow]==-1)
									        	{
									        		replacepic.setBackgroundResource(R.drawable.badb);
									        	}
									        	else if(mood[friendnow]==-2)
									        	{
									        		replacepic.setBackgroundResource(R.drawable.worstb);
									        	}
									        	else if(mood[friendnow]==1)
									        	{
									        		replacepic.setBackgroundResource(R.drawable.goodb);
									        	}
									        	else if(mood[friendnow]==2)
									        	{
									        		replacepic.setBackgroundResource(R.drawable.bestb);
									        	}
												if(friendnow<52)
												{
													absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(60,60, leaf1x[friendnow], leaf1y[friendnow]));
												}
												else
												{
													absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(48,48, leaf1x[friendnow], leaf1y[friendnow]));
												}
												absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, 875, 240));
												//absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, leaf3x[friendnow]-4, leaf3y[friendnow]-4));
												// Create an object for subclass of AsyncTask
										        GetXMLTask task = new GetXMLTask();
										        // Execute the task
										        task.execute(new String[] { "http://graph.facebook.com/" + fid[friendnow] + "/picture" });
												
												/*underline.setText("                                                                                                       ");
												underline.setTextSize(24);
												underline.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
												absolute.addView(underline,new AbsoluteLayout.LayoutParams(700,100, 340, 220));*/
											
										        //wallnewsframe.setText(content[friendnow] + "\n\n\n  like = " + like_num[friendnow] + "	  comment = " + comment_num[friendnow]);
										        wallnewsframe.setTextSize(24);
										        wallnewsframe.setTextColor(0xFFFFFFFF);
										        wallnewsframe.setBackgroundResource(R.drawable.textview_border);
												absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
												
												wallnews.setText(content[friendnow]);
										        wallnews.setTextSize(18);
										        wallnews.setTextColor(0xFFFFFFFF);
										        //wallnewsframe.setBackgroundResource(R.drawable.textview_border);
												absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
												
												if(mood[friendnow]<0)
												{
													liketemp.setBackgroundResource(R.drawable.pat);
													absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
												}
												else
												{
													liketemp.setBackgroundResource(R.drawable.like);
													absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
												}
												liketempnumandlink.getBackground().setAlpha(0);
												liketempnumandlink.setText(String.valueOf(like_num[friendnow]));
												liketempnumandlink.setTextSize(18);
												liketempnumandlink.setTextColor(0xFFFFFFFF);
												absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
												commenttemp.setBackgroundResource(R.drawable.comment);
												absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
												commenttempunmandlink.getBackground().setAlpha(0);
												commenttempunmandlink.setText(String.valueOf(comment_num[friendnow]));
												commenttempunmandlink.setTextSize(18);
												commenttempunmandlink.setTextColor(0xFFFFFFFF);
												absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
											
												talkpic.setBackgroundResource(R.drawable.message);
												absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
												talk.getBackground().setAlpha(0);
												talk.setText("���˸��D");
												talk.setTextSize(18);
												talk.setTextColor(0xFFFFFFFF);
												absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
												talk.setOnClickListener(new Button.OnClickListener(){
													@Override
													public void onClick(View arg0) {
														// TODO Auto-generated method stub
														if(talkopencondition==0)
														{
															personhotcontent = sendPostDataToInternet(fid[friendnow],personalhoturl,1);
															absolute.removeView(friendbackground);
															absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,450, 875, 300));
															absolute.removeView(wallnewsframe);
															absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
															absolute.removeView(wallnews);
															absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
															absolute.removeView(liketemp);
															if(mood[friendnow]<0)
															{
																absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
															}
															else
															{
																absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
															}
															absolute.removeView(liketempnumandlink);
															absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
															absolute.removeView(commenttemp);
															absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
															absolute.removeView(commenttempunmandlink);
															absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
															absolute.removeView(talkpic);
															absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
															absolute.removeView(talk);
															absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
															absolute.removeView(btntemp);
															absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
															talkbackground = new ImageView(getActivity());
															talkbackground.setBackgroundResource(R.drawable.talkbackground);
															absolute.addView(talkbackground,new AbsoluteLayout.LayoutParams(330,190, 885, 555));
															talkframe = new TextView(getActivity());
															//if(personhotcontent.toString().equals(0))
															if(personhotcontent.equals(""))
															{
																talkframe.setText("�A���n�B�ͪ���S���o���!!\n���֥h���ߥL�a");
															}
															else
															{
																talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
															}
															talkframe.setTextSize(18);
															absolute.addView(talkframe,new AbsoluteLayout.LayoutParams(290,110, 905, 575));
															left.setBackgroundResource(R.drawable.left);
															absolute.addView(left,new AbsoluteLayout.LayoutParams(25,25, 1155, 550));
															left.setOnClickListener(new Button.OnClickListener(){
																@Override
																public void onClick(View v) {
																	// TODO Auto-generated method stub
																	newsindex--;
																	if(newsindex<0)
																	{
																		newsindex=0;
																	}
																	if(newsindex!=0)
																	{
																		talkframe.setText(newstemp[newsindex-1]);
																	}
																	else
																	{
																		talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
																	}
																}
															});
															right.setBackgroundResource(R.drawable.right);
															absolute.addView(right,new AbsoluteLayout.LayoutParams(25,25, 1180, 550));
															right.setOnClickListener(new Button.OnClickListener(){
																@Override
																public void onClick(View v) {
																	// TODO Auto-generated method stub
																	newsindex++;
																	if(newsindex>newstemp.length)
																	{
																		newsindex=newstemp.length;
																	}
																	if(newsindex!=0)
																	{
																		talkframe.setText(newstemp[newsindex-1]);
																	}
																	else
																	{
																		talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
																	}
																}
															});
															gotochat.setText("Go to chat");
															gotochat.getBackground().setAlpha(0);
															absolute.addView(gotochat,new AbsoluteLayout.LayoutParams(200,50, 1050, 685));
															gotochat.setOnClickListener(new Button.OnClickListener(){
																@Override
																public void onClick(View arg0) {
																	// TODO Auto-generated method stub
																	String url="http://www.facebook.com/messages/" + fid[friendnow];
																	Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
																	startActivity(ie);
																}
															});
															talkopencondition=1;
														}
														else
														{
															absolute.removeView(friendbackground);
															absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, 875, 300));
															absolute.removeView(wallnewsframe);
															absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
															absolute.removeView(wallnews);
															absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
															absolute.removeView(liketemp);
															if(mood[friendnow]<0)
															{
																absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
															}
															else
															{
																absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
															}
															absolute.removeView(liketempnumandlink);
															absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
															absolute.removeView(commenttemp);
															absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
															absolute.removeView(commenttempunmandlink);
															absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
															absolute.removeView(talkpic);
															absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
															absolute.removeView(talk);
															absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
															absolute.removeView(btntemp);
															absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
															absolute.removeView(talkbackground);
															absolute.removeView(talkframe);
															absolute.removeView(left);
															absolute.removeView(right);
															absolute.removeView(gotochat);
															talkopencondition=0;
														}
													}
												});
												
											
												memname.setText(fname[friendnow]);
												memname.setTextSize(30);
												memname.setTextColor(0xFFFFFFFF);
												absolute.addView(memname,new AbsoluteLayout.LayoutParams(350,50, 940, 255));
											
												//meminfo.setText("�ʧO\n�ͤ�\n�u�@\n�s��\n���NŪ");
												//meminfo.setTextSize(18);
												//absolute.addView(meminfo,new AbsoluteLayout.LayoutParams(200,200, 360, 440));


												
												btntemp = new Button(getActivity());
												btntemp.getBackground().setAlpha(0);

												btntemp.setBackgroundResource(R.drawable.x);
												absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
												btntemp.setOnClickListener(new Button.OnClickListener() {
													@Override
													public void onClick(View arg0) {
														// TODO Auto-generated method stub
														absolute.removeView(friendbackground);
														absolute.removeView(imgbtntemp);
														absolute.removeView(btntemp);
														absolute.removeView(mempic);
														absolute.removeView(replacepic);
														absolute.removeView(wallnewsframe);
														absolute.removeView(wallnews);
														absolute.removeView(liketemp);
														absolute.removeView(liketempnumandlink);
														absolute.removeView(commenttemp);
														absolute.removeView(commenttempunmandlink);
														//absolute.removeView(underline);
														absolute.removeView(talkpic);
														absolute.removeView(talk);
														if(talkopencondition==1)
														{
															absolute.removeView(talkbackground);
															absolute.removeView(talkframe);
															talkopencondition=0;
															absolute.removeView(left);
															absolute.removeView(right);
															absolute.removeView(gotochat);
														}
														absolute.removeView(memname);
														newsindex=0;
														downloadImageBitmap.recycle();
														doInBackgroundBitmap.recycle();
														outputBitmap.recycle();
														//absolute.removeView(updatewall);
														//absolute.removeView(meminfo);
													}
													
												});
											}
										});	

									return false;
								}						        	
					        });
						}
					});
    				
    				
    				
            		tipclick[0] = new ImageButton(getActivity());
    				tipclick[0].setBackgroundColor(0x00ffffff);
    				tipclick[1] = new ImageButton(getActivity());
    				tipclick[1].setBackgroundColor(0x00ffffff);
					tip[0].setBackgroundResource(R.drawable.tip2);
					tip[1].setBackgroundResource(R.drawable.tip3);
					absolute.addView(tipclick[0],new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
					absolute.addView(tip[0],new AbsoluteLayout.LayoutParams(415,222, 750, 500));
					tipclick[0].setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							absolute.removeView(tipclick[0]);
							absolute.removeView(tip[0]);
							absolute.addView(tipclick[1],new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
							absolute.addView(tip[1],new AbsoluteLayout.LayoutParams(406,217, 870, 225));
							tipclick[1].setOnClickListener(new Button.OnClickListener(){
								@Override
								public void onClick(View v) {
									// TODO Auto-generated method stub
									absolute.removeView(tipclick[1]);
									absolute.removeView(tip[1]);
								}
							});
						}
					});
        		}
        		
        		if(msecond%2==0)
        		{
        			/*for(int i=0;i<8;i++)
					{
	        			if(hotdoInBackgroundBitmap[i]!=null)
						{
							hotdoInBackgroundBitmap[i].recycle();
						}
						if(hotdownloadImageBitmap[i]!=null)
						{
							hotdownloadImageBitmap[i].recycle();
						}
					}
        			for(int i=0;i<groupdownloadImageBitmap.length;i++)
					{
						if(groupdoInBackgroundBitmap[i]!=null)
						{
							groupdoInBackgroundBitmap[i].recycle();
						}
						if(groupdownloadImageBitmap[i]!=null)
						{
							groupdownloadImageBitmap[i].recycle();
						}
						if(groupoutputBitmap[i]!=null)
						{
							groupoutputBitmap[i].recycle();
						}
					}*/
        			System.gc();
        		}
        		if(inout==1){
        			webtext.setText(formatter.format(mHour) + ":" + formatter.format(mMinutes));
        			//webtext.setTextColor(0xffffffff);
            		webtext.setTextSize(70);
            		date.setText(formatter.format(mYear) + "/" + formatter.format(realmMonth) + "/" + formatter.format(mDay) + " " + realmWeek);
            		date.setTextSize(25);
            		
	        		if(mHour>=5 && mHour<10){
	        			/*addrain = 0;
	        			rain[0].clearAnimation();
	        			rain[1].clearAnimation();
						absolute.removeView(rain[0]);
						absolute.removeView(rain[1]);*/
				        absolute.setBackgroundResource(R.drawable.morning);
					}
					else if(mHour>=10 && mHour<16){
						absolute.setBackgroundResource(R.drawable.afternoon);
					}
					else if(mHour>=16 && mHour<18){
						absolute.setBackgroundResource(R.drawable.dusk);
					}
					else{
						absolute.setBackgroundResource(R.drawable.night);
					}
	        		
	        		if(mMinutes%60==0 && updatecondition==0)
	        		{
	    				updatedata60.loadUrl("http://apps.facebook.com/bookroyt?time=60");
	    				Log.e("tttttttttttttt60", "up60");
	    				updatecondition=1;
	        		}
	        		else if(mMinutes%10==0 && updatecondition==0)
	        		{
	        			updatedata10.loadUrl("http://apps.facebook.com/bookroyt?time=10");
	        			Log.e("tttttttttttttt10", "up10");
	        			updatecondition=1;
	        			
	        			
	        			
	        			
	        		}
	        		else if(mMinutes%10==9)
	        		{
	        			updatecondition=0;
	        		}
	        		if(mMinutes==0 && msecond==0)
	        		{
	        			Log.e("tttttttttttttt", "up");
	        			updatedata.loadUrl("http://apps.facebook.com/bookroyt");
	        		}
	        		
	        		if(mMinutes%2==0 && downloaddatacondition==0)
	        		{
	        			result = sendPostDataToInternet(uid,friendurl,0);
	        			Log.i("result", result);
	        			//webtext.setText(result);
	        			try {
	        				ja = JSONDecode();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	        					fname[i] = jsonObject.getString("name");
	        					fid[i] = jsonObject.getString("id");
	        					sp[i] = jsonObject.getInt("social_point");
	        					content[i] = jsonObject.getString("content");
	        		            like_num[i] = jsonObject.getInt("like_num");
	        		            comment_num[i] = jsonObject.getInt("comment_num");
	        		            mood[i] = jsonObject.getInt("mood");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			if(newuser==0){
	        			for(int i=0;i<150;i++)
	        			{
	        				if(mood[i]==0)
	    		        	{
	        					leafibtn[i].setBackgroundResource(R.drawable.normalb);
	    		        	}
	    		        	else if(mood[i]==-1)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
	    		        	}
	    		        	else if(mood[i]==-2)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
	    		        	}
	    		        	else if(mood[i]==1)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
	    		        	}
	    		        	else if(mood[i]==2)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
	    		        	}
	        			}
	        			}
	        			else
	        			{
	        				for(int i=0;i<15;i++)
		        			{
		        				if(mood[i]==0)
		    		        	{
		        					leafibtn[i].setBackgroundResource(R.drawable.normalb);
		    		        	}
		    		        	else if(mood[i]==-1)
		    		        	{
		    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
		    		        	}
		    		        	else if(mood[i]==-2)
		    		        	{
		    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
		    		        	}
		    		        	else if(mood[i]==1)
		    		        	{
		    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
		    		        	}
		    		        	else if(mood[i]==2)
		    		        	{
		    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
		    		        	}
		        			}
	        			}
	        			
	        			
	        			result = sendPostDataToInternet(uid,noticeurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			noticefid = new String[ja.length()];
	        			noticeevent = new String[ja.length()];
	        			noticetypes = new String[ja.length()];
	        			noticetypeid = new String[ja.length()];
	        			noticecontent = new String[ja.length()];
	        			personalnoticeevent = new String[150][ja.length()];
	        			personalnoticetype = new String[150][ja.length()];
	        			personalnoticetypeid = new String[150][ja.length()];
	        			personalnoticecontent = new String[150][ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	noticefid[i] = jsonObject.getString("fid");
	                        	noticeevent[i] = jsonObject.getString("event");
	                        	noticetypes[i] = jsonObject.getString("type");
	                        	noticetypeid[i] = jsonObject.getString("typeid");
	                        	noticecontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			
	        			absolute.removeView(likeibtn);
	        			absolute.removeView(commentibtn);
	        			absolute.removeView(shareibtn);
	        			absolute.removeView(tagibtn);
	        			absolute.removeView(messageibtn);
	        			likenum=0;
	        			commentnum=0;
	        			sharenum=0;
	        			tagnum=0;
	        			messagenum=0;
	        			for(int i=0;i<150;i++)
	        			{
	        				noticenum[i]=0;
	        			}
	        			if(newuser==0){
	        			for(int i=0;i<noticefid.length;i++)
	        			{
	        				for(int j=0;j<150;j++)
	        				{
	        					if(noticefid[i].equals(fid[j]))
	        					{
	        						if(noticeevent[i].equals("like"))
	    	        				{
	    	        					likenum++;
	    	        					
	    	        				}
	    	        				else if(noticeevent[i].equals("com"))
	    	        				{
	    	        					commentnum++;
	    	        					
	    	        				}
	    	        				else if(noticeevent[i].equals("share"))
	    	        				{
	    	        					sharenum++;
	    	        					
	    	        				}
	    	        				else if(noticeevent[i].equals("tag"))
	    	        				{
	    	        					tagnum++;
	    	        					
	    	        				}
	    	        				else if(noticeevent[i].equals("msg"))
	    	        				{
	    	        					messagenum++;
	    	        					
	    	        				}
	        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
	        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
	        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
	        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
	        						noticenum[j]++;
        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
        							havenotice[j]=1;
        							//havenoticeid[j]=poid[i];
        						}
        					}
        				}
	        			}
	        			else
	        			{
	        				for(int i=0;i<noticefid.length;i++)
		        			{
		        				for(int j=0;j<15;j++)
		        				{
		        					if(noticefid[i].equals(fid[j]))
		        					{
		        						if(noticeevent[i].equals("like"))
		    	        				{
		    	        					likenum++;
		    	        					
		    	        				}
		    	        				else if(noticeevent[i].equals("com"))
		    	        				{
		    	        					commentnum++;
		    	        					
		    	        				}
		    	        				else if(noticeevent[i].equals("share"))
		    	        				{
		    	        					sharenum++;
		    	        					
		    	        				}
		    	        				else if(noticeevent[i].equals("tag"))
		    	        				{
		    	        					tagnum++;
		    	        					
		    	        				}
		    	        				else if(noticeevent[i].equals("msg"))
		    	        				{
		    	        					messagenum++;
		    	        					
		    	        				}
		        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
		        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
		        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
		        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
		        						noticenum[j]++;
	        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
	        							havenotice[j]=1;
	        							//havenoticeid[j]=poid[i];
	        						}
	        					}
	        				}
	        			}
	        			result = sendPostDataToInternet(uid,likerecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			likerecordfid = new String[ja.length()];
	        			likerecordevent = new String[ja.length()];
	        			likerecordtypes = new String[ja.length()];
	        			likerecordtypeid = new String[ja.length()];
	        			likerecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	likerecordfid[i] = jsonObject.getString("fid");
	                        	likerecordevent[i] = jsonObject.getString("event");
	                        	likerecordtypes[i] = jsonObject.getString("type");
	                        	likerecordtypeid[i] = jsonObject.getString("typeid");
	                        	likerecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			result = sendPostDataToInternet(uid,commentrecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			commentrecordfid = new String[ja.length()];
	        			commentrecordevent = new String[ja.length()];
	        			commentrecordtypes = new String[ja.length()];
	        			commentrecordtypeid = new String[ja.length()];
	        			commentrecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	commentrecordfid[i] = jsonObject.getString("fid");
	                        	commentrecordevent[i] = jsonObject.getString("event");
	                        	commentrecordtypes[i] = jsonObject.getString("type");
	                        	commentrecordtypeid[i] = jsonObject.getString("typeid");
	                        	commentrecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			result = sendPostDataToInternet(uid,tagrecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			tagrecordfid = new String[ja.length()];
	        			tagrecordevent = new String[ja.length()];
	        			tagrecordtypes = new String[ja.length()];
	        			tagrecordtypeid = new String[ja.length()];
	        			tagrecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	tagrecordfid[i] = jsonObject.getString("fid");
	                        	tagrecordevent[i] = jsonObject.getString("event");
	                        	tagrecordtypes[i] = jsonObject.getString("type");
	                        	tagrecordtypeid[i] = jsonObject.getString("typeid");
	                        	tagrecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			if(likenum>0)
	        			{
	        				likeibtn = new ImageButton(getActivity());
        					likeibtn.getBackground().setAlpha(0);
    	    		        likeibtn.setBackgroundResource(R.drawable.likes);
    	    		        absolute.addView(likeibtn,new AbsoluteLayout.LayoutParams(199,126, 70, 960));
    	    		        likeibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub

									
									
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x7f000000);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(likeibtn);
											absolute.removeView(list);
											

											result = sendPostDataToInternet(uid,noticeurl,0);
						        			try {
						        				ja = JSONDecode2();
						        			} catch (JSONException e) {
						        				// TODO Auto-generated catch block
						        				e.printStackTrace();
						        			}
						        			noticefid = new String[ja.length()];
						        			noticeevent = new String[ja.length()];
						        			noticetypes = new String[ja.length()];
						        			noticetypeid = new String[ja.length()];
						        			noticecontent = new String[ja.length()];
						        			personalnoticeevent = new String[150][ja.length()];
						        			personalnoticetype = new String[150][ja.length()];
						        			personalnoticetypeid = new String[150][ja.length()];
						        			personalnoticecontent = new String[150][ja.length()];
						        			for (int i = 0; i < ja.length(); i++) {
						                        try {
						                        	JSONObject jsonObject = ja.getJSONObject(i);
						                        	noticefid[i] = jsonObject.getString("fid");
						                        	noticeevent[i] = jsonObject.getString("event");
						                        	noticetypes[i] = jsonObject.getString("type");
						                        	noticetypeid[i] = jsonObject.getString("typeid");
						                        	noticecontent[i] = jsonObject.getString("content");
						        				} catch (JSONException e) {
						        					// TODO Auto-generated catch block
						        					e.printStackTrace();
						        				}
						                    }
						        			
						        			//absolute.removeView(likeibtn);
						        			/*absolute.removeView(commentibtn);
						        			absolute.removeView(shareibtn);
						        			absolute.removeView(tagibtn);
						        			absolute.removeView(messageibtn);*/
						        			likenum=0;
						        			commentnum=0;
						        			sharenum=0;
						        			tagnum=0;
						        			messagenum=0;
						        			if(newuser==0){
						        			for(int i=0;i<150;i++)
						        			{
						        				noticenum[i]=0;
						        				havenotice[i]=0;
						        				if(mood[i]==0)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
						    		        	}
						    		        	else if(mood[i]==-1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
						    		        	}
						    		        	else if(mood[i]==-2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
						    		        	}
						    		        	else if(mood[i]==1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
						    		        	}
						    		        	else if(mood[i]==2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
						    		        	}
						        			}
						        			
						        			for(int i=0;i<noticefid.length;i++)
						        			{
						        				for(int j=0;j<150;j++)
						        				{
						        					if(noticefid[i].equals(fid[j]))
						        					{
						        						if(noticeevent[i].equals("like"))
						    	        				{
						    	        					likenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("com"))
						    	        				{
						    	        					commentnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("share"))
						    	        				{
						    	        					sharenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("tag"))
						    	        				{
						    	        					tagnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("msg"))
						    	        				{
						    	        					messagenum++;
						    	        					
						    	        				}
						        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
						        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
						        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
						        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
						        						noticenum[j]++;
					        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
					        							havenotice[j]=1;
					        							//havenoticeid[j]=poid[i];
					        						}
					        					}
					        				}
						        			}
						        			else
						        			{
						        				for(int i=0;i<15;i++)
							        			{
							        				noticenum[i]=0;
							        				havenotice[i]=0;
							        				if(mood[i]==0)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
							    		        	}
							    		        	else if(mood[i]==-1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
							    		        	}
							    		        	else if(mood[i]==-2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
							    		        	}
							    		        	else if(mood[i]==1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
							    		        	}
							    		        	else if(mood[i]==2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
							    		        	}
							        			}
							        			
							        			for(int i=0;i<noticefid.length;i++)
							        			{
							        				for(int j=0;j<15;j++)
							        				{
							        					if(noticefid[i].equals(fid[j]))
							        					{
							        						if(noticeevent[i].equals("like"))
							    	        				{
							    	        					likenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("com"))
							    	        				{
							    	        					commentnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("share"))
							    	        				{
							    	        					sharenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("tag"))
							    	        				{
							    	        					tagnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("msg"))
							    	        				{
							    	        					messagenum++;
							    	        					
							    	        				}
							        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
							        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
							        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
							        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
							        						noticenum[j]++;
						        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
						        							havenotice[j]=1;
						        							//havenoticeid[j]=poid[i];
						        						}
						        					}
						        				}
						        			}
										}
									});
									likenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            likeframe.setText(String.valueOf(likenum));
						            
						            for(int i=0;i<likerecordfid.length;i++)
				                    {
					                    if(likerecordevent[i].equals("like"))
					                    {
					                    	if(likerecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(likerecordfid[i] + "�I�F�A�@�i�Ӥ��g"));
					                    	}
					                    	else if(likerecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(likerecordfid[i] + "ı�o�u" + likerecordcontent[i] + "�v�g"));
					                        }
					                        else if(likerecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(likerecordfid[i] + "ı�o�u" + likerecordcontent[i] + "�v�g"));
					                        }
					                    }
					                    else if(likerecordevent[i].equals("com"))
					                    {
					                    	if(likerecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(likerecordfid[i] + "�^���F�u" + likerecordcontent[i] + "�v��@�i�Ӥ�"));
					                    	}
					                        else if(likerecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(likerecordfid[i] + "�^���F�u" + likerecordcontent[i] + "�v��@�g�ʺA"));
					                        }
					                    }
					                    else if(likerecordevent[i].equals("tag"))
					                    {
					                    	if(likerecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(likerecordfid[i] + "��A�аO��@�i�Ӥ�"));
					                    	}
					                    	else if(likerecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(likerecordfid[i] + "��A�аO��u" + likerecordcontent[i] + "�v��"));
					                        }
					                        else if(likerecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(likerecordfid[i] + "��A�аO��u" + likerecordcontent[i] + "�v��"));
					                        }
					                        else if(likerecordtypes[i].equals("checkin"))
					                        {
					                        	alldata.add(createData(likerecordfid[i] + "�N�A�аO��@�Ӧa�I"));
					                        }
					                    }
					                    else if(likerecordevent[i].equals("msg"))
					                    {
					                    	alldata.add(createData(likerecordfid[i] + "�ǤF�T�����A"));
					                    }
				                    }
						            
						            
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(commentnum>0)
	        			{
	        				commentibtn = new ImageButton(getActivity());
        					commentibtn.getBackground().setAlpha(0);
    	    		        commentibtn.setBackgroundResource(R.drawable.comments);
    	    		        absolute.addView(commentibtn,new AbsoluteLayout.LayoutParams(199,126, 305, 960));
    	    		        commentibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x7f000000);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(commentibtn);
											absolute.removeView(list);
											
											
											result = sendPostDataToInternet(uid,noticeurl,0);
						        			try {
						        				ja = JSONDecode2();
						        			} catch (JSONException e) {
						        				// TODO Auto-generated catch block
						        				e.printStackTrace();
						        			}
						        			noticefid = new String[ja.length()];
						        			noticeevent = new String[ja.length()];
						        			noticetypes = new String[ja.length()];
						        			noticetypeid = new String[ja.length()];
						        			noticecontent = new String[ja.length()];
						        			personalnoticeevent = new String[150][ja.length()];
						        			personalnoticetype = new String[150][ja.length()];
						        			personalnoticetypeid = new String[150][ja.length()];
						        			personalnoticecontent = new String[150][ja.length()];
						        			for (int i = 0; i < ja.length(); i++) {
						                        try {
						                        	JSONObject jsonObject = ja.getJSONObject(i);
						                        	noticefid[i] = jsonObject.getString("fid");
						                        	noticeevent[i] = jsonObject.getString("event");
						                        	noticetypes[i] = jsonObject.getString("type");
						                        	noticetypeid[i] = jsonObject.getString("typeid");
						                        	noticecontent[i] = jsonObject.getString("content");
						        				} catch (JSONException e) {
						        					// TODO Auto-generated catch block
						        					e.printStackTrace();
						        				}
						                    }
						        			
						        			//absolute.removeView(likeibtn);
						        			//absolute.removeView(commentibtn);
						        			//absolute.removeView(shareibtn);
						        			//absolute.removeView(tagibtn);
						        			//absolute.removeView(messageibtn);
						        			likenum=0;
						        			commentnum=0;
						        			sharenum=0;
						        			tagnum=0;
						        			messagenum=0;
						        			if(newuser==0){
						        			for(int i=0;i<150;i++)
						        			{
						        				noticenum[i]=0;
						        				havenotice[i]=0;
						        				if(mood[i]==0)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
						    		        	}
						    		        	else if(mood[i]==-1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
						    		        	}
						    		        	else if(mood[i]==-2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
						    		        	}
						    		        	else if(mood[i]==1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
						    		        	}
						    		        	else if(mood[i]==2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
						    		        	}
						        			}
						        			
						        			for(int i=0;i<noticefid.length;i++)
						        			{
						        				for(int j=0;j<150;j++)
						        				{
						        					if(noticefid[i].equals(fid[j]))
						        					{
						        						if(noticeevent[i].equals("like"))
						    	        				{
						    	        					likenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("com"))
						    	        				{
						    	        					commentnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("share"))
						    	        				{
						    	        					sharenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("tag"))
						    	        				{
						    	        					tagnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("msg"))
						    	        				{
						    	        					messagenum++;
						    	        					
						    	        				}
						        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
						        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
						        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
						        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
						        						noticenum[j]++;
					        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
					        							havenotice[j]=1;
					        							//havenoticeid[j]=poid[i];
					        						}
					        					}
					        				}
						        			}
						        			else
						        			{
						        				for(int i=0;i<15;i++)
							        			{
							        				noticenum[i]=0;
							        				havenotice[i]=0;
							        				if(mood[i]==0)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
							    		        	}
							    		        	else if(mood[i]==-1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
							    		        	}
							    		        	else if(mood[i]==-2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
							    		        	}
							    		        	else if(mood[i]==1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
							    		        	}
							    		        	else if(mood[i]==2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
							    		        	}
							        			}
							        			
							        			for(int i=0;i<noticefid.length;i++)
							        			{
							        				for(int j=0;j<15;j++)
							        				{
							        					if(noticefid[i].equals(fid[j]))
							        					{
							        						if(noticeevent[i].equals("like"))
							    	        				{
							    	        					likenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("com"))
							    	        				{
							    	        					commentnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("share"))
							    	        				{
							    	        					sharenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("tag"))
							    	        				{
							    	        					tagnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("msg"))
							    	        				{
							    	        					messagenum++;
							    	        					
							    	        				}
							        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
							        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
							        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
							        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
							        						noticenum[j]++;
						        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
						        							havenotice[j]=1;
						        							//havenoticeid[j]=poid[i];
						        						}
						        					}
						        				}
						        			}
										}
									});
									commentnum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            commentframe.setText(String.valueOf(commentnum));
						            
						            
						            for(int i=0;i<commentrecordfid.length;i++)
				                    {
					                    if(commentrecordevent[i].equals("like"))
					                    {
					                    	if(commentrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(commentrecordfid[i] + "�I�F�A�@�i�Ӥ��g"));
					                    	}
					                    	else if(commentrecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(commentrecordfid[i] + "ı�o�u" + commentrecordcontent[i] + "�v�g"));
					                        }
					                        else if(commentrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(commentrecordfid[i] + "ı�o�u" + commentrecordcontent[i] + "�v�g"));
					                        }
					                    }
					                    else if(commentrecordevent[i].equals("com"))
					                    {
					                    	if(commentrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(commentrecordfid[i] + "�^���F�u" + commentrecordcontent[i] + "�v��@�i�Ӥ�"));
					                    	}
					                        else if(commentrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(commentrecordfid[i] + "�^���F�u" + commentrecordcontent[i] + "�v��@�g�ʺA"));
					                        }
					                    }
					                    else if(commentrecordevent[i].equals("tag"))
					                    {
					                    	if(commentrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(commentrecordfid[i] + "��A�аO��@�i�Ӥ�"));
					                    	}
					                    	else if(commentrecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(commentrecordfid[i] + "��A�аO��u" + commentrecordcontent[i] + "�v��"));
					                        }
					                        else if(commentrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(commentrecordfid[i] + "��A�аO��u" + commentrecordcontent[i] + "�v��"));
					                        }
					                        else if(commentrecordtypes[i].equals("checkin"))
					                        {
					                        	alldata.add(createData(commentrecordfid[i] + "�N�A�аO��@�Ӧa�I"));
					                        }
					                    }
					                    else if(commentrecordevent[i].equals("msg"))
					                    {
					                    	alldata.add(createData(commentrecordfid[i] + "�ǤF�T�����A"));
					                    }
				                    }
						            
						            
						            
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(sharenum>0)
	        			{
	        				shareibtn = new ImageButton(getActivity());
        					shareibtn.getBackground().setAlpha(0);
    	    		        shareibtn.setBackgroundResource(R.drawable.shares);
    	    		        absolute.addView(shareibtn,new AbsoluteLayout.LayoutParams(199,126, 545, 960));
    	    		        shareibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x7f000000);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(shareibtn);
											absolute.removeView(list);
										}
									});
									sharenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            shareframe.setText(String.valueOf(sharenum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(tagnum>0)
	        			{
	        				tagibtn = new ImageButton(getActivity());
        					tagibtn.getBackground().setAlpha(0);
    	    		        tagibtn.setBackgroundResource(R.drawable.tags);
    	    		        absolute.addView(tagibtn,new AbsoluteLayout.LayoutParams(199,126, 790, 960));
    	    		        tagibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x7f000000);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(tagibtn);
											absolute.removeView(list);
											
											
											result = sendPostDataToInternet(uid,noticeurl,0);
						        			try {
						        				ja = JSONDecode2();
						        			} catch (JSONException e) {
						        				// TODO Auto-generated catch block
						        				e.printStackTrace();
						        			}
						        			noticefid = new String[ja.length()];
						        			noticeevent = new String[ja.length()];
						        			noticetypes = new String[ja.length()];
						        			noticetypeid = new String[ja.length()];
						        			noticecontent = new String[ja.length()];
						        			personalnoticeevent = new String[150][ja.length()];
						        			personalnoticetype = new String[150][ja.length()];
						        			personalnoticetypeid = new String[150][ja.length()];
						        			personalnoticecontent = new String[150][ja.length()];
						        			for (int i = 0; i < ja.length(); i++) {
						                        try {
						                        	JSONObject jsonObject = ja.getJSONObject(i);
						                        	noticefid[i] = jsonObject.getString("fid");
						                        	noticeevent[i] = jsonObject.getString("event");
						                        	noticetypes[i] = jsonObject.getString("type");
						                        	noticetypeid[i] = jsonObject.getString("typeid");
						                        	noticecontent[i] = jsonObject.getString("content");
						        				} catch (JSONException e) {
						        					// TODO Auto-generated catch block
						        					e.printStackTrace();
						        				}
						                    }
						        			
						        			//absolute.removeView(likeibtn);
						        			//absolute.removeView(commentibtn);
						        			//absolute.removeView(shareibtn);
						        			//absolute.removeView(tagibtn);
						        			//absolute.removeView(messageibtn);
						        			likenum=0;
						        			commentnum=0;
						        			sharenum=0;
						        			tagnum=0;
						        			messagenum=0;
						        			if(newuser==0){
						        			for(int i=0;i<150;i++)
						        			{
						        				noticenum[i]=0;
						        				havenotice[i]=0;
						        				if(mood[i]==0)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
						    		        	}
						    		        	else if(mood[i]==-1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
						    		        	}
						    		        	else if(mood[i]==-2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
						    		        	}
						    		        	else if(mood[i]==1)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
						    		        	}
						    		        	else if(mood[i]==2)
						    		        	{
						    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
						    		        	}
						        			}
						        			
						        			for(int i=0;i<noticefid.length;i++)
						        			{
						        				for(int j=0;j<150;j++)
						        				{
						        					if(noticefid[i].equals(fid[j]))
						        					{
						        						if(noticeevent[i].equals("like"))
						    	        				{
						    	        					likenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("com"))
						    	        				{
						    	        					commentnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("share"))
						    	        				{
						    	        					sharenum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("tag"))
						    	        				{
						    	        					tagnum++;
						    	        					
						    	        				}
						    	        				else if(noticeevent[i].equals("msg"))
						    	        				{
						    	        					messagenum++;
						    	        					
						    	        				}
						        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
						        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
						        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
						        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
						        						noticenum[j]++;
					        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
					        							havenotice[j]=1;
					        							//havenoticeid[j]=poid[i];
					        						}
					        					}
					        				}
						        			}
						        			else
						        			{
						        				for(int i=0;i<15;i++)
							        			{
							        				noticenum[i]=0;
							        				havenotice[i]=0;
							        				if(mood[i]==0)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
							    		        	}
							    		        	else if(mood[i]==-1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
							    		        	}
							    		        	else if(mood[i]==-2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
							    		        	}
							    		        	else if(mood[i]==1)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
							    		        	}
							    		        	else if(mood[i]==2)
							    		        	{
							    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
							    		        	}
							        			}
							        			
							        			for(int i=0;i<noticefid.length;i++)
							        			{
							        				for(int j=0;j<15;j++)
							        				{
							        					if(noticefid[i].equals(fid[j]))
							        					{
							        						if(noticeevent[i].equals("like"))
							    	        				{
							    	        					likenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("com"))
							    	        				{
							    	        					commentnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("share"))
							    	        				{
							    	        					sharenum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("tag"))
							    	        				{
							    	        					tagnum++;
							    	        					
							    	        				}
							    	        				else if(noticeevent[i].equals("msg"))
							    	        				{
							    	        					messagenum++;
							    	        					
							    	        				}
							        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
							        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
							        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
							        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
							        						noticenum[j]++;
						        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
						        							havenotice[j]=1;
						        							//havenoticeid[j]=poid[i];
						        						}
						        					}
						        				}
						        			}
										}
									});
									tagnum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            tagframe.setText(String.valueOf(tagnum));
						            
						            
						            for(int i=0;i<tagrecordfid.length;i++)
				                    {
					                    if(tagrecordevent[i].equals("like"))
					                    {
					                    	if(tagrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(tagrecordfid[i] + "�I�F�A�@�i�Ӥ��g"));
					                    	}
					                    	else if(tagrecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(tagrecordfid[i] + "ı�o�u" + tagrecordcontent[i] + "�v�g"));
					                        }
					                        else if(tagrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(tagrecordfid[i] + "ı�o�u" + tagrecordcontent[i] + "�v�g"));
					                        }
					                    }
					                    else if(tagrecordevent[i].equals("com"))
					                    {
					                    	if(tagrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(tagrecordfid[i] + "�^���F�u" + tagrecordcontent[i] + "�v��@�i�Ӥ�"));
					                    	}
					                        else if(tagrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(tagrecordfid[i] + "�^���F�u" + tagrecordcontent[i] + "�v��@�g�ʺA"));
					                        }
					                    }
					                    else if(tagrecordevent[i].equals("tag"))
					                    {
					                    	if(tagrecordtypes[i].equals("pic"))
					                    	{
					                    		alldata.add(createData(tagrecordfid[i] + "��A�аO��@�i�Ӥ�"));
					                    	}
					                    	else if(tagrecordtypes[i].equals("com"))
					                        {
					                    		alldata.add(createData(tagrecordfid[i] + "��A�аO��u" + tagrecordcontent[i] + "�v��"));
					                        }
					                        else if(tagrecordtypes[i].equals("po"))
					                        {
					                        	alldata.add(createData(tagrecordfid[i] + "��A�аO��u" + tagrecordcontent[i] + "�v��"));
					                        }
					                        else if(tagrecordtypes[i].equals("checkin"))
					                        {
					                        	alldata.add(createData(tagrecordfid[i] + "�N�A�аO��@�Ӧa�I"));
					                        }
					                    }
					                    else if(tagrecordevent[i].equals("msg"))
					                    {
					                    	alldata.add(createData(tagrecordfid[i] + "�ǤF�T�����A"));
					                    }
				                    }
						            
						            
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(messagenum>0)
	        			{
	        				messageibtn = new ImageButton(getActivity());
        					messageibtn.getBackground().setAlpha(0);
    	    		        messageibtn.setBackgroundResource(R.drawable.messages);
    	    		        absolute.addView(messageibtn,new AbsoluteLayout.LayoutParams(199,126, 1030, 960));
    	    		        messageibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x7f000000);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(messageibtn);
											absolute.removeView(list);
										}
									});
									messagenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            messageframe.setText(String.valueOf(messagenum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			likeframe.setText(String.valueOf(likenum));
	        			commentframe.setText(String.valueOf(commentnum));
	        			shareframe.setText(String.valueOf(sharenum));
	        			tagframe.setText(String.valueOf(tagnum));
	        			messageframe.setText(String.valueOf(messagenum));
	        			
	        			
	        			
	        			result = sendPostDataToInternet(uid,albumlisturl,0);
	                    //name,time,picurl,id;
	                    try {
	    					ja = JSONDecodeAlbumlist();
	    				} catch (JSONException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}
	                    albumlistname = new String[ja.length()];
	                    albumlisttime = new String[ja.length()];
	                    albumlistpicurl = new String[ja.length()];
	                    albumlistid = new String[ja.length()];
	                    for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	albumlistname[i] = jsonObject.getString("name");
	                        	albumlisttime[i] = jsonObject.getString("time");
	                        	albumlistpicurl[i] = jsonObject.getString("picurl");
	                        	albumlistid[i] = jsonObject.getString("id");
	    					} catch (JSONException e) {
	    						// TODO Auto-generated catch block
	    						e.printStackTrace();
	    					}
	                    }
	                    
	                    if(albumlistname[0].equals("null"))
	                    {
		                    
	                    }
	                    else
	                    {
	                    	List<ImageAndText> gridviewlist = new ArrayList<ImageAndText>();
		                    
		    		        for(int i=0;i<albumlistname.length;i++)
		    		        {
		    		        	//String[] splitid = albumlistid[i].split(".");
		    		        	if(albumlistid[i].contains("."))
		    		        	{
		    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], "�@�P��ï�G" + albumlistname[i] + "\n" + albumlisttime[i]));
		    		        	}
		    		        	else
		    		        	{
		    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], albumlistname[i] + "\n" + albumlisttime[i]));
		    		        	}
		    		        }
		    		        mPhotoWall = new GridView(getActivity());
		    				//absolute.addView(mPhotoWall,new AbsoluteLayout.LayoutParams(1160,200, 60, 1225));
		    				mPhotoWall.setAdapter(new ImageAndTextListAdapter(getActivity(), gridviewlist, mPhotoWall, 1));
		    				mPhotoWall.setOnItemClickListener(new OnItemClickListener(){
								@Override
								public void onItemClick(AdapterView<?> arg0, View arg1, int position, long locategridview) {
									// TODO Auto-generated method stub
									Intent intent = new Intent();
									intent.setClass(getActivity(), Albumpic.class);
									// �إ� Bundle ����
						            Bundle bundle = new Bundle();
						            bundle.putString("albumid", albumlistid[position]);
						            // �N Bundle ���w�� Intent
						            intent.putExtras(bundle);
									startActivity(intent);
								}
		    				});
	                    }
	        			
	        			
	        			
	        			downloaddatacondition=1;
	        		}
	        		if(mMinutes%2==1)
	        		{
	        			downloaddatacondition=0;
	        		}
	        		
	        		
	        		if(mMinutes==0 && birdflycondition==0)
	        		{
	        			bird = new ImageView[2];
	        	        for(int i=0;i<2;i++)
	        	        {
	        	        	bird[i] = new ImageView(getActivity());
	        	        }
	        			bird[0].setBackgroundResource(R.drawable.birdnewspaper);
						bird[1].setBackgroundResource(R.drawable.bird);
						absolute.addView(bird[0],new AbsoluteLayout.LayoutParams(150, 150, birdarrx[0], birdarry[0]));
	        			birdfly1 = null;
	        			birdfly1 = new TranslateAnimation(0,birdarrx[1]-birdarrx[0],0,birdarry[1]-birdarry[0]);
	        			birdfly1.setDuration(1000);
	        			bird[0].startAnimation(birdfly1);
	        			
	        			birdfly2 = null;
	        			birdfly2 = new TranslateAnimation(0,1300-birdarrx[1],0,50-birdarry[1]);
	        			birdfly2.setDuration(1000);
	        			
	        			newspaperanimation = new AnimationSet(true);
	        			newspaperanimation.setFillAfter(true);
	        			newspaperrotation = null;
	        			newspaperrotation = new RotateAnimation(0,1080,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
	        			newspaperrotation.setDuration(1000);
	        			newspaperrotation.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspaperrotation);
					
	        			newspapertranslation = null;
	        			newspapertranslation = new TranslateAnimation(0,820-885,0,482-525);
	        			newspapertranslation.setDuration(1000);
	        			newspapertranslation.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspapertranslation);
	        			
	        			newspaperscale = null;
	        			newspaperscale = new ScaleAnimation(0, 12, 0, 12);
	        			newspaperscale.setDuration(1000);
	        			newspaperscale.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspaperscale);
	        			
	        			birdfly1.setAnimationListener(new Animation.AnimationListener() {
							@Override public void onAnimationStart(Animation animation) {
							}
							@Override public void onAnimationRepeat(Animation animation) {
							}
							@Override public void onAnimationEnd(Animation animation) {
								result = sendPostDataToInternet(uid,hoturl,0);
			    				Log.i("result", result);
			    				//webtext.setText(result);
			    				try {
			    					ja = JSONDecode2();
			    				} catch (JSONException e) {
			    					// TODO Auto-generated catch block
			    					e.printStackTrace();
			    				}
			                    for (int i = 0; i < ja.length(); i++) {
			                        try {
			                        	JSONObject jsonObject = ja.getJSONObject(i);
			    						hotname[i] = jsonObject.getString("name");
			    						hotid[i] = jsonObject.getString("id");
			    						hottime[i] = jsonObject.getString("time");
			    						hotcontent[i] = jsonObject.getString("content");
			    						hot_like_num[i] = jsonObject.getInt("like_num");
			    						hot_comment_num[i] = jsonObject.getInt("comment_num");
			    					} catch (JSONException e) {
			    						// TODO Auto-generated catch block
			    						e.printStackTrace();
			    					}
			                    }
			                    
								absolute.removeView(bird[0]);
								newspaper.setBackgroundResource(R.drawable.newspaper);
								
								absolute.addView(bird[1],new AbsoluteLayout.LayoutParams(150, 150, birdarrx[1], birdarry[1]));
								bird[1].startAnimation(birdfly2);
								
								birdfly2.setAnimationListener(new Animation.AnimationListener() {
									@Override public void onAnimationStart(Animation animation2) {
									}
									@Override public void onAnimationRepeat(Animation animation2) {
									}
									@Override public void onAnimationEnd(Animation animation2) {
										absolute.removeView(bird[1]);
									}
								});
							}
						});
	        			
	        			
	        			birdflycondition=1;
	        		}
	        		if(mMinutes==59 && birdflycondition==1)
	        		{
	        			birdflycondition=0;
	        		}
					/*else if(msecond>=48 && msecond<60){
						
						if(addrain==0)
						{
							rain[0].setBackgroundResource(R.drawable.rainpic);
							rain[1].setBackgroundResource(R.drawable.rainpic);
							absolute.addView(rain[0],new AbsoluteLayout.LayoutParams(1280, 2000, 0, -1000));
							absolute.addView(rain[1],new AbsoluteLayout.LayoutParams(1280, 2000, 0, -1000));
							addrain = 1;
							
							animation = null;
							animation = new TranslateAnimation(0,0,0,1000);
							animation.setDuration(2000);
							animation.setRepeatCount(Animation.INFINITE);
							rain[0].startAnimation(animation);
							
							animation2 = null;
							animation2 = new TranslateAnimation(0,0,0,1000);
							animation2.setStartOffset(1000);
							animation2.setDuration(2000);
							animation2.setRepeatCount(Animation.INFINITE);
							rain[1].startAnimation(animation2);
						}
						
				        absolute.setBackgroundResource(R.drawable.rain);
					}*/
	        		
			    }
        		
        		
        		super.handleMessage(msg);
        		
        		if(inout==1)
        		{
        			
	        		
					if(msecond%10==0 && leafmovecondition==1){

						play();
						leafmovecondition = 0;
						if(newuser==0){
						for(int i=0;i<150;i++)
						{
							leafrotateanimation = null;
							if(i==8 || i==68 || i==113 || i==116)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);
							}
							else if(i==7 || i==10 || i==22 || i==47 || i==48 || i==74 || i==84 || i==119 || i==137)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0.5f);
							}
							else if(i==2 || i==6 || i==9 || i==24 || i==34 || i==40 || i==41 || i==43 || i==44 || i==46 || i==65 || i==69 || i==80 || i==81 || i==87 || i==91 || i==92 || i==93 || i==101 || i==103 || i==104 || i==112 || i==134 || i==135 || i==142)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,1f);
							}
							else if(i==0 || i==1 || i==3 || i==4 || i==5 || i==11 || i==18 || i==19 || i==20 || i==21 || i==23 || i==25 || i==26 || i==27 || i==28 || i==29 || i==31 || i==32 || i==33 || i==35 || i==37 || i==38 || i==39 || i==42 || i==45 || i==49 || i==60 || i==61 || i==62 || i==63 || i==64 || i==67 || i==71 || i==72 || i==73 || i==76 || i==77 || i==83 || i==86 || i==89 || i==90 || i==95 || i==98 || i==102 || i==107 || i==108 || i==109 || i==110 || i==115 || i==118 || i==122 || i==123 || i==126 || i==128 || i==129 || i==130 || i==131 || i==136 || i==140 || i==143 || i==147 || i==149)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,1f);
							}
							else if(i==12 || i==13 || i==17 || i==30 || i==36 || i==53 || i==55 || i==56 || i==59 || i==66 || i==75 || i==85 || i==88 || i==94 || i==97 || i==99 || i==105 || i==111 || i==117 || i==120 || i==124 || i==127 || i==132 || i==139 || i==141 || i==145)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,1f);
							}
							else if(i==14 || i==15 || i==16 || i==50 || i==51 || i==52 || i==54 || i==58 || i==70 || i==78 || i==82 || i==96 || i==100 || i==106 || i==114 || i==121 || i==125 || i==133 || i==138 || i==144 || i==146 || i==148)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,0.5f);
							}
							else if(i==57 || i==79)
							{
								leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,0f);
							}
							leafrotateanimation.setDuration(1000);
							leafrotateanimation.setFillAfter(true);
							leafrotateanimation.setRepeatMode(Animation.REVERSE);
							leafrotateanimation.setRepeatCount(1);
							leafibtn[i].startAnimation(leafrotateanimation);
						}
						}
						else
						{
							for(int i=0;i<15;i++)
							{
								leafrotateanimation = null;
								if(i==8 || i==68 || i==113 || i==116)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);
								}
								else if(i==7 || i==10 || i==22 || i==47 || i==48 || i==74 || i==84 || i==119 || i==137)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0.5f);
								}
								else if(i==2 || i==6 || i==9 || i==24 || i==34 || i==40 || i==41 || i==43 || i==44 || i==46 || i==65 || i==69 || i==80 || i==81 || i==87 || i==91 || i==92 || i==93 || i==101 || i==103 || i==104 || i==112 || i==134 || i==135 || i==142)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,1f);
								}
								else if(i==0 || i==1 || i==3 || i==4 || i==5 || i==11 || i==18 || i==19 || i==20 || i==21 || i==23 || i==25 || i==26 || i==27 || i==28 || i==29 || i==31 || i==32 || i==33 || i==35 || i==37 || i==38 || i==39 || i==42 || i==45 || i==49 || i==60 || i==61 || i==62 || i==63 || i==64 || i==67 || i==71 || i==72 || i==73 || i==76 || i==77 || i==83 || i==86 || i==89 || i==90 || i==95 || i==98 || i==102 || i==107 || i==108 || i==109 || i==110 || i==115 || i==118 || i==122 || i==123 || i==126 || i==128 || i==129 || i==130 || i==131 || i==136 || i==140 || i==143 || i==147 || i==149)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,1f);
								}
								else if(i==12 || i==13 || i==17 || i==30 || i==36 || i==53 || i==55 || i==56 || i==59 || i==66 || i==75 || i==85 || i==88 || i==94 || i==97 || i==99 || i==105 || i==111 || i==117 || i==120 || i==124 || i==127 || i==132 || i==139 || i==141 || i==145)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,1f);
								}
								else if(i==14 || i==15 || i==16 || i==50 || i==51 || i==52 || i==54 || i==58 || i==70 || i==78 || i==82 || i==96 || i==100 || i==106 || i==114 || i==121 || i==125 || i==133 || i==138 || i==144 || i==146 || i==148)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,0.5f);
								}
								else if(i==57 || i==79)
								{
									leafrotateanimation = new RotateAnimation(0,15,Animation.RELATIVE_TO_SELF,1f,Animation.RELATIVE_TO_SELF,0f);
								}
								leafrotateanimation.setDuration(1000);
								leafrotateanimation.setFillAfter(true);
								leafrotateanimation.setRepeatMode(Animation.REVERSE);
								leafrotateanimation.setRepeatCount(1);
								leafibtn[i].startAnimation(leafrotateanimation);
							}
						}
						
					}
					if(msecond%10==9)
					{
						leafmovecondition = 1;
					}
	        		
        		}
        		
        		
        	}
        };
        mClockThread = new LooperThread();
        mClockThread.start();
        
        
        
        //���oLOCATIONMANAGER����
        //locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        locationManager = (LocationManager)getActivity().getSystemService(Context.LOCATION_SERVICE);
  		
  		//�إ�Criteria�W�h����,�ín�D��Ǫ��w��\��
  		criteria = new Criteria();
  		criteria.setAccuracy(Criteria.ACCURACY_FINE);
  		
  		//�̾�Criteria���W�h�^�ǳ̾A�X�w��W��
  		//true�N���u�^�ǥثe�i���Ѫ��w��W��
  		String provider = locationManager.getBestProvider(criteria,true);
  		
  		//�Q�Ϋ��w���w��W�٨Ө��o�ۤv�̷s��m
  		Location myLocation = locationManager.getLastKnownLocation(provider);
  		this.myLocation = myLocation;
  		//updateMyLocationInfo(myLocation);
		
		
		
        
        
        
		sendBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				result = sendPostDataToInternet(uid,friendurl,0);
				Log.i("result", result);
				//webtext.setText(result);
				/*try {
					ja = JSONDecode();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

                String[] strArray = new String[ja.length()];

                for (int i = 0; i < ja.length(); i++) {
                    try {
                    	JSONObject jsonObject = ja.getJSONObject(i);
						strArray[i] = jsonObject.getString("id") + "   " + jsonObject.getString("name") + "   " + jsonObject.getString("social_point");
						pp[i]= jsonObject.getInt("social_point");
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    Log.v("information", strArray[i]);
                }*/
				if(myWebView.getVisibility()==View.GONE)
				{
					myWebView.setVisibility(View.VISIBLE);
				}
				else if(myWebView.getVisibility()==View.VISIBLE)
				{
					myWebView.setVisibility(View.GONE);
				}
			}
		});
		
		
		myWebView.setWebChromeClient(new WebChromeClient(){
	    	 
	    	public void onProgressChanged(WebView view,int progress){//���J�i�ק��ܦ�Ĳ�o

	    		if(progress < 100){
	    			pd.setVisibility(ProgressBar.VISIBLE);
	    			//webtext.setText(String.valueOf(progress));
	            }
	            pd.setProgress(progress);
	            
	    		if(progress==100){
	    			//handler.sendEmptyMessage(1);//�p�G�������J�A���öi�׹�ܮ�
	    			pd.setVisibility(ProgressBar.GONE);
	    			//txt.setText("fin");
	    			//webtext.setText(myWebView.getUrl());
	    			curl = myWebView.getUrl();
	    			//curl1 = myWebView.getUrl().toString().split("?");
	    			//Log.v("uuurl", curl1.toString());
	    			//curl2 = curl1[1].split("/");
	    			//Log.v("uuurl", curl2.toString());
	    			//curl = curl2[curl2.length-1];
	    			//Log.v("uuurl", curl);
	    			//if(count==2 && myWebView.getUrl().equals("http://apps.facebook.com/bookroyt/") && newuser==0)
	    			if(newuser==2)
	    			{
	    				Log.v("onpcccccccccccccc", "OOOOOOOOOOOOOO");
	    				count=3;
	    				//absolute.removeView(myWebView);
	    				myWebView.setVisibility(View.GONE);
	    				
	    				if(newuser==0)
	    				{
	    					absolute.removeView(loadingbackground);
		    				absolute.removeView(loading);
		    				dynamicdot=2;
		    				for(int i=0;i<10;i++)
		    				{
		    					absolute.removeView(loadingdot[i]);
		    				}
	    				}
	    				
	    				updatedata.setLayoutParams(new LayoutParams(0,0));
	    				updatedata.setX(0);
	    				updatedata.setY(0);
	    				absolute.addView(updatedata);
	    				updatedata10.setLayoutParams(new LayoutParams(0,0));
	    				updatedata10.setX(100);
	    				updatedata10.setY(0);
	    				absolute.addView(updatedata10);
	    				updatedata60.setLayoutParams(new LayoutParams(0,0));
	    				updatedata60.setX(200);
	    				updatedata60.setY(0);
	    				absolute.addView(updatedata60);
	    				
	    				rereadguide.setBackgroundResource(R.drawable.rereadguide);
	    				absolute.addView(rereadguide,new AbsoluteLayout.LayoutParams(59,67, 75, -5));
	    				rereadguide.setOnClickListener(new Button.OnClickListener(){
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								Intent intent = new Intent();
								intent.setClass(getActivity(), Guide.class);
								startActivity(intent);
							}
	    				});
	    				
	    				trunk.setImageResource(R.drawable.trunk5);
	    				trunk.setX(0);
	    				//trunk.setY(60);
	    				//trunk3
	    				//trunk.setY(15);
	    				//absolute.addView(trunk, new LayoutParams(1280,1725));
	    				//trunk1~5(���F3)
	    				trunk.setY(-115);
	    				absolute.addView(trunk, new LayoutParams(1280,1725));
	    				
	    				//likepic.getBackground().setAlpha(0);
	    				likepic.setBackgroundResource(R.drawable.like);
	    				//commentpic.getBackground().setAlpha(0);
	    				commentpic.setBackgroundResource(R.drawable.comment);
	    				//sharepic.getBackground().setAlpha(0);
	    				sharepic.setBackgroundResource(R.drawable.share);
	    				//tagpic.getBackground().setAlpha(0);
	    				tagpic.setBackgroundResource(R.drawable.tag);
	    				//messagepic.getBackground().setAlpha(0);
	    				messagepic.setBackgroundResource(R.drawable.message);
	    				//albumpic.getBackground().setAlpha(0);
	    				albumpic.setBackgroundResource(R.drawable.album);
	    				like.setText("�g");
	    				like.setTextSize(24);
	    				like.setTextColor(0xFFFFFFFF);
	    				comment.setText("�d��");
	    				comment.setTextSize(24);
	    				comment.setTextColor(0xFFFFFFFF);
	    				share.setText("����");
	    				share.setTextSize(24);
	    				share.setTextColor(0xFFFFFFFF);
	    				tag.setText("����");
	    				tag.setTextSize(24);
	    				tag.setTextColor(0xFFFFFFFF);
	    				message.setText("�T��");
	    				message.setTextSize(24);
	    				message.setTextColor(0xFFFFFFFF);
	    				album.setText("��ï");
	    				album.setTextSize(24);
	    				album.setTextColor(0xFFFFFFFF);
	    				likeframe.setText("0");
	    				likeframe.setTextSize(45);
	    				likeframe.setTextColor(0xFFFFFFFF);
	    				likeframe.setGravity(Gravity.RIGHT);
	    		        commentframe.setText("0");
	    		        commentframe.setTextSize(45);
	    		        commentframe.setTextColor(0xFFFFFFFF);
	    		        commentframe.setGravity(Gravity.RIGHT);
	    		        shareframe.setText("0");
	    		        shareframe.setTextSize(45);
	    		        shareframe.setTextColor(0xFFFFFFFF);
	    		        shareframe.setGravity(Gravity.RIGHT);
	    		        tagframe.setText("0");
	    		        tagframe.setTextSize(45);
	    		        tagframe.setTextColor(0xFFFFFFFF);
	    		        tagframe.setGravity(Gravity.RIGHT);
	    		        messageframe.setText("0");
	    		        messageframe.setTextSize(45);
	    		        messageframe.setTextColor(0xFFFFFFFF);
	    		        messageframe.setGravity(Gravity.RIGHT);
	    		        
	    		        

						absolute.addView(likepic,new AbsoluteLayout.LayoutParams(60,60, 65, 795));
						absolute.addView(like,new AbsoluteLayout.LayoutParams(200,100, 128, 806));
						absolute.addView(commentpic,new AbsoluteLayout.LayoutParams(60,60, 300, 795));
						absolute.addView(comment,new AbsoluteLayout.LayoutParams(200,100, 363, 806));
						absolute.addView(sharepic,new AbsoluteLayout.LayoutParams(60,60, 540, 795));
						absolute.addView(share,new AbsoluteLayout.LayoutParams(200,100, 603, 806));
						absolute.addView(tagpic,new AbsoluteLayout.LayoutParams(60,60, 785, 795));
						absolute.addView(tag,new AbsoluteLayout.LayoutParams(200,100, 848, 806));
						absolute.addView(messagepic,new AbsoluteLayout.LayoutParams(60,60, 1025, 795));
						absolute.addView(message,new AbsoluteLayout.LayoutParams(200,100, 1088, 806));
						absolute.addView(albumpic,new AbsoluteLayout.LayoutParams(75,75, 66, 1120));
						absolute.addView(album,new AbsoluteLayout.LayoutParams(200,100, 139, 1139));
						absolute.addView(likeframe,new AbsoluteLayout.LayoutParams(50,50, 210, 860));
						absolute.addView(commentframe,new AbsoluteLayout.LayoutParams(50,50, 445, 860));
						absolute.addView(shareframe,new AbsoluteLayout.LayoutParams(50,50, 685, 860));
						absolute.addView(tagframe,new AbsoluteLayout.LayoutParams(50,50, 930, 860));
						absolute.addView(messageframe,new AbsoluteLayout.LayoutParams(50,50, 1170, 860));
						
						
						
						likebtn = new Button(getActivity());
    					likebtn.getBackground().setAlpha(0);
	    		        absolute.addView(likebtn,new AbsoluteLayout.LayoutParams(199,126, 70, 960));
	    		        likebtn.setOnClickListener(new Button.OnClickListener() {
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
										absolute.removeView(list);
									}
								});
								list = new ListView(getActivity());
					            ArrayList<String[]> alldata = new ArrayList<String[]>();
					            list.setAdapter(new MydataAdapter(getActivity(),alldata));
					            list.setTextFilterEnabled(true);
					            list.setOnItemClickListener(new OnItemClickListener() {
					    			@Override
					    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
					    				// TODO Auto-generated method stub
					    				
					    			}
					            });
					            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
							}
	    		        });
						
	    				
	    				newspaperanimation = new AnimationSet(true);
	        			newspaperanimation.setFillAfter(true);
	        			newspaperrotation = null;
	        			newspaperrotation = new RotateAnimation(0,1080,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
	        			newspaperrotation.setDuration(1000);
	        			newspaperrotation.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspaperrotation);
					
	        			newspapertranslation = null;
	        			newspapertranslation = new TranslateAnimation(0,820-885,0,482-525);
	        			newspapertranslation.setDuration(1000);
	        			newspapertranslation.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspapertranslation);
	        			
	        			newspaperscale = null;
	        			newspaperscale = new ScaleAnimation(0, 12, 0, 12);
	        			newspaperscale.setDuration(1000);
	        			newspaperscale.setFillAfter(true);
	        			newspaperanimation.addAnimation(newspaperscale);
	        			
	    				newspaper = new ImageButton(getActivity());
						newspaper.setBackgroundResource(R.drawable.nonewspaper);
						absolute.addView(newspaper,new AbsoluteLayout.LayoutParams(120, 320, 835, 455));
						newspaper.setOnClickListener(new Button.OnClickListener(){

							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x7f000000);
								//imgbtntemp.getBackground().setAlpha(255);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								newspaper.setBackgroundResource(R.drawable.nonewspaper);
								hotbackground = new ImageView(getActivity());
								hotbackground.setBackgroundResource(R.drawable.hotbackground);
								absolute.addView(hotbackground,new AbsoluteLayout.LayoutParams(90, 60, 885, 525));
								hotbackground.startAnimation(newspaperanimation);
								newspaperanimation.setAnimationListener(new Animation.AnimationListener() {
									@Override public void onAnimationStart(Animation animation) {
									}
									@Override public void onAnimationRepeat(Animation animation) {
									}
									@Override public void onAnimationEnd(Animation animation) {
										
										hotcontentborder = new TextView[10];
										hotinformation = new TextView[10];
										hotcontenttxt = new TextView[10];
										hotpic = new ImageView[10];
										
										for(int i=0;i<10;i++)
										{
											hotcontentborder[i] = new TextView(getActivity());
											hotinformation[i] = new TextView(getActivity());
											hotcontenttxt[i] = new TextView(getActivity());
											hotpic[i] = new ImageView(getActivity());
										}
										
										for(int i=0;i<=3;i++)
										{
											hotcontentborder[i].setText("");
											hotcontentborder[i].setTextSize(24);
											hotcontentborder[i].setBackgroundResource(R.drawable.textview_border);
											absolute.addView(hotcontentborder[i],new AbsoluteLayout.LayoutParams(240,240, 150+250*i, 120));
											if(hotid[i].equals("null"))
											{
												hotpic[i].setBackgroundResource(R.drawable.ic_launcher);
											}
											else
											{
											if(i==0)
											{
												GetXMLTask1 task1 = new GetXMLTask1();
												task1.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==1)
											{
												GetXMLTask2 task2 = new GetXMLTask2();
												task2.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==2)
											{
												GetXMLTask3 task3 = new GetXMLTask3();
												task3.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==3)
											{
												GetXMLTask4 task4 = new GetXMLTask4();
												task4.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											}
											//hotpic[i].setBackgroundResource(R.drawable.afternoon);
											absolute.addView(hotpic[i],new AbsoluteLayout.LayoutParams(230,230, 155+250*i, 125));
											hotpic[i].setAlpha(187);
											hotinformation[i].setTextSize(18);
											hotinformation[i].setTextColor(0xFFFFFFFF);
											hotinformation[i].setText(hotname[i] + "\n" + hottime[i]);
											absolute.addView(hotinformation[i],new AbsoluteLayout.LayoutParams(180,50, 180+250*i, 260));
											hotcontenttxt[i].setTextSize(18);
											hotcontenttxt[i].setTextColor(0xFFFFFFFF);
											hotcontenttxt[i].setText(hotcontent[i]);
											absolute.addView(hotcontenttxt[i],new AbsoluteLayout.LayoutParams(230,45, 160+250*i, 305));
										}
										for(int i=4;i<=7;i++)
										{
											hotcontentborder[i].setText("");
											hotcontentborder[i].setTextSize(24);
											hotcontentborder[i].setBackgroundResource(R.drawable.textview_border);
											absolute.addView(hotcontentborder[i],new AbsoluteLayout.LayoutParams(240,240, 150+250*(i-4), 400));
											if(hotid[i].equals("null"))
											{
												hotpic[i].setBackgroundResource(R.drawable.ic_launcher);
											}
											else
											{
											if(i==4)
											{
												GetXMLTask5 task5 = new GetXMLTask5();
												task5.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==5)
											{
												GetXMLTask6 task6 = new GetXMLTask6();
												task6.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==6)
											{
												GetXMLTask7 task7 = new GetXMLTask7();
												task7.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											else if(i==7)
											{
												GetXMLTask8 task8 = new GetXMLTask8();
												task8.execute(new String[] { "http://graph.facebook.com/" + hotid[i] + "/picture" });
											}
											}
											//hotpic[i].setBackgroundResource(R.drawable.afternoon);
											absolute.addView(hotpic[i],new AbsoluteLayout.LayoutParams(230,230, 155+250*(i-4), 405));
											hotpic[i].setAlpha(187);
											hotinformation[i].setTextSize(18);
											hotinformation[i].setTextColor(0xFFFFFFFF);
											hotinformation[i].setText(hotname[i] + "\n" + hottime[i]);
											absolute.addView(hotinformation[i],new AbsoluteLayout.LayoutParams(180,50, 180+250*(i-4), 540));
											hotcontenttxt[i].setTextSize(18);
											hotcontenttxt[i].setTextColor(0xFFFFFFFF);
											hotcontenttxt[i].setText(hotcontent[i]);
											absolute.addView(hotcontenttxt[i],new AbsoluteLayout.LayoutParams(230,45, 160+250*(i-4), 585));
										}
										
										
										btntemp = new Button(getActivity());
										btntemp.getBackground().setAlpha(0);
										btntemp.setBackgroundResource(R.drawable.x);
										absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(80,80, 1120, 5));
										btntemp.setOnClickListener(new Button.OnClickListener() {
											@Override
											public void onClick(View arg0) {
												// TODO Auto-generated method stub
												for(int i=0;i<8;i++)
												{
													absolute.removeView(hotcontentborder[i]);
													absolute.removeView(hotinformation[i]);
													absolute.removeView(hotcontenttxt[i]);
													absolute.removeView(hotpic[i]);
													if(hotdoInBackgroundBitmap[i]!=null)
													{
														hotdoInBackgroundBitmap[i].recycle();
													}
													if(hotdownloadImageBitmap[i]!=null)
													{
														hotdownloadImageBitmap[i].recycle();
													}
												}
												absolute.removeView(imgbtntemp);
												absolute.removeView(btntemp);
												hotbackground.clearAnimation();
												absolute.removeView(hotbackground);
											}
										});
									}
								});
							}									
						});
	    				
	    				result = sendPostDataToInternet(uid,friendurl,0);
	    				Log.i("result", result);
	    				//webtext.setText(result);
	    				try {
	    					ja = JSONDecode();
	    				} catch (JSONException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}
	    				
	    				fname = new String[10000];
	                    fid = new String[10000];
	                    sp = new int[10000];
	                    content = new String[10000];
	                    clicktime = new String[10000];
	                    like_num = new int[10000];
	                    comment_num = new int[10000];
	                    mood = new int[10000];
	                    havenotice = new int[10000];
	                    havenoticeid = new String[10000];
	    				
	                    for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	    						fname[i] = jsonObject.getString("name");
	    						fid[i] = jsonObject.getString("id");
	    						sp[i] = jsonObject.getInt("social_point");
	    						content[i] = jsonObject.getString("content");
	    						clicktime[i] = mYear + "/" + formatter.format(realmMonth) + "/" + formatter.format(mDay) + " " +
	    									formatter.format(mHour) + ":" + formatter.format(mMinutes) + ":" + formatter.format(msecond);
	    			            like_num[i] = jsonObject.getInt("like_num");
	    			            comment_num[i] = jsonObject.getInt("comment_num");
	    			            mood[i] = jsonObject.getInt("mood");
	    			            havenotice[i] = 0;
	    					} catch (JSONException e) {
	    						// TODO Auto-generated catch block
	    						e.printStackTrace();
	    					}

	                    }
	    				
	    				
	                    
	                    for(int i=0;i<150;i++) {
	    		        	leafibtn[i] = new ImageButton(getActivity());
	    		        	leafibtn[i].setId(CurrentButtonNumber);
	    		        	CurrentButtonNumber++;
	    		        	leafibtn[i].getBackground().setAlpha(0);
	    		        	
	    		        	
	    		        	if(mood[i]==0)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.normalb);
	    		        	}
	    		        	else if(mood[i]==-1)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.badb);
	    		        	}
	    		        	else if(mood[i]==-2)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.worstb);
	    		        	}
	    		        	else if(mood[i]==1)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.goodb);
	    		        	}
	    		        	else if(mood[i]==2)
	    		        	{
	    		        		leafibtn[i].setBackgroundResource(R.drawable.bestb);
	    		        	}
	    		        	
	    		        	leafibtn[i].setOnClickListener(test);
	    		        	leafibtn[i].setOnLongClickListener(test2);
	    		        	//addView(����,�e�װ���)
	    		        	if(i<52)
	    		        	{
	    		        		absolute.addView(leafibtn[i],new AbsoluteLayout.LayoutParams(60,60, leaf5x[i], leaf5y[i]));
	    		        	}
	    		        	else
	    		        	{
	    		        		absolute.addView(leafibtn[i],new AbsoluteLayout.LayoutParams(48,48, leaf5x[i], leaf5y[i]));
	    		        	}
	    		        }
	                    
	                    result = sendPostDataToInternet(uid,noticeurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			noticefid = new String[ja.length()];
	        			noticeevent = new String[ja.length()];
	        			noticetypes = new String[ja.length()];
	        			noticetypeid = new String[ja.length()];
	        			noticecontent = new String[ja.length()];
	        			personalnoticeevent = new String[150][ja.length()];
	        			personalnoticetype = new String[150][ja.length()];
	        			personalnoticetypeid = new String[150][ja.length()];
	        			personalnoticecontent = new String[150][ja.length()];
	        			noticenum = new int[150];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	noticefid[i] = jsonObject.getString("fid");
	                        	noticeevent[i] = jsonObject.getString("event");
	                        	noticetypes[i] = jsonObject.getString("type");
	                        	noticetypeid[i] = jsonObject.getString("typeid");
	                        	noticecontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }

	        			for(int i=0;i<noticefid.length;i++)
	        			{
	        				
	        				for(int j=0;j<150;j++)
	        				{
	        					if(noticefid[i].equals(fid[j]))
	        					{
	        						if(noticeevent[i].equals("like"))
	    	        				{
	    	        					likenum++;
	    	        				}
	    	        				else if(noticeevent[i].equals("com"))
	    	        				{
	    	        					commentnum++;
	    	        				}
	    	        				else if(noticeevent[i].equals("share"))
	    	        				{
	    	        					sharenum++;
	    	        				}
	    	        				else if(noticeevent[i].equals("tag"))
	    	        				{
	    	        					tagnum++;
	    	        				}
	    	        				else if(noticeevent[i].equals("msg"))
	    	        				{
	    	        					messagenum++;
	    	        				}
	        						personalnoticeevent[j][noticenum[j]] = noticeevent[i];
	        						personalnoticetype[j][noticenum[j]] = noticetypes[i];
	        						personalnoticetypeid[j][noticenum[j]] = noticetypeid[i];
	        						personalnoticecontent[j][noticenum[j]] = noticecontent[i];
	        						noticenum[j]++;
        							leafibtn[j].setBackgroundResource(R.drawable.interactionb);
        							havenotice[j]=1;
        							//havenoticeid[j]=poid[i];
        						}
        					}
        				}
	        			result = sendPostDataToInternet(uid,likerecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			likerecordfid = new String[ja.length()];
	        			likerecordevent = new String[ja.length()];
	        			likerecordtypes = new String[ja.length()];
	        			likerecordtypeid = new String[ja.length()];
	        			likerecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	likerecordfid[i] = jsonObject.getString("fid");
	                        	likerecordevent[i] = jsonObject.getString("event");
	                        	likerecordtypes[i] = jsonObject.getString("type");
	                        	likerecordtypeid[i] = jsonObject.getString("typeid");
	                        	likerecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			result = sendPostDataToInternet(uid,commentrecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			commentrecordfid = new String[ja.length()];
	        			commentrecordevent = new String[ja.length()];
	        			commentrecordtypes = new String[ja.length()];
	        			commentrecordtypeid = new String[ja.length()];
	        			commentrecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	commentrecordfid[i] = jsonObject.getString("fid");
	                        	commentrecordevent[i] = jsonObject.getString("event");
	                        	commentrecordtypes[i] = jsonObject.getString("type");
	                        	commentrecordtypeid[i] = jsonObject.getString("typeid");
	                        	commentrecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			result = sendPostDataToInternet(uid,tagrecordurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			tagrecordfid = new String[ja.length()];
	        			tagrecordevent = new String[ja.length()];
	        			tagrecordtypes = new String[ja.length()];
	        			tagrecordtypeid = new String[ja.length()];
	        			tagrecordcontent = new String[ja.length()];
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	tagrecordfid[i] = jsonObject.getString("fid");
	                        	tagrecordevent[i] = jsonObject.getString("event");
	                        	tagrecordtypes[i] = jsonObject.getString("type");
	                        	tagrecordtypeid[i] = jsonObject.getString("typeid");
	                        	tagrecordcontent[i] = jsonObject.getString("content");
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
	        			if(likenum>0)
	        			{
	        				likeibtn = new ImageButton(getActivity());
        					likeibtn.getBackground().setAlpha(0);
    	    		        likeibtn.setBackgroundResource(R.drawable.likes);
    	    		        absolute.addView(likeibtn,new AbsoluteLayout.LayoutParams(199,126, 70, 960));
    	    		        likeibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x00ffffff);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(likeibtn);
											absolute.removeView(list);
										}
									});
									likenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            likeframe.setText(String.valueOf(likenum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(commentnum>0)
	        			{
	        				commentibtn = new ImageButton(getActivity());
        					commentibtn.getBackground().setAlpha(0);
    	    		        commentibtn.setBackgroundResource(R.drawable.comments);
    	    		        absolute.addView(commentibtn,new AbsoluteLayout.LayoutParams(199,126, 305, 960));
    	    		        commentibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x00ffffff);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(commentibtn);
											absolute.removeView(list);
										}
									});
									commentnum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            commentframe.setText(String.valueOf(commentnum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(sharenum>0)
	        			{
	        				shareibtn = new ImageButton(getActivity());
        					shareibtn.getBackground().setAlpha(0);
    	    		        shareibtn.setBackgroundResource(R.drawable.shares);
    	    		        absolute.addView(shareibtn,new AbsoluteLayout.LayoutParams(199,126, 545, 960));
    	    		        shareibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x00ffffff);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(shareibtn);
											absolute.removeView(list);
										}
									});
									sharenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            shareframe.setText(String.valueOf(sharenum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(tagnum>0)
	        			{
	        				tagibtn = new ImageButton(getActivity());
        					tagibtn.getBackground().setAlpha(0);
    	    		        tagibtn.setBackgroundResource(R.drawable.tags);
    	    		        absolute.addView(tagibtn,new AbsoluteLayout.LayoutParams(199,126, 790, 960));
    	    		        tagibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x00ffffff);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(tagibtn);
											absolute.removeView(list);
										}
									});
									tagnum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            tagframe.setText(String.valueOf(tagnum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			if(messagenum>0)
	        			{
	        				messageibtn = new ImageButton(getActivity());
        					messageibtn.getBackground().setAlpha(0);
    	    		        messageibtn.setBackgroundResource(R.drawable.messages);
    	    		        absolute.addView(messageibtn,new AbsoluteLayout.LayoutParams(199,126, 1030, 960));
    	    		        messageibtn.setOnClickListener(new Button.OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									imgbtntemp = new ImageButton(getActivity());
									imgbtntemp.setBackgroundColor(0x00ffffff);
									absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
									imgbtntemp.setOnClickListener(new Button.OnClickListener(){
										@Override
										public void onClick(View arg0) {
											// TODO Auto-generated method stub
											absolute.removeView(imgbtntemp);
											absolute.removeView(messageibtn);
											absolute.removeView(list);
										}
									});
									messagenum=0;
									list = new ListView(getActivity());
						            ArrayList<String[]> alldata = new ArrayList<String[]>();
						            messageframe.setText(String.valueOf(messagenum));
						            list.setAdapter(new MydataAdapter(getActivity(),alldata));
						            list.setTextFilterEnabled(true);
						            list.setOnItemClickListener(new OnItemClickListener() {
						    			@Override
						    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
						    				// TODO Auto-generated method stub
						    				
						    			}
						            });
						            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, 50, 500));
								}
    	    		        });
	        			}
	        			likeframe.setText(String.valueOf(likenum));
	        			commentframe.setText(String.valueOf(commentnum));
	        			shareframe.setText(String.valueOf(sharenum));
	        			tagframe.setText(String.valueOf(tagnum));
	        			messageframe.setText(String.valueOf(messagenum));
	        			
	                    
	                    CurrentButtonNumber=0;
	                    result = sendPostDataToInternet(uid,recommendurl,0);
	                    try {
	    					ja = JSONDecode2();
	    				} catch (JSONException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}
	                    
	                    recommendid = new String[ja.length()];
	                    
	                    for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	recommendid[i] = jsonObject.getString("recommendid");
	    					} catch (JSONException e) {
	    						// TODO Auto-generated catch block
	    						e.printStackTrace();
	    					}
	                    }
	                    
	                    for(int i=0;i<recommendid.length;i++)
	                    {
	                    	if(recommendid.length<6)
	                    	{
		                    	recommendibtn[i] = new ImageButton(getActivity());
		                    	recommendibtn[i].setId(CurrentButtonNumber);
		    		        	CurrentButtonNumber++;
		    		        	recommendibtn[i].getBackground().setAlpha(0);
		    		        	recommendibtn[i].setBackgroundResource(R.drawable.newfriend);
		    		        	recommendibtn[i].setOnClickListener(recommendwindow);
		    		        	absolute.addView(recommendibtn[i],new AbsoluteLayout.LayoutParams(40,40, recommendfriend3x[i], recommendfriend3y[i]));
	                    	}
	                    }
	                    
	                    
	                    result = sendPostDataToInternet(uid,hoturl,0);
	    				Log.i("result", result);
	    				//webtext.setText(result);
	    				try {
	    					ja = JSONDecode2();
	    				} catch (JSONException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}

	                    hotname = new String[10];
	                    hotid = new String[10];
	                    hottime = new String[10];
	                    hotcontent = new String[10];
	                    hot_like_num = new int[10];
	                    hot_comment_num = new int[10];

	                    for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	    						
	    						hotname[i] = jsonObject.getString("name");
	    						hotid[i] = jsonObject.getString("id");
	    						hottime[i] = jsonObject.getString("time");
	    						hotcontent[i] = jsonObject.getString("content");
	    						hot_like_num[i] = jsonObject.getInt("like_num");
	    						hot_comment_num[i] = jsonObject.getInt("comment_num");
	    					} catch (JSONException e) {
	    						// TODO Auto-generated catch block
	    						e.printStackTrace();
	    					}

	                    }
	                    
	                    result = sendPostDataToInternet(uid,albumlisturl,0);
	                    //name,time,picurl,id;
	                    try {
	    					ja = JSONDecodeAlbumlist();
	    				} catch (JSONException e) {
	    					// TODO Auto-generated catch block
	    					e.printStackTrace();
	    				}
	                    albumlistname = new String[ja.length()];
	                    albumlisttime = new String[ja.length()];
	                    albumlistpicurl = new String[ja.length()];
	                    albumlistid = new String[ja.length()];
	                    for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	                        	albumlistname[i] = jsonObject.getString("name");
	                        	albumlisttime[i] = jsonObject.getString("time");
	                        	albumlistpicurl[i] = jsonObject.getString("picurl");
	                        	albumlistid[i] = jsonObject.getString("id");
	    					} catch (JSONException e) {
	    						// TODO Auto-generated catch block
	    						e.printStackTrace();
	    					}
	                    }
	                    
	                    if(albumlistname[0].equals("null"))
	                    {
		                    
	                    }
	                    else
	                    {
	                    	List<ImageAndText> gridviewlist = new ArrayList<ImageAndText>();
		                    
		    		        for(int i=0;i<albumlistname.length;i++)
		    		        {
		    		        	//String[] splitid = albumlistid[i].split(".");
		    		        	if(albumlistid[i].contains("."))
		    		        	{
		    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], "�@�P��ï�G" + albumlistname[i] + "\n" + albumlisttime[i]));
		    		        	}
		    		        	else
		    		        	{
		    		        		gridviewlist.add(new ImageAndText(albumlistpicurl[i], albumlistname[i] + "\n" + albumlisttime[i]));
		    		        	}
		    		        }
		    		        absolute.addView(horizonsv,new AbsoluteLayout.LayoutParams(1140,250, 65, 1225));
		    		        horizonsv.addView(fl,new HorizontalScrollView.LayoutParams(1140,250));
		    				mPhotoWall.setColumnWidth(270);
		    				mPhotoWall.setStretchMode(2);//STRETCH_COLUMN_WIDTH
		    				mPhotoWall.setNumColumns(albumlistname.length);
		    				mPhotoWall.setVerticalSpacing(20);
		    				mPhotoWall.setGravity(Gravity.CENTER);
		    				fl.addView(mPhotoWall,new FrameLayout.LayoutParams(285*albumlistname.length,250));
		    				//absolute.addView(mPhotoWall,new AbsoluteLayout.LayoutParams(1160,200, 60, 1225));
		    				mPhotoWall.setAdapter(new ImageAndTextListAdapter(getActivity(), gridviewlist, mPhotoWall, 1));
		    				mPhotoWall.setOnItemClickListener(new OnItemClickListener(){
								@Override
								public void onItemClick(AdapterView<?> arg0, View arg1, int position, long locategridview) {
									// TODO Auto-generated method stub
									Intent intent = new Intent();
									intent.setClass(getActivity(), Albumpic.class);
									// �إ� Bundle ����
						            Bundle bundle = new Bundle();
						            bundle.putString("albumid", albumlistid[position]);
						            // �N Bundle ���w�� Intent
						            intent.putExtras(bundle);
									startActivity(intent);
								}
		    				});
	                    }
	                    
	                    inout = 1;

	            		
	            		
	            		clearbutton.setBackgroundResource(R.drawable.clearnotice);
	            		//absolute.addView(clearbutton,new AbsoluteLayout.LayoutParams(74,84, 50, 600));
	            		clearbutton.setOnClickListener(new Button.OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								for(int i=0;i<5;i++)
								{
									noticetype[i].setBackgroundResource(R.drawable.like);
								}
								absolute.addView(noticetype[0],new AbsoluteLayout.LayoutParams(70,70, noticex[0], noticey[0]));
								
								noticetranslation = null;
			        			noticetranslation = new TranslateAnimation(0,noticex[1]-noticex[0],0,noticey[1]-noticey[0]);
			        			noticetranslation.setDuration(800);
			        			noticetranslation.setFillAfter(true);
			        			
								noticeanimation = new AnimationSet(true);
								noticeanimation.setFillAfter(true);
								noticerotationset1 = null;
								noticerotationset1 = new RotateAnimation(0,720,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
								noticerotationset1.setDuration(1500);
								noticerotationset1.setFillAfter(true);
								noticeanimation.addAnimation(noticerotationset1);
								noticetranslationset1 = null;
			        			noticetranslationset1 = new TranslateAnimation(0,noticex[2]-noticex[1],0,noticey[2]-noticey[1]);
			        			noticetranslationset1.setDuration(1500);
			        			noticetranslationset1.setFillAfter(true);
			        			noticeanimation.addAnimation(noticetranslationset1);
			        			
			        			noticeanimation2 = new AnimationSet(true);
								noticeanimation2.setFillAfter(true);
								noticerotationset2 = null;
								noticerotationset2 = new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
								noticerotationset2.setDuration(1000);
								noticerotationset2.setFillAfter(true);
								noticeanimation2.addAnimation(noticerotationset2);
								noticetranslationset2 = null;
			        			noticetranslationset2 = new TranslateAnimation(0,noticex[3]-noticex[2],0,noticey[3]-noticey[2]);
			        			noticetranslationset2.setDuration(1000);
			        			noticetranslationset2.setFillAfter(true);
			        			noticeanimation2.addAnimation(noticetranslationset2);
			        			
			        			noticetranslation2 = null;
			        			noticetranslation2 = new TranslateAnimation(0,noticex[4]-noticex[3],0,noticey[4]-noticey[3]);
			        			noticetranslation2.setDuration(1000);
			        			noticetranslation2.setFillAfter(true);

			        			noticetype[0].startAnimation(noticetranslation);
			        			noticetranslation.setAnimationListener(new Animation.AnimationListener() {
									@Override public void onAnimationStart(Animation animation) {
									}
									@Override public void onAnimationRepeat(Animation animation) {
									}
									@Override public void onAnimationEnd(Animation animation) {
										absolute.removeView(noticetype[0]);
										absolute.addView(noticetype[1],new AbsoluteLayout.LayoutParams(70,70, noticex[1], noticey[1]));
										noticetype[1].startAnimation(noticeanimation);
										noticeanimation.setAnimationListener(new Animation.AnimationListener() {
											@Override public void onAnimationStart(Animation animation2) {
											}
											@Override public void onAnimationRepeat(Animation animation2) {
											}
											@Override public void onAnimationEnd(Animation animation2) {
												absolute.removeView(noticetype[1]);
												absolute.addView(noticetype[2],new AbsoluteLayout.LayoutParams(70,70, noticex[2], noticey[2]));
												noticetype[2].startAnimation(noticeanimation2);
												noticeanimation2.setAnimationListener(new Animation.AnimationListener() {
													@Override public void onAnimationStart(Animation animation3) {
													}
													@Override public void onAnimationRepeat(Animation animation3) {
													}
													@Override public void onAnimationEnd(Animation animation3) {
														absolute.removeView(noticetype[2]);
														absolute.addView(noticetype[3],new AbsoluteLayout.LayoutParams(70,70, noticex[3], noticey[3]));
														noticetype[3].startAnimation(noticetranslation2);
														noticetranslation2.setAnimationListener(new Animation.AnimationListener() {
															@Override public void onAnimationStart(Animation animation4) {
															}
															@Override public void onAnimationRepeat(Animation animation4) {
															}
															@Override public void onAnimationEnd(Animation animation4) {
																absolute.removeView(noticetype[3]);
																//absolute.addView(noticetype[4],new AbsoluteLayout.LayoutParams(70,70, noticex[4], noticey[4]));
															}
									        			});
													}
							        			});
											}
					        			});
									}
			        			});
								
								
							}
	            			
	            		});
	    				
	            		//GetXMLTaskMyself taskmyself = new GetXMLTaskMyself();
	    				//taskmyself.execute(new String[] { "http://graph.facebook.com/" + uid + "/picture" });
	    				absolute.addView(myself,new AbsoluteLayout.LayoutParams(70,70, 675, 550));
	    				myselfclick.setBackgroundColor(0x00ffffff);
	    				absolute.addView(myselfclick,new AbsoluteLayout.LayoutParams(70,70, 675, 550));
	    				myselfclick.setOnClickListener(new Button.OnClickListener(){
							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								/*imgbtntemp = new ImageButton(getActivity());
								imgbtntemp.setBackgroundColor(0x00ffffff);
								absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								imgbtntemp.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										absolute.removeView(imgbtntemp);
									}
								});*/
								
								PopupMenu menu = new PopupMenu(getActivity(), v);
								for(int i=0;i<150;i++)
								{
									menu.getMenu().add(0, i, 0, fname[i]);
								}
						        menu.show();
						        menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
									@Override
									public boolean onMenuItemClick(MenuItem arg0) {
										// TODO Auto-generated method stub
										friendnow = arg0.getItemId();

								    		mempic = new ImageView(getActivity());
								    		replacepic = new ImageView(getActivity());
								    		wallnewsframe = new TextView(getActivity());
								    		wallnews = new TextView(getActivity());
								    		liketemp = new ImageView(getActivity());
								    		liketempnumandlink = new Button(getActivity());
								    		commenttemp = new ImageView(getActivity());
								    		commenttempunmandlink = new Button(getActivity());
											underline = new TextView(getActivity());
											memname = new TextView(getActivity());
											meminfo = new TextView(getActivity());
											talkpic = new ImageView(getActivity());
											talk = new Button(getActivity());
											left = new ImageButton(getActivity());
											right = new ImageButton(getActivity());
											gotochat = new Button(getActivity());
								    	
											imgbtntemp = new ImageButton(getActivity());
											imgbtntemp.setBackgroundColor(0x7f000000);
											//imgbtntemp.getBackground().setAlpha(255);
											absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
											
											
											
											friendanimation = new AnimationSet(true);
											friendanimation.setFillAfter(true);
											friendtranslation = null;
											friendtranslation = new TranslateAnimation(0,875-leaf5x[arg0.getItemId()],0,300-leaf5y[arg0.getItemId()]);
											friendtranslation.setDuration(500);
											friendtranslation.setFillAfter(true);
											friendanimation.addAnimation(friendtranslation);
											
											friendscale = null;
											friendscale = new ScaleAnimation(0, 1, 0, 1);
											friendscale.setDuration(500);
											friendscale.setFillAfter(true);
											friendanimation.addAnimation(friendscale);

											
											friendbackground = new ImageView(getActivity());
											friendbackground.setBackgroundResource(R.drawable.friendbackground);
								    		absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, leaf5x[arg0.getItemId()], leaf5y[arg0.getItemId()]));
								    		friendbackground.startAnimation(friendanimation);
								    		friendanimation.setAnimationListener(new Animation.AnimationListener() {
												@Override public void onAnimationStart(Animation animation) {
												}
												@Override public void onAnimationRepeat(Animation animation) {
												}
												@Override public void onAnimationEnd(Animation animation) {
													//mempic.setBackgroundResource(R.drawable.dusk);
													if(mood[friendnow]==0)
										        	{
														replacepic.setBackgroundResource(R.drawable.normalb);
										        	}
										        	else if(mood[friendnow]==-1)
										        	{
										        		replacepic.setBackgroundResource(R.drawable.badb);
										        	}
										        	else if(mood[friendnow]==-2)
										        	{
										        		replacepic.setBackgroundResource(R.drawable.worstb);
										        	}
										        	else if(mood[friendnow]==1)
										        	{
										        		replacepic.setBackgroundResource(R.drawable.goodb);
										        	}
										        	else if(mood[friendnow]==2)
										        	{
										        		replacepic.setBackgroundResource(R.drawable.bestb);
										        	}
													if(friendnow<52)
													{
														absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(60,60, leaf5x[friendnow], leaf5y[friendnow]));
													}
													else
													{
														absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(48,48, leaf5x[friendnow], leaf5y[friendnow]));
													}
													absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, 875, 240));
													//absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, leaf3x[friendnow]-4, leaf3y[friendnow]-4));
													// Create an object for subclass of AsyncTask
											        GetXMLTask task = new GetXMLTask();
											        // Execute the task
											        task.execute(new String[] { "http://graph.facebook.com/" + fid[friendnow] + "/picture" });
													
													/*underline.setText("                                                                                                       ");
													underline.setTextSize(24);
													underline.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
													absolute.addView(underline,new AbsoluteLayout.LayoutParams(700,100, 340, 220));*/
												
											        //wallnewsframe.setText(content[friendnow] + "\n\n\n  like = " + like_num[friendnow] + "	  comment = " + comment_num[friendnow]);
											        wallnewsframe.setTextSize(24);
											        wallnewsframe.setTextColor(0xFFFFFFFF);
											        wallnewsframe.setBackgroundResource(R.drawable.textview_border);
													absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
													
													wallnews.setText(content[friendnow]);
											        wallnews.setTextSize(18);
											        wallnews.setTextColor(0xFFFFFFFF);
											        //wallnewsframe.setBackgroundResource(R.drawable.textview_border);
													absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
													
													if(mood[friendnow]<0)
													{
														liketemp.setBackgroundResource(R.drawable.pat);
														absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
													}
													else
													{
														liketemp.setBackgroundResource(R.drawable.like);
														absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
													}
													liketempnumandlink.getBackground().setAlpha(0);
													liketempnumandlink.setText(String.valueOf(like_num[friendnow]));
													liketempnumandlink.setTextSize(18);
													liketempnumandlink.setTextColor(0xFFFFFFFF);
													absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
													commenttemp.setBackgroundResource(R.drawable.comment);
													absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
													commenttempunmandlink.getBackground().setAlpha(0);
													commenttempunmandlink.setText(String.valueOf(comment_num[friendnow]));
													commenttempunmandlink.setTextSize(18);
													commenttempunmandlink.setTextColor(0xFFFFFFFF);
													absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
												
													talkpic.setBackgroundResource(R.drawable.message);
													absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
													talk.getBackground().setAlpha(0);
													talk.setText("���˸��D");
													talk.setTextSize(18);
													talk.setTextColor(0xFFFFFFFF);
													absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
													talk.setOnClickListener(new Button.OnClickListener(){
														@Override
														public void onClick(View arg0) {
															// TODO Auto-generated method stub
															if(talkopencondition==0)
															{
																personhotcontent = sendPostDataToInternet(fid[friendnow],personalhoturl,1);
																absolute.removeView(friendbackground);
																absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,450, 875, 300));
																absolute.removeView(wallnewsframe);
																absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
																absolute.removeView(wallnews);
																absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
																absolute.removeView(liketemp);
																if(mood[friendnow]<0)
																{
																	absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
																}
																else
																{
																	absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
																}
																absolute.removeView(liketempnumandlink);
																absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
																absolute.removeView(commenttemp);
																absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
																absolute.removeView(commenttempunmandlink);
																absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
																absolute.removeView(talkpic);
																absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
																absolute.removeView(talk);
																absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
																absolute.removeView(btntemp);
																absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
																talkbackground = new ImageView(getActivity());
																talkbackground.setBackgroundResource(R.drawable.talkbackground);
																absolute.addView(talkbackground,new AbsoluteLayout.LayoutParams(330,190, 885, 555));
																talkframe = new TextView(getActivity());
																//if(personhotcontent.toString().equals(0))
																if(personhotcontent.equals(""))
																{
																	talkframe.setText("�A���n�B�ͪ���S���o���!!\n���֥h���ߥL�a");
																}
																else
																{
																	talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
																}
																talkframe.setTextSize(18);
																absolute.addView(talkframe,new AbsoluteLayout.LayoutParams(290,110, 905, 575));
																left.setBackgroundResource(R.drawable.left);
																absolute.addView(left,new AbsoluteLayout.LayoutParams(25,25, 1155, 550));
																left.setOnClickListener(new Button.OnClickListener(){
																	@Override
																	public void onClick(View v) {
																		// TODO Auto-generated method stub
																		newsindex--;
																		if(newsindex<0)
																		{
																			newsindex=0;
																		}
																		if(newsindex!=0)
																		{
																			talkframe.setText(newstemp[newsindex-1]);
																		}
																		else
																		{
																			talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
																		}
																	}
																});
																right.setBackgroundResource(R.drawable.right);
																absolute.addView(right,new AbsoluteLayout.LayoutParams(25,25, 1180, 550));
																right.setOnClickListener(new Button.OnClickListener(){
																	@Override
																	public void onClick(View v) {
																		// TODO Auto-generated method stub
																		newsindex++;
																		if(newsindex>newstemp.length)
																		{
																			newsindex=newstemp.length;
																		}
																		if(newsindex!=0)
																		{
																			talkframe.setText(newstemp[newsindex-1]);
																		}
																		else
																		{
																			talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
																		}
																	}
																});
																gotochat.setText("Go to chat");
																gotochat.getBackground().setAlpha(0);
																absolute.addView(gotochat,new AbsoluteLayout.LayoutParams(200,50, 1050, 685));
																gotochat.setOnClickListener(new Button.OnClickListener(){
																	@Override
																	public void onClick(View arg0) {
																		// TODO Auto-generated method stub
																		String url="http://www.facebook.com/messages/" + fid[friendnow];
																		Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
																		startActivity(ie);
																	}
																});
																talkopencondition=1;
															}
															else
															{
																absolute.removeView(friendbackground);
																absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, 875, 300));
																absolute.removeView(wallnewsframe);
																absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
																absolute.removeView(wallnews);
																absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
																absolute.removeView(liketemp);
																if(mood[friendnow]<0)
																{
																	absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
																}
																else
																{
																	absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
																}
																absolute.removeView(liketempnumandlink);
																absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
																absolute.removeView(commenttemp);
																absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
																absolute.removeView(commenttempunmandlink);
																absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
																absolute.removeView(talkpic);
																absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
																absolute.removeView(talk);
																absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
																absolute.removeView(btntemp);
																absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
																absolute.removeView(talkbackground);
																absolute.removeView(talkframe);
																absolute.removeView(left);
																absolute.removeView(right);
																absolute.removeView(gotochat);
																talkopencondition=0;
															}
														}
													});
													
												
													memname.setText(fname[friendnow]);
													memname.setTextSize(30);
													memname.setTextColor(0xFFFFFFFF);
													absolute.addView(memname,new AbsoluteLayout.LayoutParams(350,50, 940, 255));
												
													//meminfo.setText("�ʧO\n�ͤ�\n�u�@\n�s��\n���NŪ");
													//meminfo.setTextSize(18);
													//absolute.addView(meminfo,new AbsoluteLayout.LayoutParams(200,200, 360, 440));


													
													btntemp = new Button(getActivity());
													btntemp.getBackground().setAlpha(0);

													btntemp.setBackgroundResource(R.drawable.x);
													absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
													btntemp.setOnClickListener(new Button.OnClickListener() {
														@Override
														public void onClick(View arg0) {
															// TODO Auto-generated method stub
															absolute.removeView(friendbackground);
															absolute.removeView(imgbtntemp);
															absolute.removeView(btntemp);
															absolute.removeView(mempic);
															absolute.removeView(replacepic);
															absolute.removeView(wallnewsframe);
															absolute.removeView(wallnews);
															absolute.removeView(liketemp);
															absolute.removeView(liketempnumandlink);
															absolute.removeView(commenttemp);
															absolute.removeView(commenttempunmandlink);
															//absolute.removeView(underline);
															absolute.removeView(talkpic);
															absolute.removeView(talk);
															if(talkopencondition==1)
															{
																absolute.removeView(talkbackground);
																absolute.removeView(talkframe);
																talkopencondition=0;
																absolute.removeView(left);
																absolute.removeView(right);
																absolute.removeView(gotochat);
															}
															absolute.removeView(memname);
															newsindex=0;
															downloadImageBitmap.recycle();
															doInBackgroundBitmap.recycle();
															outputBitmap.recycle();
															//absolute.removeView(updatewall);
															//absolute.removeView(meminfo);
														}
														
													});
												}
											});	

										return false;
									}						        	
						        });
							}
						});
	    				
	    				
	    				
	            		tipclick[0] = new ImageButton(getActivity());
	    				tipclick[0].setBackgroundColor(0x00ffffff);
	    				tipclick[1] = new ImageButton(getActivity());
	    				tipclick[1].setBackgroundColor(0x00ffffff);
						tip[0].setBackgroundResource(R.drawable.tip2);
						tip[1].setBackgroundResource(R.drawable.tip3);
						absolute.addView(tipclick[0],new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
						absolute.addView(tip[0],new AbsoluteLayout.LayoutParams(415,222, 750, 500));
						tipclick[0].setOnClickListener(new Button.OnClickListener(){
							@Override
							public void onClick(View arg0) {
								// TODO Auto-generated method stub
								absolute.removeView(tipclick[0]);
								absolute.removeView(tip[0]);
								absolute.addView(tipclick[1],new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
								absolute.addView(tip[1],new AbsoluteLayout.LayoutParams(406,217, 870, 225));
								tipclick[1].setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										absolute.removeView(tipclick[1]);
										absolute.removeView(tip[1]);
									}
								});
							}
						});
	            		
	    			}
	    		}
	    		
	    		
	    		super.onProgressChanged(view, progress);
	    	}
	    });
		
		
		
		
		
		updatedata.setWebChromeClient(new WebChromeClient(){
	    	 
	    	public void onProgressChanged(WebView view,int progress){//���J�i�ק��ܦ�Ĳ�o

	    		if(progress < 100){
	            }
	    		if(progress==100){
	    		}
	    		
	    		super.onProgressChanged(view, progress);
	    	}
	    });
		updatedata10.setWebChromeClient(new WebChromeClient(){
	    	 
	    	public void onProgressChanged(WebView view,int progress){//���J�i�ק��ܦ�Ĳ�o

	    		if(progress < 100){
	            }
	    		if(progress==100){
	    		}
	    		
	    		super.onProgressChanged(view, progress);
	    	}
	    });
		updatedata60.setWebChromeClient(new WebChromeClient(){
	    	 
	    	public void onProgressChanged(WebView view,int progress){//���J�i�ק��ܦ�Ĳ�o

	    		if(progress < 100){
	            }
	    		if(progress==100){
	    		}
	    		
	    		super.onProgressChanged(view, progress);
	    	}
	    });
		
		
		
		
		
		
		
		/*btntemp.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//absolute.removeView(imagetemp);
				//absolute.removeView(btntemp);
			}
			
		});*/
        
		
		return view;
	}
	//�^�_������
    @Override
    public void onResume() {
        super.onResume();
        
        // For scenarios where the main activity is launched and user
		// session is not null, the session state change notification
		// may not be triggered. Trigger it if it's open/closed.
		Session session = Session.getActiveSession();
		if (session != null &&
				(session.isOpened() || session.isClosed()) ) {
			onSessionStateChange(session, session.getState(), null);
		}
		Log.i(TAG, "onresume");
        uiHelper.onResume();
        
        //��ĳ�n���o��m��T�ɳ����Y�h���s�^�����A�����w��覡
      	String provider = locationManager.getBestProvider(criteria, true);
      		
      	//�i�H�]�w�g�L�h�ֲ@���Τ��ث�z�LLocationListener�Ӻʱ��ۤv��m�O�_����
      	locationManager.requestLocationUpdates(provider, 10000 ,10, myLocationListener);
      	
      	if(inout==1)
      	{
      		updatedata.loadUrl("http://apps.facebook.com/bookroyt");
      		Log.e("tttttttttttttt", "up");
      	}
    }
    //���X�������B���ϥΪ̵n�J�����X�{��
    @Override
    public void onPause() {
    	locationManager.removeUpdates(myLocationListener);
        super.onPause();
        uiHelper.onPause();
        Log.i(TAG, "onpause");
    }
    //�����{��
    @Override
    public void onDestroy() {
        super.onDestroy();
        uiHelper.onDestroy();
        Log.i(TAG, "ondestroy");
    }
	
	
	//(fb)���n�J�I�s�n�J�����ɰ���B�n�J�����^�������ɡB�n�X
    private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(final Session session, final SessionState state, final Exception exception) {
            onSessionStateChange(session, state, exception);
            Log.i(TAG, "call function");
            
        }
    };
    
    //(fb)�n�J�����ɰ���
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uiHelper.onActivityResult(requestCode, resultCode, data);
        Log.i(TAG, "onactivityresult");
    }
    
    //���}���{���ɰO�����A
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        uiHelper.onSaveInstanceState(outState);
        Log.i(TAG, "onSaveInstanceState");
    }
    
    
    //�P�_�O�_�n�J
    private void onSessionStateChange(Session session, SessionState state, Exception exception) {
    	if (state.isOpened()) {
    		Log.i(TAG, "Logged in...");
    		//webtext.setBackgroundResource(R.drawable.textview_border);  //�[��
    		//webtext.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG); //�[���u
    		Request.executeMeRequestAsync(session, new Request.GraphUserCallback() {
				
				@Override
				public void onCompleted(GraphUser user, Response response) {
					// TODO Auto-generated method stub
					if(user!=null) {
						//TextView welcome = (TextView)findViewById(R.id.welcome);
						//welcome.setText("Hello " + user.getName() + "!!!" + user.getId());
						authButton.setVisibility(View.GONE);
						logbutton.setVisibility(View.VISIBLE);
						uid = user.getId();
						
						result = sendPostDataToInternet(uid,decideurl,0);
	        			try {
	        				ja = JSONDecode2();
	        			} catch (JSONException e) {
	        				// TODO Auto-generated catch block
	        				e.printStackTrace();
	        			}
	        			for (int i = 0; i < ja.length(); i++) {
	                        try {
	                        	JSONObject jsonObject = ja.getJSONObject(i);
	        					if(jsonObject.getString("id").equals("null"))
	        					{
	        						newuser=1;
	        					}
	        				} catch (JSONException e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	                    }
						if(uid.equals("100001303371482"))
						{
							newuser=2;
						}
						else
						{
							newuser=1;
							all15=1;
						}

						Log.i(TAG, user.getId() + "=" + user.getName());
						//txt.setText(uid);
						result = uid;
						//webtext.setText(result);
						//http://www.facebook.com/login.php
						//https://m.facebook.com/login.php
						//http://apps.facebook.com/androidroyt
						//�Y���[����Ψ禡�|�ϥΥ~�����s�����}�ҡA��]�O�]�������J�ɡAyahoo�P�_�O Mobile�ҥH��}�A�ӳo��}���ʧ@�ڭ̨èS���B�z�A�ҥH�N�|�}�ҹw�]���s�����s��
						myWebView.setWebViewClient(myWebViewClient);	//�h����H�ΤU�C�禡�A�i�H������ܦbapp��
						if(loging==0)
						{
							absolute.setBackgroundResource(R.drawable.login);
							Log.i("LLLLLLLLLLLLLLL", "msg");
							loging=1;
							myWebView.setLayoutParams(new LayoutParams(278,410));
							myWebView.setX(928);
							myWebView.setY(68);
							absolute.addView(myWebView);
							myWebView.loadUrl("https://m.facebook.com/login.php");
						}
						WebSettings webSettings = myWebView.getSettings();
						webSettings.setJavaScriptEnabled(true);
						
						
						updatedata.setWebViewClient(updatedataClient);	//�h����H�ΤU�C�禡�A�i�H������ܦbapp��
						WebSettings webSettingss = updatedata.getSettings();
						webSettingss.setJavaScriptEnabled(true);
						updatedata10.setWebViewClient(updatedata10Client);	//�h����H�ΤU�C�禡�A�i�H������ܦbapp��
						WebSettings webSettingss10 = updatedata10.getSettings();
						webSettingss10.setJavaScriptEnabled(true);
						updatedata60.setWebViewClient(updatedata60Client);	//�h����H�ΤU�C�禡�A�i�H������ܦbapp��
						WebSettings webSettingss60 = updatedata60.getSettings();
						webSettingss60.setJavaScriptEnabled(true);
					}
				}
			});
    		//txt.setText(uid);
        } else if (state.isClosed()) {
        	Log.i(TAG, "Logged out...");

        	session.getActiveSession().closeAndClearTokenInformation();
        	//super.onSaveInstanceState(null);
            //uiHelper.onSaveInstanceState(null);
        	authButton.setVisibility(View.VISIBLE);
        	logbutton.setVisibility(View.GONE);
        	txt.setText(null);
        	webtext.setText(null);
        	count = 0;
        	loging = 0;
        	absolute.removeView(rereadguide);
        	absolute.removeView(myWebView);
        	absolute.removeView(date);

        	absolute.removeView(myself);
        	absolute.removeView(myselfclick);
        	absolute.removeView(trunk);
        	absolute.removeView(newspaper);
        	absolute.removeView(likepic);
        	absolute.removeView(commentpic);
        	absolute.removeView(sharepic);
        	absolute.removeView(tagpic);
        	absolute.removeView(messagepic);
        	absolute.removeView(albumpic);
        	absolute.removeView(like);
        	absolute.removeView(comment);
        	absolute.removeView(share);
        	absolute.removeView(tag);
        	absolute.removeView(message);
        	absolute.removeView(album);
        	
        	absolute.removeView(mPhotoWall);
        	absolute.setBackgroundColor(0xFFFFFF);

        	for(int i = 0 ; i < 150 ; i++)
        	{
        		absolute.removeView(leafibtn[i]);
        	}
        	for(int i = 0 ; i < 6 ; i++)
        	{
        		absolute.removeView(recommendibtn[i]);
        	}
        	
        	inout = 0;
        }
    }
    
    //(webview)
    WebViewClient myWebViewClient = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			if(count==0)
			{
				myWebView.loadUrl("http://apps.facebook.com/bookroyt");
				Log.v("TTTTTTTTTTTTTTTTT","EWTRGDRAHAERHAERH");
				count=1;
				newusercount++;
				if(newuser==0)
				{
					loadingbackground = new ImageView(getActivity());
					loadingbackground.setBackgroundResource(R.drawable.loadingbacground);
					absolute.addView(loadingbackground,new AbsoluteLayout.LayoutParams(286, 420, 922, 60));
					loading = new TextView(getActivity());
					loading.setTextSize(40);
					loading.setTextColor(0xFFFFFFFF);
					loading.setText("Loading");
					absolute.addView(loading,new AbsoluteLayout.LayoutParams(278, 60, 995, 215));
	
					loadingdot = new TextView[10];
			        for(int i=0;i<10;i++)
			        {
			        	loadingdot[i] = new TextView(getActivity());
			        }
			        loadingdot[0].setTextSize(30);
					loadingdot[0].setTextColor(0xFF111111);
	                loadingdot[0].setText(".");
					absolute.addView(loadingdot[0],new AbsoluteLayout.LayoutParams(50, 50, 990, 275));
					for(int i=1;i<10;i++)
					{
						loadingdot[i].setTextSize(30);
						loadingdot[i].setTextColor(0xFFFFFFFF);
		                loadingdot[i].setText(".");
						absolute.addView(loadingdot[i],new AbsoluteLayout.LayoutParams(50, 50, 990+i*17, 275));
					}
					dynamicdot=1;
					Intent intent = new Intent();
					intent.setClass(getActivity(), Guide.class);
					startActivity(intent);
				}
			}
			else if(count==1)
			{
				Log.v("2222222TTTTTTTTTTTTTTTTT","EWTRGDRAHAERHAERH");
				count=2;
				newusercount++;
				if(all15==1)
				{
					newusercount=5;
				}
				
			}
			else if(newusercount==2)
			{
				Log.e("newusercountnewusercount", String.valueOf(newusercount));
				//count=3;
				newusercount++;
			}
			else if(newusercount==3)
			{
				Log.e("newusercountnewusercount", String.valueOf(newusercount));
				//count=4;
				newusercount++;
			}
			else if(newusercount==4)
			{
				Log.e("newusercountnewusercount", String.valueOf(newusercount));
				//count=5;
				jumptoshow = msecond;
				newusercount++;
			}
			else
			{
				Log.v("33333333333TTTTTTTTTTTTTTTTT","EWTRGDRAHAERHAERH");
			}
			return true;
		}
		

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
			handler.proceed();
			handler.cancel();
			handler.handleMessage(null);
		}
		//onReceivedSslError��webView�B�zssl�Үѳ]�m
		//�䤤handler.proceed();���ܵ����Ү��T��
		//handler.cancel();���ܱ��_�s���A���q�{�覡
		//handler.handleMessage(null);�i����L�B�z
		
		//�����]��
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
			//setContentView(R.layout.layout2);
			//txt.setText("��");
			Log.v("SSSSSSSSSSS","sssssssssssssssssss");
		}
	};
    //(webview)�мg��^��
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (myWebView.canGoBack() && event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
        	myWebView.goBack();
            return true;
        }

        //return super.onKeyDown(keyCode, event);
        return false;
    }
    
    
    //(webview)
    WebViewClient updatedataClient = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
		

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
			handler.proceed();
			handler.cancel();
			handler.handleMessage(null);
		}
		
		//�����]��
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
		}
	};
	//(webview)
    WebViewClient updatedata10Client = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
		

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
			handler.proceed();
			handler.cancel();
			handler.handleMessage(null);
		}
		
		//�����]��
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
		}
	};
	//(webview)
    WebViewClient updatedata60Client = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
		

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
			handler.proceed();
			handler.cancel();
			handler.handleMessage(null);
		}
		
		//�����]��
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
		}
	};
    
    
    //�ɶ��ܤƪ������
    class LooperThread extends Thread{
    	public void run(){
    		super.run();
    		try{
    			do{
    				long time = System.currentTimeMillis();
    				final Calendar mCalendar = Calendar.getInstance();
    				mCalendar.setTimeInMillis(time);
    				mYear = mCalendar.get(Calendar.YEAR);
    				mMonth = mCalendar.get(Calendar.MONTH);
    				mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
    				mWeek = mCalendar.get(Calendar.DAY_OF_WEEK);
    				mHour = mCalendar.get(Calendar.HOUR_OF_DAY);
    				mMinutes = mCalendar.get(Calendar.MINUTE);
    				msecond = mCalendar.get(Calendar.SECOND);
    				
    				realmMonth = mMonth + 1;
    				switch(mWeek)
    				{
    					case 1:
    						realmWeek = "�g��";
    						break;
    					case 2:
    						realmWeek = "�g�@";
    						break;
    					case 3:
    						realmWeek = "�g�G";
    						break;
    					case 4:
    						realmWeek = "�g�T";
    						break;
    					case 5:
    						realmWeek = "�g�|";
    						break;
    					case 6:
    						realmWeek = "�g��";
    						break;
    					case 7:
    						realmWeek = "�g��";
    						break;
    				}
    				Thread.sleep(500);
    				Message m = new Message();
    				m.what = MainFragment.GUINOTIFIER;
    				MainFragment.this.mHandler.sendMessage(m);
    			}while (MainFragment.LooperThread.interrupted() == false);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    	}
    }
    
    //�w��Ѯ�
    private void updateMyLocationInfo(Location myLocation){
		StringBuilder msgg = new StringBuilder();
		msgg.append("�ۤv��m������T\n");
		
		//�����q��ɶ�
		Date date = new Date(myLocation.getTime());
		DateFormat dateFormat = DateFormat.getDateTimeInstance();
		String time = dateFormat.format(date);
		msgg.append("�w��ɶ�: " + time + "\n");
		
		//���o�ۤv��m���g�n��
		msgg.append("�n��: " + myLocation.getLatitude() + "\n");
		msgg.append("�g��: " + myLocation.getLongitude() + "\n");
		msgg.append("��ǫ�(����): " + myLocation.getAccuracy() + "\n");
		msgg.append("����(����): " + myLocation.getAltitude() + "\n");
		
		StringBuilder builder = new StringBuilder(); 
		//builder.append("�n�סG").append(this.myLocation.getLatitude()).append("\n"); 
		//builder.append("�g�סG").append(this.myLocation.getLongitude()).append("\n"); 
		try { 
		    List<Address> addresses = new Geocoder(getActivity()).getFromLocation( 
		            myLocation.getLatitude(), myLocation.getLongitude(), 2); 
		    //if (addresses.size() > 0) { 
		        Address address = addresses.get(0);
		        //builder.append(address.getAddressLine(0)).append("\n");
		        builder.append(address.getAdminArea());
		        //builder.append(address.getSubAdminArea()).append("\n");
		        // for (Address address : addresses) { 
		        //for (int i = 0; i < address.getMaxAddressLineIndex(); i++) { 
		            //builder.append(address.getAddressLine(i)).append("\n"); 
		            // builder.append(address.getLocality()).append("\n"); 
		             //builder.append(address.getPostalCode()).append("\n");
		             //builder.append(address.getCountryName()); 
		       // } 
		        //tv.setText(builder);
		    //}
		    
			}catch (IOException e){
				Log.e(getClass().getName(), e.toString());
		    }
		    //tv.setText(builder);
		lolo = builder.toString();
		if(lolo.equals("�x�_��") || lolo.equals("�s�_��"))
        {
        	//city = "Taipei";
			city = "TWXX0021";
        }
        if(lolo.equals("�򶩥�"))
        {
        	//city = "Chilung";
        	city = "TWXX0003";
        }
        if(lolo.equals("��鿤"))
        {
        	//city = "T��ao-yuan";
        	city = "TWXX0025";
        }
        if(lolo.equals("�s�˿�") || lolo.equals("�s�˥�"))
        {
        	//city = "Hsin-chu";
        	city = "TWXX0009";
        }
        if(lolo.equals("�]�߿�"))
        {
        	//city = "Chu-nan";
        	//city = "10034496";
        	//city = "Miao-li";
        	city = "TWXX0014";
        }
        if(lolo.equals("�x����"))
        {
        	//city = "T��aichung";
        	city = "TWXX0019";
        }
        if(lolo.equals("���ƿ�"))
        {
        	//city = "Chang-hua";
        	city = "TWXX0001";
        }
        if(lolo.equals("�Ÿq��") || lolo.equals("�Ÿq��"))
        {
        	//city = "Chiayi";
        	city = "TWXX0002";
        }
        if(lolo.equals("�x�n��"))
        {
        	//city = "T��ainan";
        	city = "32433";
        }
        if(lolo.equals("������"))
        {
        	//city = "Kaohsiung";
        	city = "16133";
        }
        if(lolo.equals("�̪F��"))
        {
        	//city = "P��ingtung";
        	city = "24933";
        }
        if(lolo.equals("�y����"))
        {
        	//city = "Su-ao";
        	city = "TWXX0016";
        }
        if(lolo.equals("�Ὤ��"))
        {
        	//city = "Hua-lien";
        	city = "TWXX0011";
        }
        if(lolo.equals("�x�F��"))
        {
        	//city = "T��ai-tung";
        	city = "32435";
        }
        
        GetWeather gw = new GetWeather();
	    String str = gw.getWeather(city);
	    TomorrowWeatherV0 tomorrowWeatherV0 = TomorrowWeatherParse.parse(str);

	    /*if(tomorrowWeatherV0.getCurrentcondition().equals(35) || tomorrowWeatherV0.getCurrentcondition().equals(39)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(45) || tomorrowWeatherV0.getCurrentcondition().equals(46)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(9) || tomorrowWeatherV0.getCurrentcondition().equals(10)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(11) || tomorrowWeatherV0.getCurrentcondition().equals(12)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(40) || tomorrowWeatherV0.getCurrentcondition().equals(1)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(2) || tomorrowWeatherV0.getCurrentcondition().equals(3)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(4) || tomorrowWeatherV0.getCurrentcondition().equals(37)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(38) || tomorrowWeatherV0.getCurrentcondition().equals(47)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(5) || tomorrowWeatherV0.getCurrentcondition().equals(13)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(14) || tomorrowWeatherV0.getCurrentcondition().equals(15)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(16) || tomorrowWeatherV0.getCurrentcondition().equals(18)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(25) || tomorrowWeatherV0.getCurrentcondition().equals(41)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(42) || tomorrowWeatherV0.getCurrentcondition().equals(6)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(7) || tomorrowWeatherV0.getCurrentcondition().equals(8)
    			|| tomorrowWeatherV0.getCurrentcondition().equals(17))
	    {
	    	if(addrain==0)
			{
				rain[0].setBackgroundResource(R.drawable.rainpic);
				rain[1].setBackgroundResource(R.drawable.rainpic);
				absolute.addView(rain[0],new AbsoluteLayout.LayoutParams(1280, 2000, 0, -1000));
				absolute.addView(rain[1],new AbsoluteLayout.LayoutParams(1280, 2000, 0, -1000));
				addrain = 1;
				
				rainanimation = null;
				rainanimation = new TranslateAnimation(0,0,0,1000);
				rainanimation.setDuration(2000);
				rainanimation.setRepeatCount(Animation.INFINITE);
				rain[0].startAnimation(rainanimation);
				
				rainanimation2 = null;
				rainanimation2 = new TranslateAnimation(0,0,0,1000);
				rainanimation2.setStartOffset(1000);
				rainanimation2.setDuration(2000);
				rainanimation2.setRepeatCount(Animation.INFINITE);
				rain[1].startAnimation(rainanimation2);
			}
	    	else
	    	{
	    		addrain = 0;
    			rain[0].clearAnimation();
    			rain[1].clearAnimation();
				absolute.removeView(rain[0]);
				absolute.removeView(rain[1]);
	    	}
			
	        absolute.setBackgroundResource(R.drawable.rain);
	    }*/
	    /*txt.setText("��m�G" + tomorrowWeatherV0.getLocation() + "\n" + "���Ѥ���G" + tomorrowWeatherV0.getDate() + "   " + tomorrowWeatherV0.getDay()
	    		+ "\n" + "�{�b�ūסG" + tomorrowWeatherV0.getCurrenttemperature() + "�A�{�b�Ѯ𪬪p�G" + tomorrowWeatherV0.getCurrentcondition()
	    		+ "\n" + "���ѤѮ𪬪p�G" + tomorrowWeatherV0.getCondition() + "�A�̰���šG" + tomorrowWeatherV0.getHigh() + "�A�̧C��šG" + tomorrowWeatherV0.getLow()
	    		+ "\n" + "���Ѥ���G" + tomorrowWeatherV0.getDate2() + "   " + tomorrowWeatherV0.getDay2()
	    		+ "\n" + "���ѤѮ𪬪p�G" + tomorrowWeatherV0.getCondition2() + "�A�̰���šG" + tomorrowWeatherV0.getHigh2() + "�A�̧C��šG" + tomorrowWeatherV0.getLow2());*/
	}
	
	private LocationListener myLocationListener = new LocationListener(){
		@Override
		//��m���ܮɩI�s�öǤJ�s����m
		public void onLocationChanged(Location location){
			myLocation = location;
			updateMyLocationInfo(location);
		}
		
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras){
			switch(status){
			case LocationProvider.AVAILABLE:
				Toast.makeText(getActivity(),provider + "�i�H�ϥ�",
						Toast.LENGTH_SHORT).show();
				break;
			case LocationProvider.OUT_OF_SERVICE:
				Toast.makeText(getActivity(),
						provider + "�L�k���ѪA�ȥB�u�ɶ����L�k�^�_", Toast.LENGTH_SHORT)
						.show();
				break;
			case LocationProvider.TEMPORARILY_UNAVAILABLE:
				Toast.makeText(getActivity(), provider + "�ȮɵL�k�ϥ�,�����ӫܧִN�i�^�_",
						Toast.LENGTH_SHORT).show();
				break;
			}
		}
		
		@Override
		//�ϥΪ̱N�w��\��}�ҮɩI�s
		public void onProviderEnabled(String provider){
			Toast.makeText(getActivity(), provider + "�\��w�g�}��",
					Toast.LENGTH_SHORT).show();
		}
		
		@Override
		//�ϥΪ̱N�w��\�������ɩI�s
		public void onProviderDisabled(String provider){
			Toast.makeText(getActivity(), provider + "�\��w�g����",
					Toast.LENGTH_SHORT).show();
		}
		
		
	};
	
	private Address getAddress(String locationName){
		//�إ�Geocoder
		Geocoder geocoder = new Geocoder(getActivity());
		List<Address> addressList = null;
		
		try{
			//�Ѳ��a�W
			addressList = geocoder.getFromLocationName(locationName, 1);
		} catch (IOException e){
			Log.e(getClass().getName(), e.toString());
		}
		if (addressList == null || addressList.isEmpty()){
			return null;
		}else{
			return addressList.get(0);
		}
	}
	
    
    
    //�s��PHP����
    private String sendPostDataToInternet(String strTxt, String url, int identify)
    {
        /* �إ�HTTP Post�s�u */
        HttpPost httpRequest = new HttpPost(url);
        /*
         * Post�B�@�ǰe�ܼƥ�����NameValuePair[]�}�C�x�s
         */
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        if(identify==0)
        {
        	params.add(new BasicNameValuePair("uid", strTxt));
        }
        else if(identify==1)
        {
        	params.add(new BasicNameValuePair("friendid", strTxt));
        }
        try
        {
            /* �o�XHTTP request */
            httpRequest.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
            /* ���oHTTP response */
            HttpResponse httpResponse = new DefaultHttpClient().execute(httpRequest);
            /* �Y���A�X��200 ok */
            if (httpResponse.getStatusLine().getStatusCode() == 200)
            {
                /* ���X�^���r�� */
                String strResult = EntityUtils.toString(httpResponse.getEntity());
                // �^�Ǧ^���r��
                return strResult;
            }
        }
        catch (ClientProtocolException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (IOException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (Exception e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        return null;
    }
    
    //�M�������q��
    private String sendPostDataToInternetClear(String strTxt1, String strTxt2, String strTxt3, String strTxt4, String strTxt5, String url)
    {
        /* �إ�HTTP Post�s�u */
        HttpPost httpRequest = new HttpPost(url);
        /*
         * Post�B�@�ǰe�ܼƥ�����NameValuePair[]�}�C�x�s
         */
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        
        params.add(new BasicNameValuePair("uid", strTxt1));
        params.add(new BasicNameValuePair("fid", strTxt2));
        params.add(new BasicNameValuePair("event", strTxt3));
        params.add(new BasicNameValuePair("type", strTxt4));
        params.add(new BasicNameValuePair("typeid", strTxt5));
        
        try
        {
            /* �o�XHTTP request */
            httpRequest.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
            /* ���oHTTP response */
            HttpResponse httpResponse = new DefaultHttpClient().execute(httpRequest);
            /* �Y���A�X��200 ok */
            if (httpResponse.getStatusLine().getStatusCode() == 200)
            {
                /* ���X�^���r�� */
                String strResult = EntityUtils.toString(httpResponse.getEntity());
                // �^�Ǧ^���r��
                return strResult;
            }
        }
        catch (ClientProtocolException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (IOException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (Exception e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        return null;
    }
    
    
    //�ѪR���
    private JSONArray JSONDecode() throws JSONException {
        JSONArray jsonArray = new JSONArray(result);
        Log.i("Number of Entries", Integer.toString(jsonArray.length()));
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String id = jsonObject.getString("id");
            String name = jsonObject.getString("name");
            int social_point = jsonObject.getInt("social_point");
            String content = jsonObject.getString("content");
            int like_num = jsonObject.getInt("like_num");
            int comment_num = jsonObject.getInt("comment_num");
            int mood = jsonObject.getInt("mood");
            Log.i("Entry", "id: " + id + ", name: " + name + ", social_point: " + social_point);
            //resolve.setText("name: " + name + ", bet: " + bet);
            
        }
        return jsonArray;
    }
    //�ѪR���
    private JSONArray JSONDecode2() throws JSONException {
        JSONArray jsonArray = new JSONArray(result);
        Log.i("Number of Entries", Integer.toString(jsonArray.length()));
        
        return jsonArray;
    }
    //�ѪR���
    private JSONArray JSONDecodeAlbumlist() throws JSONException {
        JSONArray jsonArray = new JSONArray(result);
        Log.i("Number of Entries", Integer.toString(jsonArray.length()));
        
        return jsonArray;
    }
    
    //���l�ʧ@
    public Button.OnClickListener test = new Button.OnClickListener()
    {
    	public void onClick(View v)
    	{ 
    		//alertbox("�гy�X�Ӫ����s.","�ٶ� . �ڬO�� " + String.valueOf(v.getId()) + " �ӫ��s" + "\n" + "�ڬO " + fname[v.getId()] + " ������� = " + sp[v.getId()]);
    		//webtext.setText("�ڬO" + fname[v.getId()] + " ������� = " + sp[v.getId()]);
    		
    		afa[v.getId()]=255;
    		fallcondition[v.getId()] = 0;
    		leafibtn[v.getId()].clearAnimation();

    		friendnow = v.getId();
    		
			/*updatewall.setLayoutParams(new LayoutParams(200,200));
			updatewall.setX(0);
			updatewall.setY(0);
			absolute.addView(updatewall);
			updatewall.loadUrl("http://apps.facebook.com/bookroyt?fid=" + fid[v.getId()]);*/
    		
    		mempic = new ImageView(getActivity());
    		replacepic = new ImageView(getActivity());
    		wallnewsframe = new TextView(getActivity());
    		wallnews = new TextView(getActivity());
    		liketemp = new ImageView(getActivity());
    		liketempnumandlink = new Button(getActivity());
    		commenttemp = new ImageView(getActivity());
    		commenttempunmandlink = new Button(getActivity());
			underline = new TextView(getActivity());
			memname = new TextView(getActivity());
			meminfo = new TextView(getActivity());
			talkpic = new ImageView(getActivity());
			talk = new Button(getActivity());
			left = new ImageButton(getActivity());
			right = new ImageButton(getActivity());
			gotochat = new Button(getActivity());
    	if(havenotice[v.getId()]==1)
    	{
    		imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			imgbtntemp.setOnClickListener(new Button.OnClickListener(){
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					absolute.removeView(list);
					absolute.removeView(imgbtntemp);
				}
			});
			
    		havenotice[friendnow]=0;
    		/*usecount=usecount%100;
    		oldusecount1=oldusecount1%100;
    		oldusecount2=oldusecount2%100;
    		oldusecount3=oldusecount3%100;
    		oldusecount4=oldusecount4%100;*/

    		if(mood[friendnow]==0)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.normalb);
        	}
        	else if(mood[friendnow]==-1)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.badb);
        	}
        	else if(mood[friendnow]==-2)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.worstb);
        	}
        	else if(mood[friendnow]==1)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.goodb);
        	}
        	else if(mood[friendnow]==2)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.bestb);
        	}
    		
    		
    		noticewindowanimation = new AnimationSet(true);
    		noticewindowanimation.setFillAfter(true);

		
    		noticewindowtranslation = null;
    		noticewindowtranslation = new TranslateAnimation(0,50-leaf5x[friendnow],0,500-leaf5y[friendnow]);
    		noticewindowtranslation.setDuration(500);
    		noticewindowtranslation.setFillAfter(true);
			noticewindowanimation.addAnimation(noticewindowtranslation);
			
			noticewindowscale = null;
			noticewindowscale = new ScaleAnimation(0, 1, 0, 1);
			noticewindowscale.setDuration(500);
			noticewindowscale.setFillAfter(true);
			noticewindowanimation.addAnimation(noticewindowscale);
			
    		
    		list = new ListView(getActivity());
            //�����q���T��list
            ArrayList<String[]> alldata = new ArrayList<String[]>();
            /*for(int i = 0; i < fname.length; i++)
            {
            	alldata.add(createData(fname[i]));
            }*/
            for(int i=0;i<noticenum[friendnow];i++)
            {
            	Log.e("CCCCCCCCCCCCCCClllllllearrrrrrrrrr", uid + "___" + fid[friendnow] + "___" + personalnoticeevent[friendnow][i] + "___" + personalnoticetype[friendnow][i] + "___" + personalnoticetypeid[friendnow][i] + "___" + clearurl);
            	sendPostDataToInternetClear(uid, fid[friendnow], personalnoticeevent[friendnow][i], personalnoticetype[friendnow][i], personalnoticetypeid[friendnow][i], clearurl);
            if(personalnoticeevent[friendnow][i].equals("like"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "�I�F�A�@�i�Ӥ��g"));
            		likenum--;
            	}
            	else if(personalnoticetype[friendnow][i].equals("com"))
                {
            		alldata.add(createData(fname[friendnow] + "ı�o�u" + personalnoticecontent[friendnow][i] + "�v�g"));
            		likenum--;
                }
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "ı�o�u" + personalnoticecontent[friendnow][i] + "�v�g"));
                	likenum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("com"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "�^���F�u" + personalnoticecontent[friendnow][i] + "�v��@�i�Ӥ�"));
            		commentnum--;
            	}
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "�^���F�u" + personalnoticecontent[friendnow][i] + "�v��@�g�ʺA"));
                	commentnum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("tag"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "��A�аO��@�i�Ӥ�"));
            		tagnum--;
            	}
            	else if(personalnoticetype[friendnow][i].equals("com"))
                {
            		alldata.add(createData(fname[friendnow] + "��A�аO��u" + personalnoticecontent[friendnow][i] + "�v��"));
            		tagnum--;
                }
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "��A�аO��u" + personalnoticecontent[friendnow][i] + "�v��"));
                	tagnum--;
                }
                else if(personalnoticetype[friendnow][i].equals("checkin"))
                {
                	alldata.add(createData(fname[friendnow] + "�N�A�аO��@�Ӧa�I"));
                	tagnum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("msg"))
            {
            	alldata.add(createData(fname[friendnow] + "�ǤF�T�����A"));
            	messagenum--;
            }
            }
            if(likenum==0)
            {
            	absolute.removeView(likeibtn);
            }
            if(commentnum==0)
            {
            	absolute.removeView(commentibtn);
            }
            if(sharenum==0)
            {
            	absolute.removeView(shareibtn);
            }
            if(tagnum==0)
            {
            	absolute.removeView(tagibtn);
            }
            if(messagenum==0)
            {
            	absolute.removeView(messageibtn);
            }
            likeframe.setText(String.valueOf(likenum));
			commentframe.setText(String.valueOf(commentnum));
			shareframe.setText(String.valueOf(sharenum));
			tagframe.setText(String.valueOf(tagnum));
			messageframe.setText(String.valueOf(messagenum));
            list.setAdapter(new MydataAdapter(getActivity(),alldata));
            list.setTextFilterEnabled(true);
            list.setOnItemClickListener(new OnItemClickListener() {
    			@Override
    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
    				// TODO Auto-generated method stub
    				
    			}
            });
            /*list.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, fname));
            list.setTextFilterEnabled(true);
            list.setBackgroundResource(R.drawable.friendbackground);*/
            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, leaf5x[friendnow], leaf5y[friendnow]));
            list.startAnimation(noticewindowanimation);
            
            /*noticewindowanimation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					
                    
				}
			});*/
    		
    		
    		/*for(int i=0;i<5;i++)
			{
				noticetype[i].setBackgroundResource(R.drawable.like);
			}
			absolute.addView(notice[0][0][usecount],new AbsoluteLayout.LayoutParams(70,70, leaf5x[v.getId()], leaf5y[v.getId()]));
			
			
			noticetranslation = null;
			noticetranslation = new TranslateAnimation(0,leaf5x[v.getId()]-leaf5x[v.getId()],0,likey[0]-leaf5y[v.getId()]);
			noticetranslation.setDuration(800);
			noticetranslation.setFillAfter(true);
			
			noticeanimation = new AnimationSet(true);
			noticeanimation.setFillAfter(true);
			noticerotationset1 = null;
			noticerotationset1 = new RotateAnimation(0,720,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
			noticerotationset1.setDuration(1500);
			noticerotationset1.setFillAfter(true);
			noticeanimation.addAnimation(noticerotationset1);
			noticetranslationset1 = null;
			noticetranslationset1 = new TranslateAnimation(0,likex[1]-leaf5x[v.getId()],0,likey[1]-likey[0]);
			noticetranslationset1.setDuration(1500);
			noticetranslationset1.setFillAfter(true);
			noticeanimation.addAnimation(noticetranslationset1);
			
			noticeanimation2 = new AnimationSet(true);
			noticeanimation2.setFillAfter(true);
			noticerotationset2 = null;
			noticerotationset2 = new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
			noticerotationset2.setDuration(1000);
			noticerotationset2.setFillAfter(true);
			noticeanimation2.addAnimation(noticerotationset2);
			noticetranslationset2 = null;
			noticetranslationset2 = new TranslateAnimation(0,likex[2]-likex[1],0,likey[2]-likey[1]);
			noticetranslationset2.setDuration(1000);
			noticetranslationset2.setFillAfter(true);
			noticeanimation2.addAnimation(noticetranslationset2);
			
			noticetranslation2 = null;
			noticetranslation2 = new TranslateAnimation(0,likex[3]-likex[2],0,likey[3]-likey[2]);
			noticetranslation2.setDuration(1000);
			noticetranslation2.setFillAfter(true);

			notice[0][0][usecount].startAnimation(noticetranslation);
			usecount++;
			noticetranslation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					absolute.removeView(notice[0][0][oldusecount1]);
					absolute.addView(notice[0][1][oldusecount1],new AbsoluteLayout.LayoutParams(70,70, leaf5x[friendnow], likey[0]));
					notice[0][1][oldusecount1].startAnimation(noticeanimation);
					oldusecount1++;
					noticeanimation.setAnimationListener(new Animation.AnimationListener() {
						@Override public void onAnimationStart(Animation animation2) {
						}
						@Override public void onAnimationRepeat(Animation animation2) {
						}
						@Override public void onAnimationEnd(Animation animation2) {
							absolute.removeView(notice[0][1][oldusecount2]);
							absolute.addView(notice[0][2][oldusecount2],new AbsoluteLayout.LayoutParams(70,70, likex[1], likey[1]));
							notice[0][2][oldusecount2].startAnimation(noticeanimation2);
							oldusecount2++;
							noticeanimation2.setAnimationListener(new Animation.AnimationListener() {
								@Override public void onAnimationStart(Animation animation3) {
								}
								@Override public void onAnimationRepeat(Animation animation3) {
								}
								@Override public void onAnimationEnd(Animation animation3) {
									absolute.removeView(notice[0][2][oldusecount3]);
									absolute.addView(notice[0][3][oldusecount3],new AbsoluteLayout.LayoutParams(70,70, likex[2], likey[2]));
									notice[0][3][oldusecount3].startAnimation(noticetranslation2);
									oldusecount3++;
									noticetranslation2.setAnimationListener(new Animation.AnimationListener() {
										@Override public void onAnimationStart(Animation animation4) {
										}
										@Override public void onAnimationRepeat(Animation animation4) {
										}
										@Override public void onAnimationEnd(Animation animation4) {
											absolute.removeView(notice[0][3][oldusecount4]);
											oldusecount4++;
											likenum++;
											likeframe.setText(String.valueOf(likenum));
											
											//absolute.addView(noticetype[4],new AbsoluteLayout.LayoutParams(70,70, noticex[4], noticey[4]));
										}
				        			});
								}
		        			});
						}
        			});
				}
			});*/
    	}
    	else
    	{
			imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			
			
			
			friendanimation = new AnimationSet(true);
			friendanimation.setFillAfter(true);
			friendtranslation = null;
			friendtranslation = new TranslateAnimation(0,875-leaf5x[v.getId()],0,300-leaf5y[v.getId()]);
			friendtranslation.setDuration(500);
			friendtranslation.setFillAfter(true);
			friendanimation.addAnimation(friendtranslation);
			
			friendscale = null;
			friendscale = new ScaleAnimation(0, 1, 0, 1);
			friendscale.setDuration(500);
			friendscale.setFillAfter(true);
			friendanimation.addAnimation(friendscale);

			
			friendbackground = new ImageView(getActivity());
			friendbackground.setBackgroundResource(R.drawable.friendbackground);
    		absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, leaf5x[v.getId()], leaf5y[v.getId()]));
    		friendbackground.startAnimation(friendanimation);
    		friendanimation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					//mempic.setBackgroundResource(R.drawable.dusk);
					if(mood[friendnow]==0)
		        	{
						replacepic.setBackgroundResource(R.drawable.normalb);
		        	}
		        	else if(mood[friendnow]==-1)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.badb);
		        	}
		        	else if(mood[friendnow]==-2)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.worstb);
		        	}
		        	else if(mood[friendnow]==1)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.goodb);
		        	}
		        	else if(mood[friendnow]==2)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.bestb);
		        	}
					if(friendnow<52)
					{
						absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(60,60, leaf5x[friendnow], leaf5y[friendnow]));
					}
					else
					{
						absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(48,48, leaf5x[friendnow], leaf5y[friendnow]));
					}
					absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, 875, 240));
					//absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, leaf3x[friendnow]-4, leaf3y[friendnow]-4));
					// Create an object for subclass of AsyncTask
			        GetXMLTask task = new GetXMLTask();
			        // Execute the task
			        task.execute(new String[] { "http://graph.facebook.com/" + fid[friendnow] + "/picture" });
					
					/*underline.setText("                                                                                                       ");
					underline.setTextSize(24);
					underline.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
					absolute.addView(underline,new AbsoluteLayout.LayoutParams(700,100, 340, 220));*/
				
			        //wallnewsframe.setText(content[friendnow] + "\n\n\n  like = " + like_num[friendnow] + "	  comment = " + comment_num[friendnow]);
			        wallnewsframe.setTextSize(24);
			        wallnewsframe.setTextColor(0xFFFFFFFF);
			        wallnewsframe.setBackgroundResource(R.drawable.textview_border);
					absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
					
					wallnews.setText(content[friendnow]);
			        wallnews.setTextSize(18);
			        wallnews.setTextColor(0xFFFFFFFF);
			        //wallnewsframe.setBackgroundResource(R.drawable.textview_border);
					absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
					
					if(mood[friendnow]<0)
					{
						liketemp.setBackgroundResource(R.drawable.pat);
						absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
					}
					else
					{
						liketemp.setBackgroundResource(R.drawable.like);
						absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
					}
					liketempnumandlink.getBackground().setAlpha(0);
					liketempnumandlink.setText(String.valueOf(like_num[friendnow]));
					liketempnumandlink.setTextSize(18);
					liketempnumandlink.setTextColor(0xFFFFFFFF);
					absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
					commenttemp.setBackgroundResource(R.drawable.comment);
					absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
					commenttempunmandlink.getBackground().setAlpha(0);
					commenttempunmandlink.setText(String.valueOf(comment_num[friendnow]));
					commenttempunmandlink.setTextSize(18);
					commenttempunmandlink.setTextColor(0xFFFFFFFF);
					absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
				
					talkpic.setBackgroundResource(R.drawable.message);
					absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
					talk.getBackground().setAlpha(0);
					talk.setText("���˸��D");
					talk.setTextSize(18);
					talk.setTextColor(0xFFFFFFFF);
					absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
					talk.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							if(talkopencondition==0)
							{
								personhotcontent = sendPostDataToInternet(fid[friendnow],personalhoturl,1);
								absolute.removeView(friendbackground);
								absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,450, 875, 300));
								absolute.removeView(wallnewsframe);
								absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
								absolute.removeView(wallnews);
								absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
								absolute.removeView(liketemp);
								if(mood[friendnow]<0)
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
								}
								else
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
								}
								absolute.removeView(liketempnumandlink);
								absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
								absolute.removeView(commenttemp);
								absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
								absolute.removeView(commenttempunmandlink);
								absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
								absolute.removeView(talkpic);
								absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
								absolute.removeView(talk);
								absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
								absolute.removeView(btntemp);
								absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
								talkbackground = new ImageView(getActivity());
								talkbackground.setBackgroundResource(R.drawable.talkbackground);
								absolute.addView(talkbackground,new AbsoluteLayout.LayoutParams(330,190, 885, 555));
								talkframe = new TextView(getActivity());
								//if(personhotcontent.toString().equals(0))
								if(personhotcontent.equals(""))
								{
									talkframe.setText("�A���n�B�ͪ���S���o���!!\n���֥h���ߥL�a");
								}
								else
								{
									talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
								}
								talkframe.setTextSize(18);
								absolute.addView(talkframe,new AbsoluteLayout.LayoutParams(290,110, 905, 575));
								left.setBackgroundResource(R.drawable.left);
								absolute.addView(left,new AbsoluteLayout.LayoutParams(25,25, 1155, 550));
								left.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										newsindex--;
										if(newsindex<0)
										{
											newsindex=0;
										}
										if(newsindex!=0)
										{
											talkframe.setText(newstemp[newsindex-1]);
										}
										else
										{
											talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
										}
									}
								});
								right.setBackgroundResource(R.drawable.right);
								absolute.addView(right,new AbsoluteLayout.LayoutParams(25,25, 1180, 550));
								right.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										newsindex++;
										if(newsindex>newstemp.length)
										{
											newsindex=newstemp.length;
										}
										if(newsindex!=0)
										{
											talkframe.setText(newstemp[newsindex-1]);
										}
										else
										{
											talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
										}
									}
								});
								gotochat.setText("Go to chat");
								gotochat.getBackground().setAlpha(0);
								absolute.addView(gotochat,new AbsoluteLayout.LayoutParams(200,50, 1050, 685));
								gotochat.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										String url="http://www.facebook.com/messages/" + fid[friendnow];
										Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
										startActivity(ie);
									}
								});
								talkopencondition=1;
							}
							else
							{
								absolute.removeView(friendbackground);
								absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, 875, 300));
								absolute.removeView(wallnewsframe);
								absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
								absolute.removeView(wallnews);
								absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
								absolute.removeView(liketemp);
								if(mood[friendnow]<0)
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
								}
								else
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
								}
								absolute.removeView(liketempnumandlink);
								absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
								absolute.removeView(commenttemp);
								absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
								absolute.removeView(commenttempunmandlink);
								absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
								absolute.removeView(talkpic);
								absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
								absolute.removeView(talk);
								absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
								absolute.removeView(btntemp);
								absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
								absolute.removeView(talkbackground);
								absolute.removeView(talkframe);
								absolute.removeView(left);
								absolute.removeView(right);
								absolute.removeView(gotochat);
								talkopencondition=0;
							}
						}
					});
					
				
					memname.setText(fname[friendnow]);
					memname.setTextSize(30);
					memname.setTextColor(0xFFFFFFFF);
					absolute.addView(memname,new AbsoluteLayout.LayoutParams(350,50, 940, 255));
				
					//meminfo.setText("�ʧO\n�ͤ�\n�u�@\n�s��\n���NŪ");
					//meminfo.setTextSize(18);
					//absolute.addView(meminfo,new AbsoluteLayout.LayoutParams(200,200, 360, 440));


					
					btntemp = new Button(getActivity());
					btntemp.getBackground().setAlpha(0);

					btntemp.setBackgroundResource(R.drawable.x);
					absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
					btntemp.setOnClickListener(new Button.OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							absolute.removeView(friendbackground);
							absolute.removeView(imgbtntemp);
							absolute.removeView(btntemp);
							absolute.removeView(mempic);
							absolute.removeView(replacepic);
							absolute.removeView(wallnewsframe);
							absolute.removeView(wallnews);
							absolute.removeView(liketemp);
							absolute.removeView(liketempnumandlink);
							absolute.removeView(commenttemp);
							absolute.removeView(commenttempunmandlink);
							//absolute.removeView(underline);
							absolute.removeView(talkpic);
							absolute.removeView(talk);
							if(talkopencondition==1)
							{
								absolute.removeView(talkbackground);
								absolute.removeView(talkframe);
								talkopencondition=0;
								absolute.removeView(left);
								absolute.removeView(right);
								absolute.removeView(gotochat);
							}
							absolute.removeView(memname);
							newsindex=0;
							downloadImageBitmap.recycle();
							doInBackgroundBitmap.recycle();
							outputBitmap.recycle();
							//absolute.removeView(updatewall);
							//absolute.removeView(meminfo);
						}
						
					});
				}
			});


			/*imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundResource(R.drawable.b147);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1540,1540, -55, -320));
			animation3 = null;
			animation3 = new ScaleAnimation(0, 1, 0, 1);
			animation3.setStartOffset(1000);
			animation2.setDuration(500);
			imgbtntemp.startAnimation(animation3);*/
			
    	}
			
    	}
    };
    
    //���l�����ʧ@
    public Button.OnLongClickListener test2 = new Button.OnLongClickListener()
    {
		@Override
		public boolean onLongClick(View v) {
			// TODO Auto-generated method stub
			groupshow=1;
			imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			//�s�ؤ@�ӷs����X�Ϥ�
			linkline = Bitmap.createBitmap(1280, 1625, Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(linkline);
			Paint paint = new Paint();
			paint.setColor(Color.YELLOW);
			paint.setStrokeWidth((float)4.0);

			imgbtntemp.setOnClickListener(new Button.OnClickListener(){
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					linkline.recycle();
					absolute.removeView(imgbtntemp);
					absolute.removeView(memcircle);
					absolute.removeView(mempic);
					absolute.removeView(memname);
					for(int i=0;i<groupcount;i++)
					{
						absolute.removeView(memgroupcircle[i]);
						absolute.removeView(memgrouppic[i]);
						//absolute.removeView(memgroupname[i]);
						if(groupdoInBackgroundBitmap[i]!=null)
						{
							groupdoInBackgroundBitmap[i].recycle();
						}
						if(groupdownloadImageBitmap[i]!=null)
						{
							groupdownloadImageBitmap[i].recycle();
						}
						if(groupoutputBitmap[i]!=null)
						{
							groupoutputBitmap[i].recycle();
						}
						doInBackgroundBitmap.recycle();
						downloadImageBitmap.recycle();
						outputBitmap.recycle();
					}
					groupcount=0;
				}
			});
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			
			groupresult = sendPostDataToInternet(fid[v.getId()],groupurl,1);
			
			String[] relative = groupresult.split(",");
			
			memgrouppic = new ImageView[relative.length];
			memgroupcircle = new ImageView[relative.length];
			//memgroupname = new TextView[relative.length];
	        
			for(int i = 0; i < relative.length; i++)
			{
				Log.e("tttttttttttttttttttttttttttttt", relative[i]);
				
				for(int j=0;j<150;j++)
				{
					if(relative[i].equals(fid[j]))
					{
						memgroupcircle[groupcount] = new ImageView(getActivity());
						memgroupcircle[groupcount].setBackgroundResource(R.drawable.groupcircle);
						memgrouppic[groupcount] = new ImageView(getActivity());
						/*memgroupname[groupcount] = new TextView(getActivity());
						memgroupname[groupcount].setTextSize(24);
						memgroupname[groupcount].setTextColor(0xFFFF0000);
						memgroupname[groupcount].setText(fname[j]);*/
						//mempic.setBackgroundResource(R.drawable.dusk);
						//memgrouppic[i].setBackgroundResource(R.drawable.ic_launcher);
						absolute.addView(memgroupcircle[groupcount],new AbsoluteLayout.LayoutParams(80, 78, leaf5x[j]-12, leaf5y[j]-11));
						absolute.addView(memgrouppic[groupcount],new AbsoluteLayout.LayoutParams(60, 60, leaf5x[j]-4, leaf5y[j]-4));
						//absolute.addView(memgroupname[groupcount],new AbsoluteLayout.LayoutParams(125, 150, leaf2x[j]-5, leaf2y[j]-35));
						canvas.drawLine(leaf5x[v.getId()]+20, leaf5y[v.getId()]+20, leaf5x[j]+20, leaf5y[j]+20, paint);
						// Create an object for subclass of AsyncTask
						if(groupcount==0)
						{
							GetXMLTaskGroup1 taskGroup1 = new GetXMLTaskGroup1();
					        // Execute the task
							taskGroup1.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==1)
						{
							GetXMLTaskGroup2 taskGroup2 = new GetXMLTaskGroup2();
					        // Execute the task
							taskGroup2.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==2)
						{
							GetXMLTaskGroup3 taskGroup3 = new GetXMLTaskGroup3();
					        // Execute the task
							taskGroup3.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==3)
						{
							GetXMLTaskGroup4 taskGroup4 = new GetXMLTaskGroup4();
					        // Execute the task
							taskGroup4.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==4)
						{
							GetXMLTaskGroup5 taskGroup5 = new GetXMLTaskGroup5();
					        // Execute the task
							taskGroup5.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==5)
						{
							GetXMLTaskGroup6 taskGroup6 = new GetXMLTaskGroup6();
					        // Execute the task
							taskGroup6.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==6)
						{
							GetXMLTaskGroup7 taskGroup7 = new GetXMLTaskGroup7();
					        // Execute the task
							taskGroup7.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==7)
						{
							GetXMLTaskGroup8 taskGroup8 = new GetXMLTaskGroup8();
					        // Execute the task
							taskGroup8.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==8)
						{
							GetXMLTaskGroup9 taskGroup9 = new GetXMLTaskGroup9();
					        // Execute the task
							taskGroup9.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==9)
						{
							GetXMLTaskGroup10 taskGroup10 = new GetXMLTaskGroup10();
					        // Execute the task
							taskGroup10.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==10)
						{
							GetXMLTaskGroup11 taskGroup11 = new GetXMLTaskGroup11();
					        // Execute the task
							taskGroup11.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==11)
						{
							GetXMLTaskGroup12 taskGroup12 = new GetXMLTaskGroup12();
					        // Execute the task
							taskGroup12.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==12)
						{
							GetXMLTaskGroup13 taskGroup13 = new GetXMLTaskGroup13();
					        // Execute the task
							taskGroup13.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==13)
						{
							GetXMLTaskGroup14 taskGroup14 = new GetXMLTaskGroup14();
					        // Execute the task
							taskGroup14.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==14)
						{
							GetXMLTaskGroup15 taskGroup15 = new GetXMLTaskGroup15();
					        // Execute the task
							taskGroup15.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==15)
						{
							GetXMLTaskGroup16 taskGroup16 = new GetXMLTaskGroup16();
					        // Execute the task
							taskGroup16.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==16)
						{
							GetXMLTaskGroup17 taskGroup17 = new GetXMLTaskGroup17();
					        // Execute the task
							taskGroup17.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==17)
						{
							GetXMLTaskGroup18 taskGroup18 = new GetXMLTaskGroup18();
					        // Execute the task
							taskGroup18.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==18)
						{
							GetXMLTaskGroup19 taskGroup19 = new GetXMLTaskGroup19();
					        // Execute the task
							taskGroup19.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
						else if(groupcount==19)
						{
							GetXMLTaskGroup20 taskGroup20 = new GetXMLTaskGroup20();
					        // Execute the task
							taskGroup20.execute(new String[] { "http://graph.facebook.com/" + relative[i] + "/picture" });
						}
				        
				        groupcount++;
				        break;
					}
				}
				if(groupcount==7)
				{
					break;
				}
			}
			imgbtntemp.setImageBitmap(linkline);
			groupshow=0;
			memcircle = new ImageView(getActivity());
			mempic = new ImageView(getActivity());
			//memname = new TextView(getActivity());

			memcircle.setBackgroundResource(R.drawable.groupcircle);
			absolute.addView(memcircle,new AbsoluteLayout.LayoutParams(80, 78, leaf5x[v.getId()]-12, leaf5y[v.getId()]-11));
			//mempic.setBackgroundResource(R.drawable.dusk);
			absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60, 60, leaf5x[v.getId()]-4, leaf5y[v.getId()]-4));
			// Create an object for subclass of AsyncTask
	        GetXMLTask task = new GetXMLTask();
	        // Execute the task
	        task.execute(new String[] { "http://graph.facebook.com/" + fid[v.getId()] + "/picture" });
		
			//memname.setText(fname[v.getId()]);
			//memname.setTextSize(24);
			//memname.setTextColor(0xFFFF0000);
			//absolute.addView(memname,new AbsoluteLayout.LayoutParams(125,150, leaf2x[v.getId()]-5, leaf2y[v.getId()]-35));

			return true;
		}
    };
    
    
    public Button.OnClickListener testnewuser = new Button.OnClickListener()
    {
    	public void onClick(View v)
    	{ 
    		//alertbox("�гy�X�Ӫ����s.","�ٶ� . �ڬO�� " + String.valueOf(v.getId()) + " �ӫ��s" + "\n" + "�ڬO " + fname[v.getId()] + " ������� = " + sp[v.getId()]);
    		//webtext.setText("�ڬO" + fname[v.getId()] + " ������� = " + sp[v.getId()]);
    		
    		afa[v.getId()]=255;
    		fallcondition[v.getId()] = 0;
    		leafibtn[v.getId()].clearAnimation();

    		friendnow = v.getId();
    		
			/*updatewall.setLayoutParams(new LayoutParams(200,200));
			updatewall.setX(0);
			updatewall.setY(0);
			absolute.addView(updatewall);
			updatewall.loadUrl("http://apps.facebook.com/bookroyt?fid=" + fid[v.getId()]);*/
    		
    		mempic = new ImageView(getActivity());
    		replacepic = new ImageView(getActivity());
    		wallnewsframe = new TextView(getActivity());
    		wallnews = new TextView(getActivity());
    		liketemp = new ImageView(getActivity());
    		liketempnumandlink = new Button(getActivity());
    		commenttemp = new ImageView(getActivity());
    		commenttempunmandlink = new Button(getActivity());
			underline = new TextView(getActivity());
			memname = new TextView(getActivity());
			meminfo = new TextView(getActivity());
			talkpic = new ImageView(getActivity());
			talk = new Button(getActivity());
			left = new ImageButton(getActivity());
			right = new ImageButton(getActivity());
			gotochat = new Button(getActivity());
    	if(havenotice[v.getId()]==1)
    	{
    		imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			imgbtntemp.setOnClickListener(new Button.OnClickListener(){
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					absolute.removeView(list);
					absolute.removeView(imgbtntemp);
				}
			});
			
    		havenotice[friendnow]=0;
    		/*usecount=usecount%100;
    		oldusecount1=oldusecount1%100;
    		oldusecount2=oldusecount2%100;
    		oldusecount3=oldusecount3%100;
    		oldusecount4=oldusecount4%100;*/

    		if(mood[friendnow]==0)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.normalb);
        	}
        	else if(mood[friendnow]==-1)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.badb);
        	}
        	else if(mood[friendnow]==-2)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.worstb);
        	}
        	else if(mood[friendnow]==1)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.goodb);
        	}
        	else if(mood[friendnow]==2)
        	{
        		leafibtn[friendnow].setBackgroundResource(R.drawable.bestb);
        	}
    		
    		
    		noticewindowanimation = new AnimationSet(true);
    		noticewindowanimation.setFillAfter(true);

		
    		noticewindowtranslation = null;
    		noticewindowtranslation = new TranslateAnimation(0,50-leaf1x[friendnow],0,500-leaf1y[friendnow]);
    		noticewindowtranslation.setDuration(500);
    		noticewindowtranslation.setFillAfter(true);
			noticewindowanimation.addAnimation(noticewindowtranslation);
			
			noticewindowscale = null;
			noticewindowscale = new ScaleAnimation(0, 1, 0, 1);
			noticewindowscale.setDuration(500);
			noticewindowscale.setFillAfter(true);
			noticewindowanimation.addAnimation(noticewindowscale);
			
    		
    		list = new ListView(getActivity());
            //�����q���T��list
            ArrayList<String[]> alldata = new ArrayList<String[]>();
            /*for(int i = 0; i < fname.length; i++)
            {
            	alldata.add(createData(fname[i]));
            }*/
            for(int i=0;i<noticenum[friendnow];i++)
            {
            	Log.e("CCCCCCCCCCCCCCClllllllearrrrrrrrrr", uid + "___" + fid[friendnow] + "___" + personalnoticeevent[friendnow][i] + "___" + personalnoticetype[friendnow][i] + "___" + personalnoticetypeid[friendnow][i] + "___" + clearurl);
            	sendPostDataToInternetClear(uid, fid[friendnow], personalnoticeevent[friendnow][i], personalnoticetype[friendnow][i], personalnoticetypeid[friendnow][i], clearurl);
            if(personalnoticeevent[friendnow][i].equals("like"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "�I�F�A�@�i�Ӥ��g"));
            		likenum--;
            	}
            	else if(personalnoticetype[friendnow][i].equals("com"))
                {
            		alldata.add(createData(fname[friendnow] + "ı�o�u" + personalnoticecontent[friendnow][i] + "�v�g"));
            		likenum--;
                }
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "ı�o�u" + personalnoticecontent[friendnow][i] + "�v�g"));
                	likenum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("com"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "�^���F�u" + personalnoticecontent[friendnow][i] + "�v��@�i�Ӥ�"));
            		commentnum--;
            	}
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "�^���F�u" + personalnoticecontent[friendnow][i] + "�v��@�g�ʺA"));
                	commentnum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("tag"))
            {
            	if(personalnoticetype[friendnow][i].equals("pic"))
            	{
            		alldata.add(createData(fname[friendnow] + "��A�аO��@�i�Ӥ�"));
            		tagnum--;
            	}
            	else if(personalnoticetype[friendnow][i].equals("com"))
                {
            		alldata.add(createData(fname[friendnow] + "��A�аO��u" + personalnoticecontent[friendnow][i] + "�v��"));
            		tagnum--;
                }
                else if(personalnoticetype[friendnow][i].equals("po"))
                {
                	alldata.add(createData(fname[friendnow] + "��A�аO��u" + personalnoticecontent[friendnow][i] + "�v��"));
                	tagnum--;
                }
                else if(personalnoticetype[friendnow][i].equals("checkin"))
                {
                	alldata.add(createData(fname[friendnow] + "�N�A�аO��@�Ӧa�I"));
                	tagnum--;
                }
            }
            else if(personalnoticeevent[friendnow][i].equals("msg"))
            {
            	alldata.add(createData(fname[friendnow] + "�ǤF�T�����A"));
            	messagenum--;
            }
            }
            if(likenum==0)
            {
            	absolute.removeView(likeibtn);
            }
            if(commentnum==0)
            {
            	absolute.removeView(commentibtn);
            }
            if(sharenum==0)
            {
            	absolute.removeView(shareibtn);
            }
            if(tagnum==0)
            {
            	absolute.removeView(tagibtn);
            }
            if(messagenum==0)
            {
            	absolute.removeView(messageibtn);
            }
            likeframe.setText(String.valueOf(likenum));
			commentframe.setText(String.valueOf(commentnum));
			shareframe.setText(String.valueOf(sharenum));
			tagframe.setText(String.valueOf(tagnum));
			messageframe.setText(String.valueOf(messagenum));
            list.setAdapter(new MydataAdapter(getActivity(),alldata));
            list.setTextFilterEnabled(true);
            list.setOnItemClickListener(new OnItemClickListener() {
    			@Override
    			public void onItemClick(AdapterView<?> arg0, View arg1, int position, long idd) {
    				// TODO Auto-generated method stub
    				
    			}
            });
            /*list.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, fname));
            list.setTextFilterEnabled(true);
            list.setBackgroundResource(R.drawable.friendbackground);*/
            absolute.addView(list,new AbsoluteLayout.LayoutParams(350,225, leaf1x[friendnow], leaf1y[friendnow]));
            list.startAnimation(noticewindowanimation);
            
            /*noticewindowanimation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					
                    
				}
			});*/
    		
    		
    		/*for(int i=0;i<5;i++)
			{
				noticetype[i].setBackgroundResource(R.drawable.like);
			}
			absolute.addView(notice[0][0][usecount],new AbsoluteLayout.LayoutParams(70,70, leaf5x[v.getId()], leaf5y[v.getId()]));
			
			
			noticetranslation = null;
			noticetranslation = new TranslateAnimation(0,leaf5x[v.getId()]-leaf5x[v.getId()],0,likey[0]-leaf5y[v.getId()]);
			noticetranslation.setDuration(800);
			noticetranslation.setFillAfter(true);
			
			noticeanimation = new AnimationSet(true);
			noticeanimation.setFillAfter(true);
			noticerotationset1 = null;
			noticerotationset1 = new RotateAnimation(0,720,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
			noticerotationset1.setDuration(1500);
			noticerotationset1.setFillAfter(true);
			noticeanimation.addAnimation(noticerotationset1);
			noticetranslationset1 = null;
			noticetranslationset1 = new TranslateAnimation(0,likex[1]-leaf5x[v.getId()],0,likey[1]-likey[0]);
			noticetranslationset1.setDuration(1500);
			noticetranslationset1.setFillAfter(true);
			noticeanimation.addAnimation(noticetranslationset1);
			
			noticeanimation2 = new AnimationSet(true);
			noticeanimation2.setFillAfter(true);
			noticerotationset2 = null;
			noticerotationset2 = new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
			noticerotationset2.setDuration(1000);
			noticerotationset2.setFillAfter(true);
			noticeanimation2.addAnimation(noticerotationset2);
			noticetranslationset2 = null;
			noticetranslationset2 = new TranslateAnimation(0,likex[2]-likex[1],0,likey[2]-likey[1]);
			noticetranslationset2.setDuration(1000);
			noticetranslationset2.setFillAfter(true);
			noticeanimation2.addAnimation(noticetranslationset2);
			
			noticetranslation2 = null;
			noticetranslation2 = new TranslateAnimation(0,likex[3]-likex[2],0,likey[3]-likey[2]);
			noticetranslation2.setDuration(1000);
			noticetranslation2.setFillAfter(true);

			notice[0][0][usecount].startAnimation(noticetranslation);
			usecount++;
			noticetranslation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					absolute.removeView(notice[0][0][oldusecount1]);
					absolute.addView(notice[0][1][oldusecount1],new AbsoluteLayout.LayoutParams(70,70, leaf5x[friendnow], likey[0]));
					notice[0][1][oldusecount1].startAnimation(noticeanimation);
					oldusecount1++;
					noticeanimation.setAnimationListener(new Animation.AnimationListener() {
						@Override public void onAnimationStart(Animation animation2) {
						}
						@Override public void onAnimationRepeat(Animation animation2) {
						}
						@Override public void onAnimationEnd(Animation animation2) {
							absolute.removeView(notice[0][1][oldusecount2]);
							absolute.addView(notice[0][2][oldusecount2],new AbsoluteLayout.LayoutParams(70,70, likex[1], likey[1]));
							notice[0][2][oldusecount2].startAnimation(noticeanimation2);
							oldusecount2++;
							noticeanimation2.setAnimationListener(new Animation.AnimationListener() {
								@Override public void onAnimationStart(Animation animation3) {
								}
								@Override public void onAnimationRepeat(Animation animation3) {
								}
								@Override public void onAnimationEnd(Animation animation3) {
									absolute.removeView(notice[0][2][oldusecount3]);
									absolute.addView(notice[0][3][oldusecount3],new AbsoluteLayout.LayoutParams(70,70, likex[2], likey[2]));
									notice[0][3][oldusecount3].startAnimation(noticetranslation2);
									oldusecount3++;
									noticetranslation2.setAnimationListener(new Animation.AnimationListener() {
										@Override public void onAnimationStart(Animation animation4) {
										}
										@Override public void onAnimationRepeat(Animation animation4) {
										}
										@Override public void onAnimationEnd(Animation animation4) {
											absolute.removeView(notice[0][3][oldusecount4]);
											oldusecount4++;
											likenum++;
											likeframe.setText(String.valueOf(likenum));
											
											//absolute.addView(noticetype[4],new AbsoluteLayout.LayoutParams(70,70, noticex[4], noticey[4]));
										}
				        			});
								}
		        			});
						}
        			});
				}
			});*/
    	}
    	else
    	{
			imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			
			
			
			friendanimation = new AnimationSet(true);
			friendanimation.setFillAfter(true);
			friendtranslation = null;
			friendtranslation = new TranslateAnimation(0,875-leaf1x[v.getId()],0,300-leaf1y[v.getId()]);
			friendtranslation.setDuration(500);
			friendtranslation.setFillAfter(true);
			friendanimation.addAnimation(friendtranslation);
			
			friendscale = null;
			friendscale = new ScaleAnimation(0, 1, 0, 1);
			friendscale.setDuration(500);
			friendscale.setFillAfter(true);
			friendanimation.addAnimation(friendscale);

			
			friendbackground = new ImageView(getActivity());
			friendbackground.setBackgroundResource(R.drawable.friendbackground);
    		absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, leaf1x[v.getId()], leaf1y[v.getId()]));
    		friendbackground.startAnimation(friendanimation);
    		friendanimation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					//mempic.setBackgroundResource(R.drawable.dusk);
					if(mood[friendnow]==0)
		        	{
						replacepic.setBackgroundResource(R.drawable.normalb);
		        	}
		        	else if(mood[friendnow]==-1)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.badb);
		        	}
		        	else if(mood[friendnow]==-2)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.worstb);
		        	}
		        	else if(mood[friendnow]==1)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.goodb);
		        	}
		        	else if(mood[friendnow]==2)
		        	{
		        		replacepic.setBackgroundResource(R.drawable.bestb);
		        	}
					if(friendnow<52)
					{
						absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(60,60, leaf1x[friendnow], leaf1y[friendnow]));
					}
					else
					{
						absolute.addView(replacepic,new AbsoluteLayout.LayoutParams(48,48, leaf1x[friendnow], leaf1y[friendnow]));
					}
					absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, 875, 240));
					//absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, leaf3x[friendnow]-4, leaf3y[friendnow]-4));
					// Create an object for subclass of AsyncTask
			        GetXMLTask task = new GetXMLTask();
			        // Execute the task
			        task.execute(new String[] { "http://graph.facebook.com/" + fid[friendnow] + "/picture" });
					
					/*underline.setText("                                                                                                       ");
					underline.setTextSize(24);
					underline.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
					absolute.addView(underline,new AbsoluteLayout.LayoutParams(700,100, 340, 220));*/
				
			        //wallnewsframe.setText(content[friendnow] + "\n\n\n  like = " + like_num[friendnow] + "	  comment = " + comment_num[friendnow]);
			        wallnewsframe.setTextSize(24);
			        wallnewsframe.setTextColor(0xFFFFFFFF);
			        wallnewsframe.setBackgroundResource(R.drawable.textview_border);
					absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
					
					wallnews.setText(content[friendnow]);
			        wallnews.setTextSize(18);
			        wallnews.setTextColor(0xFFFFFFFF);
			        //wallnewsframe.setBackgroundResource(R.drawable.textview_border);
					absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
					
					if(mood[friendnow]<0)
					{
						liketemp.setBackgroundResource(R.drawable.pat);
						absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
					}
					else
					{
						liketemp.setBackgroundResource(R.drawable.like);
						absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
					}
					liketempnumandlink.getBackground().setAlpha(0);
					liketempnumandlink.setText(String.valueOf(like_num[friendnow]));
					liketempnumandlink.setTextSize(18);
					liketempnumandlink.setTextColor(0xFFFFFFFF);
					absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
					commenttemp.setBackgroundResource(R.drawable.comment);
					absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
					commenttempunmandlink.getBackground().setAlpha(0);
					commenttempunmandlink.setText(String.valueOf(comment_num[friendnow]));
					commenttempunmandlink.setTextSize(18);
					commenttempunmandlink.setTextColor(0xFFFFFFFF);
					absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
				
					talkpic.setBackgroundResource(R.drawable.message);
					absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
					talk.getBackground().setAlpha(0);
					talk.setText("���˸��D");
					talk.setTextSize(18);
					talk.setTextColor(0xFFFFFFFF);
					absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
					talk.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							if(talkopencondition==0)
							{
								personhotcontent = sendPostDataToInternet(fid[friendnow],personalhoturl,1);
								absolute.removeView(friendbackground);
								absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,450, 875, 300));
								absolute.removeView(wallnewsframe);
								absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
								absolute.removeView(wallnews);
								absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
								absolute.removeView(liketemp);
								if(mood[friendnow]<0)
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
								}
								else
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
								}
								absolute.removeView(liketempnumandlink);
								absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
								absolute.removeView(commenttemp);
								absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
								absolute.removeView(commenttempunmandlink);
								absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
								absolute.removeView(talkpic);
								absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
								absolute.removeView(talk);
								absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
								absolute.removeView(btntemp);
								absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
								talkbackground = new ImageView(getActivity());
								talkbackground.setBackgroundResource(R.drawable.talkbackground);
								absolute.addView(talkbackground,new AbsoluteLayout.LayoutParams(330,190, 885, 555));
								talkframe = new TextView(getActivity());
								//if(personhotcontent.toString().equals(0))
								if(personhotcontent.equals(""))
								{
									talkframe.setText("�A���n�B�ͪ���S���o���!!\n���֥h���ߥL�a");
								}
								else
								{
									talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
								}
								talkframe.setTextSize(18);
								absolute.addView(talkframe,new AbsoluteLayout.LayoutParams(290,110, 905, 575));
								left.setBackgroundResource(R.drawable.left);
								absolute.addView(left,new AbsoluteLayout.LayoutParams(25,25, 1155, 550));
								left.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										newsindex--;
										if(newsindex<0)
										{
											newsindex=0;
										}
										if(newsindex!=0)
										{
											talkframe.setText(newstemp[newsindex-1]);
										}
										else
										{
											talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
										}
									}
								});
								right.setBackgroundResource(R.drawable.right);
								absolute.addView(right,new AbsoluteLayout.LayoutParams(25,25, 1180, 550));
								right.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										newsindex++;
										if(newsindex>newstemp.length)
										{
											newsindex=newstemp.length;
										}
										if(newsindex!=0)
										{
											talkframe.setText(newstemp[newsindex-1]);
										}
										else
										{
											talkframe.setText("��A���n�B�Ͳ��L�̪񪺨Ƨa!\n" + personhotcontent);
										}
									}
								});
								gotochat.setText("Go to chat");
								gotochat.getBackground().setAlpha(0);
								absolute.addView(gotochat,new AbsoluteLayout.LayoutParams(200,50, 1050, 685));
								gotochat.setOnClickListener(new Button.OnClickListener(){
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										String url="http://www.facebook.com/messages/" + fid[friendnow];
										Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
										startActivity(ie);
									}
								});
								talkopencondition=1;
							}
							else
							{
								absolute.removeView(friendbackground);
								absolute.addView(friendbackground,new AbsoluteLayout.LayoutParams(350,275, 875, 300));
								absolute.removeView(wallnewsframe);
								absolute.addView(wallnewsframe,new AbsoluteLayout.LayoutParams(300,200, 885, 310));
								absolute.removeView(wallnews);
								absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(290,152, 890, 315));
								absolute.removeView(liketemp);
								if(mood[friendnow]<0)
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(40,40, 1022, 462));
								}
								else
								{
									absolute.addView(liketemp,new AbsoluteLayout.LayoutParams(50,50, 1020, 460));
								}
								absolute.removeView(liketempnumandlink);
								absolute.addView(liketempnumandlink,new AbsoluteLayout.LayoutParams(60,60, 1050, 455));
								absolute.removeView(commenttemp);
								absolute.addView(commenttemp,new AbsoluteLayout.LayoutParams(50,50, 1100, 460));
								absolute.removeView(commenttempunmandlink);
								absolute.addView(commenttempunmandlink,new AbsoluteLayout.LayoutParams(60,60, 1130, 455));
								absolute.removeView(talkpic);
								absolute.addView(talkpic,new AbsoluteLayout.LayoutParams(40,40, 885, 520));
								absolute.removeView(talk);
								absolute.addView(talk,new AbsoluteLayout.LayoutParams(125,40, 895, 520));
								absolute.removeView(btntemp);
								absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
								absolute.removeView(talkbackground);
								absolute.removeView(talkframe);
								absolute.removeView(left);
								absolute.removeView(right);
								absolute.removeView(gotochat);
								talkopencondition=0;
							}
						}
					});
					
				
					memname.setText(fname[friendnow]);
					memname.setTextSize(30);
					memname.setTextColor(0xFFFFFFFF);
					absolute.addView(memname,new AbsoluteLayout.LayoutParams(350,50, 940, 255));
				
					//meminfo.setText("�ʧO\n�ͤ�\n�u�@\n�s��\n���NŪ");
					//meminfo.setTextSize(18);
					//absolute.addView(meminfo,new AbsoluteLayout.LayoutParams(200,200, 360, 440));


					
					btntemp = new Button(getActivity());
					btntemp.getBackground().setAlpha(0);

					btntemp.setBackgroundResource(R.drawable.x);
					absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 1185, 300));
					btntemp.setOnClickListener(new Button.OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							absolute.removeView(friendbackground);
							absolute.removeView(imgbtntemp);
							absolute.removeView(btntemp);
							absolute.removeView(mempic);
							absolute.removeView(replacepic);
							absolute.removeView(wallnewsframe);
							absolute.removeView(wallnews);
							absolute.removeView(liketemp);
							absolute.removeView(liketempnumandlink);
							absolute.removeView(commenttemp);
							absolute.removeView(commenttempunmandlink);
							//absolute.removeView(underline);
							absolute.removeView(talkpic);
							absolute.removeView(talk);
							if(talkopencondition==1)
							{
								absolute.removeView(talkbackground);
								absolute.removeView(talkframe);
								talkopencondition=0;
								absolute.removeView(left);
								absolute.removeView(right);
								absolute.removeView(gotochat);
							}
							absolute.removeView(memname);
							newsindex=0;
							downloadImageBitmap.recycle();
							doInBackgroundBitmap.recycle();
							outputBitmap.recycle();
							//absolute.removeView(updatewall);
							//absolute.removeView(meminfo);
						}
						
					});
				}
			});


			/*imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundResource(R.drawable.b147);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1540,1540, -55, -320));
			animation3 = null;
			animation3 = new ScaleAnimation(0, 1, 0, 1);
			animation3.setStartOffset(1000);
			animation2.setDuration(500);
			imgbtntemp.startAnimation(animation3);*/
			
    	}
			
    	}
    };
    
    
    //���˦n�͸��l�ʧ@
    public Button.OnClickListener recommendwindow = new Button.OnClickListener()
    {
    	public void onClick(View v)
    	{ 

    		friendnow = v.getId();
    		
    		
    		recommendbackground = new ImageView(getActivity());
    		recommendsendmessagepic = new ImageView(getActivity());
    		recommendadd = new ImageButton(getActivity());
			recommendsendmessage = new Button(getActivity());
			mempic = new ImageView(getActivity());
    	
			imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			
			
			
			friendanimation = new AnimationSet(true);
			friendanimation.setFillAfter(true);
			friendtranslation = null;
			friendtranslation = new TranslateAnimation(0,75-recommendfriend3x[v.getId()],0,500-recommendfriend3y[v.getId()]);
			friendtranslation.setDuration(500);
			friendtranslation.setFillAfter(true);
			friendanimation.addAnimation(friendtranslation);
			
			friendscale = null;
			friendscale = new ScaleAnimation(0, 1, 0, 1);
			friendscale.setDuration(500);
			friendscale.setFillAfter(true);
			friendanimation.addAnimation(friendscale);

			
			recommendbackground = new ImageView(getActivity());
			recommendbackground.setBackgroundResource(R.drawable.recommendbackground);
    		absolute.addView(recommendbackground,new AbsoluteLayout.LayoutParams(350,150, recommendfriend3x[v.getId()], recommendfriend3y[v.getId()]));
    		recommendbackground.startAnimation(friendanimation);
    		friendanimation.setAnimationListener(new Animation.AnimationListener() {
				@Override public void onAnimationStart(Animation animation) {
				}
				@Override public void onAnimationRepeat(Animation animation) {
				}
				@Override public void onAnimationEnd(Animation animation) {
					//mempic.setBackgroundResource(R.drawable.dusk);
					absolute.addView(mempic,new AbsoluteLayout.LayoutParams(60,60, 100, 525));
					// Create an object for subclass of AsyncTask
			        GetXMLTask task = new GetXMLTask();
			        // Execute the task
			        task.execute(new String[] { "http://graph.facebook.com/" + recommendid[friendnow] + "/picture" });
					
			        recommendadd.setBackgroundResource(R.drawable.addfriend);
					absolute.addView(recommendadd,new AbsoluteLayout.LayoutParams(77,26, 200, 550));
					recommendadd.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							String url="http://www.facebook.com/" + recommendid[friendnow];
							Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
							startActivity(ie);
						}
					});
					
					recommendsendmessagepic.setBackgroundResource(R.drawable.message);
					absolute.addView(recommendsendmessagepic,new AbsoluteLayout.LayoutParams(40,40, 210, 600));
					recommendsendmessage.getBackground().setAlpha(0);
					recommendsendmessage.setText("Send a message");
					recommendsendmessage.setTextSize(15);
					recommendsendmessage.setTextColor(0xFFFFFFFF);
					absolute.addView(recommendsendmessage,new AbsoluteLayout.LayoutParams(150,40, 225, 600));
					recommendsendmessage.setOnClickListener(new Button.OnClickListener(){
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							String url="http://www.facebook.com/messages/" + recommendid[friendnow];
							Intent ie = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
							startActivity(ie);
						}
					});

					
					btntemp = new Button(getActivity());
					btntemp.getBackground().setAlpha(0);

					btntemp.setBackgroundResource(R.drawable.x);
					absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(40,40, 385, 500));
					btntemp.setOnClickListener(new Button.OnClickListener() {
						@Override
						public void onClick(View arg0) {
							// TODO Auto-generated method stub
							absolute.removeView(recommendbackground);
							absolute.removeView(imgbtntemp);
							absolute.removeView(btntemp);
							absolute.removeView(mempic);
							absolute.removeView(recommendsendmessagepic);
							absolute.removeView(recommendadd);
							absolute.removeView(recommendsendmessage);
						}
					});
				}
			});
			
    	}
    };
    
    
    
    
    public Button.OnClickListener hot = new Button.OnClickListener()
    {
    	public void onClick(View v)
    	{ 
    		/*animation = null;
			animation = new TranslateAnimation(0,620-flowerx[v.getId()],0,405-flowery[v.getId()]);
			//animation = new ScaleAnimation(1, 3, 1, 3);
			animation.setDuration(100);
			//animation.setFillAfter(true);
			flowerbtn[v.getId()].startAnimation(animation);
    	
			imgbtntemp = new ImageButton(getActivity());
			imgbtntemp.setBackgroundColor(0x7f000000);
			//imgbtntemp.getBackground().setAlpha(255);
			absolute.addView(imgbtntemp,new AbsoluteLayout.LayoutParams(1280,1625, 0, 0));
			
			imagetemp = new ImageView(getActivity());
			imagetemp.setBackgroundResource(R.drawable.flowerclick);
    		absolute.addView(imagetemp,new AbsoluteLayout.LayoutParams(70,70, 620, 405));
    		animation2 = null;
			animation2 = new ScaleAnimation(0,19,0,19,35,35);
			animation2.setStartOffset(100);
			animation2.setDuration(100);
			animation2.setFillAfter(true);
			imagetemp.startAnimation(animation2);
			
			
			mempic = new ImageView(getActivity());
			wallnews = new TextView(getActivity());
			underline = new TextView(getActivity());
			memname = new TextView(getActivity());
			meminfo = new TextView(getActivity());
			talk = new TextView(getActivity());
			
			//mempic.setBackgroundResource(R.drawable.dusk);
			absolute.addView(mempic,new AbsoluteLayout.LayoutParams(100,100, 360, 280));
			// Create an object for subclass of AsyncTask
	        GetXMLTask task = new GetXMLTask();
	        // Execute the task
	        task.execute(new String[] { "http://graph.facebook.com/" + hotid[v.getId()] + "/picture" });
		
			wallnews.setText("");
			wallnews.setTextSize(24);
			//wallnews.setTextColor(0xFFFFFF00);
			//wallnews.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
			absolute.addView(wallnews,new AbsoluteLayout.LayoutParams(700,100, 340, 220));
			
			underline.setText("                                                                                                       ");
			underline.setTextSize(24);
			underline.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
			absolute.addView(underline,new AbsoluteLayout.LayoutParams(700,100, 340, 220));
		
			talk.setText(hotcontent[v.getId()] + "\n\n\n	like = " + hot_like_num[v.getId()] + "		comment = " + hot_comment_num[v.getId()]);
			talk.setTextSize(24);
			talk.setBackgroundResource(R.drawable.textview_border);
			absolute.addView(talk,new AbsoluteLayout.LayoutParams(440,220, 500, 280));
		
			memname.setText(hotname[v.getId()]);
			memname.setTextSize(30);
			absolute.addView(memname,new AbsoluteLayout.LayoutParams(125,150, 360, 395));
		
			flowerbtn[v.getId()].setBackgroundResource(R.drawable.flower);
			
			btntemp = new Button(getActivity());
			btntemp.getBackground().setAlpha(0);

			btntemp.setBackgroundResource(R.drawable.x);
			absolute.addView(btntemp,new AbsoluteLayout.LayoutParams(100,100, 1000, 150));
			btntemp.setOnClickListener(new Button.OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					absolute.removeView(imagetemp);
					absolute.removeView(imgbtntemp);
					absolute.removeView(btntemp);
					absolute.removeView(mempic);
					absolute.removeView(wallnews);
					absolute.removeView(underline);
					absolute.removeView(talk);
					absolute.removeView(memname);
					//absolute.removeView(meminfo);
				}
				
			});*/
			
			
    	}
    };
    
    
    //��ܹ�ܤ��
    protected void alertbox(String title, String mymessage)
    {
      new AlertDialog.Builder(getActivity())
         .setMessage(mymessage)
         .setTitle(title)
         .setCancelable(true)
         .setNeutralButton(android.R.string.ok,
            new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton){}
            })
         .show();
    }
    
    
    
    private class GetXMLTaskMyself extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	myself.setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
    
    
    
    private class GetXMLTask extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	doInBackgroundBitmap = null;
            for (String url : urls) {
            	doInBackgroundBitmap = downloadImage(url);
            }
            Log.e("Bitmap doinbackground", doInBackgroundBitmap.toString());
            return doInBackgroundBitmap;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	mempic.setImageBitmap(createStarPhoto(500,500,result));
        	Log.e("Bitmap onPostExecute", result.toString());
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	downloadImageBitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                downloadImageBitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            Log.e("Bitmap downloadImage", downloadImageBitmap.toString());
            return downloadImageBitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
    
    //�I���B��(���)
    private Bitmap createStarPhoto(int x, int y, Bitmap image)
	{
		//�ھڨӷ����s�ؤ@��drawable��H
		Drawable imageDrawable = new BitmapDrawable(image);

		//�s�ؤ@�ӷs����X�Ϥ�
		outputBitmap = Bitmap.createBitmap(x, y, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(outputBitmap);

		//�s�ؤ@�ӯx��
		RectF outerRect = new RectF(0, 0, x, y);
		//���ͤ@�Ӭ��⪺�ꨤ�x��
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(Color.RED);
		canvas.drawCircle(250, 250, 200, paint);
		
		//�N�ӷ��Ϥ�ø�s��o�Ӷꨤ�x�ΤW
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		imageDrawable.setBounds(0, 0, x, y);
		canvas.saveLayer(outerRect, paint, Canvas.ALL_SAVE_FLAG);
		imageDrawable.draw(canvas);
		canvas.restore();
		Log.e("Bitmap createStarPhoto", outputBitmap.toString());
		image.recycle();
		return outputBitmap;
	}
    
    
    
    
    
    //����
    private void initMediaPlayer() {

		
		mPlayer = MediaPlayer.create(getActivity().getApplicationContext(), R.raw.cloudsound);

		mPlayer.setOnPreparedListener(new OnPreparedListener() {
			public void onPrepared(MediaPlayer mp) {


			}
		});


		mPlayer.setOnCompletionListener(new OnCompletionListener() {

			public void onCompletion(MediaPlayer mp) {

				stop();
			}
		});
	}
	private void stop() {
		mPlayer.stop();

		try {
			mPlayer.prepare();
			mPlayer.seekTo(0);

		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	private void play() {

		mPlayer.start();
	}
	private void pause() {
		mPlayer.pause();
	}
	
	
	
	
	
	
	private class GetXMLTask1 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[0] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[0] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[0];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[0].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[0] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[0] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[0];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask2 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[1] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[1] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[1];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[1].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[1] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[1] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[1];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask3 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[2] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[2] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[2];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[2].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[2] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[2] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[2];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask4 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[3] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[3] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[3];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[3].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[3] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[3] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[3];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask5 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[4] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[4] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[4];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[4].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[4] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[4] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[4];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask6 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[5] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[5] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[5];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[5].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[5] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[5] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[5];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask7 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[6] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[6] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[6];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[6].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[6] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[6] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[6];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTask8 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	hotdoInBackgroundBitmap[7] = null;
            for (String url : urls) {
            	hotdoInBackgroundBitmap[7] = downloadImage(url);
            }
            return hotdoInBackgroundBitmap[7];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	hotpic[7].setImageBitmap(result);
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	hotdownloadImageBitmap[7] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                hotdownloadImageBitmap[7] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return hotdownloadImageBitmap[7];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	
	
	
	
	private class GetXMLTaskGroup1 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[0] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[0] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[0];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[0].setImageBitmap(createStarPhotoGroup(500,500,result,0));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[0] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[0] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[0];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup2 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[1] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[1] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[1];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[1].setImageBitmap(createStarPhotoGroup(500,500,result,1));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[1] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[1] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[1];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup3 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[2] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[2] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[2];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[2].setImageBitmap(createStarPhotoGroup(500,500,result,2));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[2] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[2] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[2];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup4 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[3] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[3] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[3];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[3].setImageBitmap(createStarPhotoGroup(500,500,result,3));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[3] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[3] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[3];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup5 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[4] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[4] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[4];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[4].setImageBitmap(createStarPhotoGroup(500,500,result,4));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[4] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[4] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[4];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup6 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[5] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[5] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[5];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[5].setImageBitmap(createStarPhotoGroup(500,500,result,5));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[5] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[5] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[5];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup7 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[6] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[6] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[6];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[6].setImageBitmap(createStarPhotoGroup(500,500,result,6));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[6] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[6] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[6];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup8 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[7] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[7] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[7];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[7].setImageBitmap(createStarPhotoGroup(500,500,result,7));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[7] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[7] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[7];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup9 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[8] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[8] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[8];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[8].setImageBitmap(createStarPhotoGroup(500,500,result,8));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[8] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[8] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[8];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup10 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
        	groupdoInBackgroundBitmap[9] = null;
            for (String url : urls) {
            	groupdoInBackgroundBitmap[9] = downloadImage(url);
            }
            return groupdoInBackgroundBitmap[9];
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[9].setImageBitmap(createStarPhotoGroup(500,500,result,9));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
        	groupdownloadImageBitmap[9] = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                groupdownloadImageBitmap[9] = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return groupdownloadImageBitmap[9];
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup11 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[10].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup12 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[11].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup13 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[12].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup14 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[13].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup15 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[14].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup16 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[15].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup17 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[16].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup18 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[17].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup19 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[18].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	private class GetXMLTaskGroup20 extends AsyncTask<String, Void, Bitmap> {
        @Override
        protected Bitmap doInBackground(String... urls) {
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
            }
            return map;
        }
 
        // Sets the Bitmap returned by doInBackground
        @Override
        protected void onPostExecute(Bitmap result) {
        	memgrouppic[19].setImageBitmap(createStarPhoto(500,500,result));
        	result.recycle();
        }
 
        // Creates Bitmap from InputStream and returns it
        private Bitmap downloadImage(String url) {
            Bitmap bitmap = null;
            InputStream stream = null;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inSampleSize = 1;
            
            try {
                stream = getHttpConnection(url);
                bitmap = BitmapFactory.
                        decodeStream(stream, null, bmOptions);
                stream.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            return bitmap;
        }
 
        // Makes HttpURLConnection and returns InputStream
        private InputStream getHttpConnection(String urlString)
                throws IOException {
            InputStream stream = null;
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
 
            try {
                HttpURLConnection httpConnection = (HttpURLConnection) connection;
                httpConnection.setRequestMethod("GET");
                httpConnection.connect();
 
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    stream = httpConnection.getInputStream();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return stream;
        }
    }
	
	//�I���B��(���)(group�M��)
    private Bitmap createStarPhotoGroup(int x, int y, Bitmap image, int index)
	{
		//�ھڨӷ����s�ؤ@��drawable��H
		Drawable imageDrawable = new BitmapDrawable(image);

		//�s�ؤ@�ӷs����X�Ϥ�
		groupoutputBitmap[index] = Bitmap.createBitmap(x, y, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(groupoutputBitmap[index]);

		//�s�ؤ@�ӯx��
		RectF outerRect = new RectF(0, 0, x, y);
		//���ͤ@�Ӭ��⪺�ꨤ�x��
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(Color.RED);
		canvas.drawCircle(250, 250, 200, paint);
		
		//�N�ӷ��Ϥ�ø�s��o�Ӷꨤ�x�ΤW
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		imageDrawable.setBounds(0, 0, x, y);
		canvas.saveLayer(outerRect, paint, Canvas.ALL_SAVE_FLAG);
		imageDrawable.draw(canvas);
		canvas.restore();
		Log.e("Bitmap createStarPhoto", groupoutputBitmap[index].toString());
		image.recycle();
		return groupoutputBitmap[index];
	}
	
	
	/** �إ�UI Thread�ϥΪ�Handler�A�ӱ�����LThread�Ӫ��T�� */
    Handler mHandlernews = new Handler()
    {
          @Override
          public void handleMessage(Message msg)
          {
        	  newstemp = new String[Arr_RssNews.length];
               switch (msg.what)
               {
               // ��s��ơA�NRss�s�D�����D�ΰj��̧ǦL�X��
               case REFRESH_DATA:
                    for (int i = 0; i < Arr_RssNews.length; i++)
                    {
                    	newstemp[i] = Arr_RssNews[i].getTitle();
                          //result_edtxt.append(Arr_RssNews[i].getTitle() + "\n");
                    }
                    break;
               }
          }
    };
    /**
     * �q�����^��RSS����ơ]�ݭn�f�t������^
     * @return Rss�s�D������}�C
     */
    public RssNews[] getRssNews()
    {
          if (trgUrl == null)
               return null;
          try
          {
               // �إߤ@��Parser����A�ë��w�^���W�h (ParsingHandler)
               SimpleXMLParser dataXMLParser = new SimpleXMLParser(
               new RssNewsXMLParsingHandler());
               // �I�sgetData��k���o����}�C
               Object[] data = (Object[]) dataXMLParser.getData(trgUrl);
               if (data != null)
               {
                    // �p�G��ƧκA���T�A�N�^��
                    if (data[0] instanceof RssNews[])
                    {
                          return (RssNews[]) data[0];
                    }
               }

          } catch (SAXException e)
          {
               e.printStackTrace();
          } catch (IOException e)
          {
               e.printStackTrace();
          } catch (ParserConfigurationException e)
          {
               e.printStackTrace();
          }
          
          // �Y�����~�h�^��null
          return null;
    }
    
    
    private String[] createData(String text){
		String temp[]={text};
		return temp;
	}

}
