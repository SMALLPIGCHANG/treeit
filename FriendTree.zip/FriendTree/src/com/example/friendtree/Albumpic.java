package com.example.friendtree;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.widget.GridView;

public class Albumpic extends Activity {
	
	private String albumpicturl = "http://cell5.widelab.org/~b9929061/android/albumpic.php";
	private String result;
	private JSONArray ja;
	private String[] albumpicture;
	private String[] picturefrom;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);       															//�h�����ε{�����D
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);	//�h����������Abar
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);											//�ù���V
		setContentView(R.layout.albumpicture);
		
		String albumid;
		
		// �إ� Bundle ����
        Bundle bundle = this.getIntent().getExtras();
        albumid = bundle.getString("albumid");
        
        GridView gridView = (GridView) findViewById(R.id.gridview);
		List<ImageAndText> list = new ArrayList<ImageAndText>();
        
        result = sendPostDataToInternet(albumid,albumpicturl);
        try {
			ja = JSONDecode();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        albumpicture = new String[ja.length()];
        picturefrom = new String[ja.length()];
        
		for (int i = 0; i < ja.length(); i++) {
            try {
            	JSONObject jsonObject = ja.getJSONObject(i);
            	albumpicture[i] = jsonObject.getString("pictureurl");
            	picturefrom[i] = jsonObject.getString("picturefrom");
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        for(int i=0;i<albumpicture.length;i++)
        {
        	list.add(new ImageAndText(albumpicture[i], picturefrom[i]));
        	Log.e("ajetiojaweyiogjiawojrioawjo", albumpicture[i]);
        }
		
        gridView.setAdapter(new ImageAndTextListAdapter(this, list, gridView, 0));
	}

	
	//�s��PHP����
    private String sendPostDataToInternet(String strTxt, String url)
    {
        /* �إ�HTTP Post�s�u */
        HttpPost httpRequest = new HttpPost(url);
        /*
         * Post�B�@�ǰe�ܼƥ�����NameValuePair[]�}�C�x�s
         */
        List<NameValuePair> params = new ArrayList<NameValuePair>();

        params.add(new BasicNameValuePair("albumid", strTxt));

        try
        {
            /* �o�XHTTP request */
            httpRequest.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));
            /* ���oHTTP response */
            HttpResponse httpResponse = new DefaultHttpClient().execute(httpRequest);
            /* �Y���A�X��200 ok */
            if (httpResponse.getStatusLine().getStatusCode() == 200)
            {
                /* ���X�^���r�� */
                String strResult = EntityUtils.toString(httpResponse.getEntity());
                // �^�Ǧ^���r��
                return strResult;
            }
        }
        catch (ClientProtocolException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (IOException e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        catch (Exception e)
        {
            //Toast.makeText(this, e.getMessage().toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        return null;
    }
    //�ѪR���
    private JSONArray JSONDecode() throws JSONException {
        JSONArray jsonArray = new JSONArray(result);
        
        return jsonArray;
    }
	
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.friend_tree, menu);
		return true;
	}
}
