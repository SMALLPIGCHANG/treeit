package com.example.friendtree;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class TomorrowWeatherParse {

	//�ѪR�Ѯ�w���r�Ŧꦨ�@�ӤѮ�H����H
	public static TomorrowWeatherV0 parse(String googleWeatherString) {

		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

		TomorrowWeatherV0 tomorrowWeatherV0 = new TomorrowWeatherV0();

		try {
			XMLReader xmlReader = saxParserFactory.newSAXParser().getXMLReader();
			handler handler = new handler(tomorrowWeatherV0);
			xmlReader.setContentHandler(handler);

			xmlReader.parse(new InputSource(new StringReader(googleWeatherString)));

		} catch (SAXException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return tomorrowWeatherV0;

	}

}