package com.example.friendtree;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;


public class SimpleXMLParser {

protected SimpleXMLParsingHandler xmlParsingHandler;
	
    /**
     * �غc�l�A�����NxmlParsingHandler��new�X��
     *
     */
    public SimpleXMLParser(SimpleXMLParsingHandler parser)
    {
          xmlParsingHandler = parser;
    }


    /**
     * �qXML����R�X����
     *
     * @param inputStream
     *            �ӷ���FileInputStream
     * @return�^�ǥ]�t����}�C����� (�^�ǥi�H���u�@�Ӫ���}�C)
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws IOException
     */
    public Object[] getData(InputStream inputStream) throws SAXException,
               IOException, ParserConfigurationException
    {
          Object[] data;
          /* ����SAXParser���� */
          SAXParserFactory spf = SAXParserFactory.newInstance();
          SAXParser sp = spf.newSAXParser();
          /* ����XMLReader���� */
          XMLReader xr = sp.getXMLReader();
          /* �]�w�۩w�q��MyHandler��XMLReader */
          if (xmlParsingHandler == null)
          {
               throw new NullPointerException("xmlParsingHandler is null");
          } else
          {
               xr.setContentHandler(xmlParsingHandler);
               /* �ѪRXML */
               xr.parse(new InputSource(inputStream));
               /* ���oRSS���D�P���e�C�� */
               data = (Object[]) xmlParsingHandler.getParsedData();
          }
          inputStream.close();
          return data;
    }


    /**
     * �qXML����R�X���� (�h����k)
     *
     * @param urlPath
     *            url���}
     * @throws IOException
     * @throws SAXException
     * @throws ParserConfigurationException
     */
    public Object[] getData(String urlPath) throws SAXException, IOException,
               ParserConfigurationException
    {
          URL url = new URL(urlPath);
          HttpURLConnection uc = (HttpURLConnection) url.openConnection();
          uc.setConnectTimeout(15000);
          uc.setReadTimeout(15000); // �]�wtimeout�ɶ�
          uc.connect(); // �}�l�s�u
          int status = uc.getResponseCode();
          if (status == HttpURLConnection.HTTP_OK)
          {
               Object[] data = getData(url.openStream());
               return data;
          }
          return null;
    }
}
