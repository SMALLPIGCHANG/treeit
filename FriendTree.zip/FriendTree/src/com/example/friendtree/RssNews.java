package com.example.friendtree;

public class RssNews {

	private String title = null;
    private String link = null;
    private String pubDate = null;


    public void setTitle(String title)
    {
          this.title = title;
    }


    public String getTitle()
    {
          return title;
    }


    public void setLink(String link)
    {

          this.link = link;
    }


    public String getLink()
    {

          return link;
    }


    public void setPubDate(String pubDate)
    {
          this.pubDate = pubDate;
    }


    public String getPubDate()
    {
          return pubDate;
    }


    @Override
    public String toString()

    {
          return "RssNews [title=" + title + ", link=" + link + ", pubDate=" + pubDate + "]";
    }
}
