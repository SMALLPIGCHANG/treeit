package com.example.friendtree;

import java.util.Stack;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public abstract class SimpleXMLParsingHandler extends DefaultHandler {

	protected static final String TAG = "ParsingHandler";

    /** XML�ѪRNode�����| */
    private Stack<String> in_node;
    public Stack<String> getInNode()
    {
          return in_node;
    }


    /** �����Ҧ�(��ʳ]�w��true�|���Log) */
    private boolean debugMode = false;
    /**
     * �N�ഫ����Ʀ^��
     */
    public abstract Object getParsedData();
    /**
     * XML���}�l�ѪR�ɩI�s��method�A�o�̭n�[�Wnew�X�ۭq�����󪺵{��
     */
    @Override
    public void startDocument() throws SAXException
    {
          in_node = new Stack<String>();
    }


    /**
     * XML��󵲧��ѪR�ɩI�s��method
     */
    @Override
    public void endDocument() throws SAXException
    {
    }


    /**
     * �ѪR��Element���}�Y�ɩI�s��method
     */
    @Override
    public void startElement(String namespaceURI, String localName,
               String qName, Attributes atts) throws SAXException
    {
          if (isDebugMode())
          {
               Log.v(TAG, "startElement:    qName=" + qName);
               for (int i = 0; i < atts.getLength(); i++)
               {
                    Log.v(TAG, "\t\t atts[" + i + "]getQName=" + atts.getQName(i));
                    Log.v(TAG, "\t\t atts[" + i + "]getValue=" + atts.getValue(i));
               }
          }
          in_node.push(qName);
    }


    /**
     * �ѪR��Element�������ɩI�s��method
     */
    @Override
    public void endElement(String namespaceURI, String localName, String qName)
               throws SAXException
    {
          if (isDebugMode())
               Log.v(TAG, "endElement:    qName=" + qName);
          in_node.pop();
    }


    /** ���oElement���}�Y�������������r�� */
    @Override
    public void characters(char ch[], int start, int length)
    {
          String fetchStr = new String(ch).substring(start, start + length);
          // printNodePos();
          if (isDebugMode())
               Log.v(TAG, "\t characters:    ch=" + fetchStr);
          characters(fetchStr);
    }


    /**
     * ���oElement���}�Y�������������r��o�̻ݭn���u�s�WNode���W�Ҧ���ơv
     *
     * @param fetchStr
     *            ���o�쪺�r��
     */
    public void characters(String fetchStr)
    {
    }


    // --------------------------------------------------------------------------------------

    /**
     * �L�X�{�bNode����m�A�����ΡC�Ҧp:rss -> channel -> title 
     */
    public String printNodePos()
    {
          StringBuffer sb = new StringBuffer();
          // �L�X�{�bNode����m
          for (int i = 0; i < in_node.size(); i++)
          {
               if (i > 0)
                    sb.append(" -> ");
               sb.append(in_node.get(i));
          }
          sb.append("\n");
          return sb.toString();
    }


    /**
     * �b�Ѽư襤���ڭn���Ѽ�
     */
    public static String findAttr(Attributes atts, String findStr)
    {
          int i;
          for (i = 0; i < atts.getLength(); i++)
          {
               if (atts.getQName(i).compareToIgnoreCase(findStr) == 0)
               {
                    break;
               }
          }
          return atts.getValue(i);
    }


    public void setDebugMode(boolean debugMode)
    {
          this.debugMode = debugMode;
    }


    public boolean isDebugMode()
    {
          return debugMode;
    }
}
