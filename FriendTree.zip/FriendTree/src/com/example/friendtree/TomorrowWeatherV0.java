package com.example.friendtree;

public class TomorrowWeatherV0 {

	String location;
	String date;
	String day;
	String currenttemperature;
	String currentcondition;
	String currentweather;
	String low;
	String high;
	String icon;
	String condition;
	String date2;
	String day2;
	String low2;
	String high2;
	String condition2;
	
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getCurrenttemperature() {
		return currenttemperature;
	}
	public void setCurrenttemperature(String currenttemperature) {
		this.currenttemperature = currenttemperature;
	}
	public String getCurrentcondition() {
		return currentcondition;
	}
	public void setCurrentcondition(String currentcondition) {
		this.currentcondition = currentcondition;
	}
	public String getCurrentweather() {
		return currentweather;
	}
	public void setCurrentweather(String currentweather) {
		this.currentweather = currentweather;
	}
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getDate2() {
		return date2;
	}
	public void setDate2(String date2) {
		this.date2 = date2;
	}
	public String getDay2() {
		return day2;
	}
	public void setDay2(String day2) {
		this.day2 = day2;
	}
	public String getLow2() {
		return low2;
	}
	public void setLow2(String low2) {
		this.low2 = low2;
	}
	public String getHigh2() {
		return high2;
	}
	public void setHigh2(String high2) {
		this.high2 = high2;
	}
	public String getCondition2() {
		return condition2;
	}
	public void setCondition2(String condition2) {
		this.condition2 = condition2;
	}
	
	public TomorrowWeatherV0(String location, String date, String day, String currenttemperature, String currentcondition, String currentweather, String low, String high, String icon,
			String condition, String date2, String day2, String low2, String high2, String condition2) {
		super();
		this.location = location;
		this.date = date;
		this.day = day;
		this.currenttemperature = currenttemperature;
		this.currentcondition = currentcondition;
		this.currentweather = currentweather;
		this.low = low;
		this.high = high;
		this.icon = icon;
		this.condition = condition;
		this.date2 = date2;
		this.day2 = day2;
		this.low2 = low2;
		this.high2 = high2;
		this.condition2 = condition2;
	}
	
	public TomorrowWeatherV0() {
		
	}	
}