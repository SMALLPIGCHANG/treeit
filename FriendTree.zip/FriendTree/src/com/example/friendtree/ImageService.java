package com.example.friendtree;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;


public class ImageService {
	//*********************************************�u�{������Ϥ��귽******************************************************
	//���a�ƾڽw�s
	public Map<String, SoftReference<Bitmap>> imageCacheMap = new HashMap<String, SoftReference<Bitmap>>();
	//�T�w���ӽu�{�Ӱ������
    private ExecutorService executorService = Executors.newFixedThreadPool(5);
    //�^�ը�ƨϥ�

 final static ImageService imageService = new ImageService();
    
	public static ImageService getInstance(){
		return imageService;
	}

	public void putImageCache(String url, Bitmap bitmap) {
		try {
			if(!ImageCache.getInstance().isBitmapExit(url));
				ImageCache.getInstance().put(url, bitmap, true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setBitmapByURL(String url,final ImageView imageView,final Bitmap defaultBitmap,boolean isCacheToLocal) {
		//�ĥ�Handler+Thread+�ʸ˥~�����f
	    //�p�G�w�s�L�N�|�q�w�s�����X�Ϲ��AImageCallback���f����k�]���|�Q����
		Bitmap cacheImage = loadBitmap(url,imageView,isCacheToLocal,new ImageCallback() {
	    //�аѨ���{�G�p�G�Ĥ@���[��URL�ɤU����k�|����
		@Override
		public void imageLoad(ImageView imageView, Bitmap bitmap) {
			//�p�G��^��Bitmap���ųo����q�{�Ϥ�
	    	   if (bitmap!=null) {
		            imageView.setImageBitmap(bitmap);
	    	   }else {
	    		   imageView.setImageBitmap(defaultBitmap);
	    	   }
		}
	     });
	     if(cacheImage!=null){
	    	 imageView.setImageBitmap(cacheImage);
	     }else {
	    	// imageView.setImageBitmap(defaultBitmap);
		}
	}

   public Bitmap loadBitmap(final String imageUrl,final ImageView imageView,final boolean isCacheToLocal,final ImageCallback imageCallback) {
       //�p�G�w�s�L�N�q�w�s�����X�ƾ�
	   final Handler handler = new Handler()  
       {  
           @Override  
           public void handleMessage(Message msg)  
           {  
        	   imageCallback.imageLoad(imageView, (Bitmap)msg.obj);  
           }  
       };  
       if (imageCacheMap.containsKey(imageUrl)) {
    	   Log.e("����","�w�s����Ϥ�");
           SoftReference<Bitmap> softReference = imageCacheMap.get(imageUrl);
           if (softReference.get() != null) {
               return softReference.get();
           }
       }else     
       if(ImageCache.getInstance().isBitmapExit(imageUrl)){
    	   Log.e("����","���a����Ϥ�");
    	   Bitmap bitmap=null;
    	   try {
				bitmap = ImageCache.getInstance().get(imageUrl);
			} catch (Exception e) {
				bitmap = null;
			}
			return bitmap;
       }
       else {
		
       //�w�s���S���Ϲ��A�h�q�����W���X�ƾڡA�ñN���X���ƾڽw�s�줺�s��
        executorService.submit(new Runnable() {
           public void run() {
               try {
            	   //����Ϥ�
                   final Bitmap bitmap = getNetBitmapByURL(imageUrl);
                   //�N�Ϥ���m�줺�s��
                   Log.e("����", "��������Ϥ�"+Thread.currentThread().getName());
                   if(bitmap!=null){
                	   Log.e("����", "�s�x��");
                	   imageCacheMap.put(imageUrl, new SoftReference<Bitmap>(bitmap));
                	   ImageCache.getInstance().put(imageUrl, bitmap, isCacheToLocal);
                   }
                   Message msg = handler.obtainMessage(0, bitmap);  
                   handler.sendMessage(msg);
               } catch (Exception e) {
                   throw new RuntimeException(e);
               }
           }
       });
       }
       return null;
   }
   //��������Ϥ�
   protected Bitmap getNetBitmapByURL(String urlString) {
		URL url = null;
		InputStream inputStream = null;
		HttpURLConnection urlConnection = null;
		Bitmap bmp = null;
		try {
			url = new URL(urlString);
			urlConnection = (HttpURLConnection) url.openConnection();
			urlConnection.setRequestMethod("GET");
			urlConnection.setConnectTimeout(10000);
			inputStream = urlConnection.getInputStream();
			byte[] bt = getBytesFromStream(inputStream);
			bmp = BitmapFactory.decodeByteArray(bt, 0, bt.length);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != inputStream) {
				try {
					inputStream.close();
					inputStream = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (null != urlConnection) {
				urlConnection.disconnect();
				urlConnection = null;
			}
		}
		return bmp;
	}

	// �ƾڬy
	private byte[] getBytesFromStream(InputStream inputStream) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] b = new byte[1024];
		int len = 0;
		while (len != -1) {
			try {
				len = inputStream.read(b);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (len != -1) {
				baos.write(b, 0, len); 
			}
		}
		if (inputStream != null) {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return baos.toByteArray();
	}
   //��~�ɶ}�񪺦^�ձ��f
   private interface ImageCallback {
       //�`�N����k�O�Ψӳ]�m�ؼй�H���Ϲ��귽
	   public void imageLoad(ImageView imageView, Bitmap bitmap);
   }	
   
}
