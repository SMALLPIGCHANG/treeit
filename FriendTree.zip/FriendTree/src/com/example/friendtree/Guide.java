package com.example.friendtree;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.GestureDetector.OnGestureListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class Guide extends Activity implements OnGestureListener {

	private ImageView[] iv;
	private ViewFlipper flipper;//ViewFlipper
	private GestureDetector detector;//Ĳ�N��ť
	private Button btn;
	private int page=1;
	private Resources res;
	private BitmapDrawable bmpDraw;
	private Bitmap bmp;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);       															//�h�����ε{�����D
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);	//�h����������Abar
        setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);											//�ù���V
		setContentView(R.layout.guide);
		
		btn = (Button)findViewById(R.id.backtree);
		detector = new GestureDetector(this);//�_�l��Ĳ�N
		flipper = (ViewFlipper) this.findViewById(R.id.ViewFlipper01);//���oViewFlipper
		/*flipper.addView(addTextView("step 1"));//�NView�W�[��flipper�}�C��
		flipper.addView(addTextView("step 2"));
		flipper.addView(addTextView("step 3"));
		flipper.addView(addTextView("step 4"));
		flipper.addView(addTextView("step 5"));
		
		btn.setOnClickListener(new Button.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(Guide.this, MainFragment.class);
				startActivity(intent);
			}
		});*/
		
		res = getResources();
		
		iv = new ImageView[6];
		for(int i=0;i<6;i++)
		{
			iv[i] = new ImageView(this);
		}
		//iv1 = new ImageView(this);
		//bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide1);
		//bmp = bmpDraw.getBitmap();
        //iv1.setImageBitmap(bmp);
		//iv1.setBackgroundResource(R.drawable.guide1);
        //iv2 = new ImageView(this);
        //bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide2);
		//bmp = bmpDraw.getBitmap();
        //iv2.setImageBitmap(bmp);
        //iv2.setBackgroundResource(R.drawable.guide2);
        //iv3 = new ImageView(this);
        //bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide3);
		//bmp = bmpDraw.getBitmap();
        //iv3.setImageBitmap(bmp);
        //iv3.setBackgroundResource(R.drawable.guide3);
        //iv4 = new ImageView(this);
        //bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide4);
		//bmp = bmpDraw.getBitmap();
        //iv4.setImageBitmap(bmp);
        //iv4.setBackgroundResource(R.drawable.guide4);
        //iv5 = new ImageView(this);
        //bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide5);
		//bmp = bmpDraw.getBitmap();
        //iv5.setImageBitmap(bmp);
        //iv5.setBackgroundResource(R.drawable.guide5);
        //iv6 = new ImageView(this);
        //bmpDraw = (BitmapDrawable)res.getDrawable(R.drawable.guide6);
		//bmp = bmpDraw.getBitmap();
        //iv6.setImageBitmap(bmp);
        //iv6.setBackgroundResource(R.drawable.guide6);
		iv[0].setBackgroundResource(R.drawable.guide1);
		flipper.addView(iv[0]);
		flipper.addView(iv[1]);
		flipper.addView(iv[2]);
		flipper.addView(iv[3]);
		flipper.addView(iv[4]);
		flipper.addView(iv[5]);
		
		
	}
	
	
	
	private View addTextView(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setGravity(1);
        return tv;
    }
	
	@Override  
    public boolean onTouchEvent(MotionEvent event) {   
        return this.detector.onTouchEvent(event);   
    }
	
	/*public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
            float velocityY) {
		this.flipper.showNext();//���flipper�����U�@��view
		return true;
    }*/
	
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
	    if (e1.getX() - e2.getX() > 120) {//�p�G�O�q�k�V���ư�
	        //���Uflipper���i�X�ĪG
	    	if(page==6)
	    	{
	    		flipper.removeAllViews();
	    		//bmp.recycle();
				Guide.this.finish();
	    	}
	    	else
	    	{
	    		page++;
	    		switch(page)
	    		{
	    			case 2:
	    				iv[page-1].setBackgroundResource(R.drawable.guide2);
	    				this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.left_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.left_out));
	    		        this.flipper.showNext();
	    				iv[page-2].setBackgroundColor(0xff000000);
	    				break;
	    			case 3:
	    				iv[page-1].setBackgroundResource(R.drawable.guide3);
	    				this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.left_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.left_out));
	    		        this.flipper.showNext();
	    				iv[page-2].setBackgroundColor(0xff000000);
	    				break;
	    			case 4:
	    				iv[page-1].setBackgroundResource(R.drawable.guide4);
	    				this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.left_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.left_out));
	    		        this.flipper.showNext();
	    				iv[page-2].setBackgroundColor(0xff000000);
	    				break;
	    			case 5:
	    				iv[page-1].setBackgroundResource(R.drawable.guide5);
	    				this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.left_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.left_out));
	    		        this.flipper.showNext();
	    				iv[page-2].setBackgroundColor(0xff000000);
	    				break;
	    			case 6:
	    				iv[page-1].setBackgroundResource(R.drawable.guide6);
	    				this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.left_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.left_out));
	    		        this.flipper.showNext();
	    				iv[page-2].setBackgroundColor(0xff000000);
	    				break;
	    		}
		        
	    	}
	        return true;
	    } else if (e1.getX() - e2.getX() < -120) {//�p�G�O�q���V�k�ư�
	    	if(page!=1)
	    	{
	    		page--;
	    		switch(page)
	    		{
	    			case 1:
	    				iv[page-1].setBackgroundResource(R.drawable.guide1);
	    		        this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.right_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.right_out));
	    		        this.flipper.showPrevious();
	    				iv[page].setBackgroundColor(0xff000000);
	    				break;
	    			case 2:
	    				iv[page-1].setBackgroundResource(R.drawable.guide2);
	    		        this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.right_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.right_out));
	    		        this.flipper.showPrevious();
	    				iv[page].setBackgroundColor(0xff000000);
	    				break;
	    			case 3:
	    				iv[page-1].setBackgroundResource(R.drawable.guide3);
	    		        this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.right_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.right_out));
	    		        this.flipper.showPrevious();
	    				iv[page].setBackgroundColor(0xff000000);
	    				break;
	    			case 4:
	    				iv[page-1].setBackgroundResource(R.drawable.guide4);
	    		        this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.right_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.right_out));
	    		        this.flipper.showPrevious();
	    				iv[page].setBackgroundColor(0xff000000);
	    				break;
	    			case 5:
	    				iv[page-1].setBackgroundResource(R.drawable.guide5);
	    		        this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.right_in));
	    		        this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.right_out));
	    		        this.flipper.showPrevious();
	    				iv[page].setBackgroundColor(0xff000000);
	    				break;
	    		}
		        
	    	}
	        return true;
	    }
	    
	    /*if (e1.getY() - e2.getY() > 120) {//�p�G�O�q�U���W�ư�
            //���Uflipper���i�X�ĪG
			this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.up_in));
			this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.up_out));
			this.flipper.showNext();
			return true;
			} else if (e1.getY() - e2.getY() < -120) {//�p�G�O�q�W���U�ư�
			this.flipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.down_in));
			this.flipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.down_out));
			this.flipper.showPrevious();
			return true;
		}*/
	    return false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.friend_tree, menu);
		return true;
	}



	@Override
	public boolean onDown(MotionEvent arg0) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public void onLongPress(MotionEvent arg0) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public boolean onScroll(MotionEvent arg0, MotionEvent arg1, float arg2,
			float arg3) {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public void onShowPress(MotionEvent arg0) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public boolean onSingleTapUp(MotionEvent arg0) {
		// TODO Auto-generated method stub
		return false;
	}

}
